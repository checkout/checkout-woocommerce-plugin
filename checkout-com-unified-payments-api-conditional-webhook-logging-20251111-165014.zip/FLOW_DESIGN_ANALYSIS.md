# Flow Payment Design Analysis

## Current Flow (with AJAX - Problematic)

### Non-3DS Payment Flow:
1. User clicks "Place Order"
2. JavaScript intercepts click
3. **AJAX creates order** (Order 425) via `handle_create_order()`
4. Order ID added to form as hidden field
5. Flow component submits payment
6. Payment completes immediately (no 3DS)
7. Form submits normally
8. **WooCommerce creates duplicate order** (Order 426) during checkout
9. Duplicate prevention hook deletes Order 426
10. `process_payment()` called with Order 426 (deleted) → Falls back to Order 425
11. Payment processes successfully but with confusion

### 3DS Payment Flow:
1. User clicks "Place Order"
2. JavaScript intercepts click
3. **AJAX creates order** (Order 425) via `handle_create_order()`
4. Order ID added to form as hidden field
5. Flow component submits payment
6. **3DS challenge detected** → Redirects to 3DS page
7. After 3DS → Redirects to `/?wc-api=wc_checkoutcom_flow_process?cko-payment-id=xxx`
8. `handle_3ds_return()` finds order by payment session ID
9. Calls `process_payment()` to complete order
10. Redirects to order-received page

## Issues with Current Design

1. **Duplicate Orders**: AJAX creates order, then WooCommerce creates another
2. **Complex Duplicate Prevention**: Multiple hooks trying to prevent duplicates, but not working reliably
3. **Race Conditions**: Order created via AJAX, but WooCommerce doesn't know about it
4. **Missing Hook Calls**: `woocommerce_before_checkout_process` and `woocommerce_checkout_order_id` filters not being called (no logs)
5. **Order ID Confusion**: `process_payment()` receives deleted order ID, has to fallback

## Proposed Flow (Old Design - Simpler)

### Non-3DS Payment Flow:
1. User clicks "Place Order"
2. Form submits normally (no interception for new cards)
3. **WooCommerce creates order** normally
4. `process_payment()` is called
5. Flow component already submitted payment (via `onPaymentCompleted` callback)
6. Payment ID is in POST data
7. `process_payment()` processes payment and returns success
8. Redirects to order-received page

### 3DS Payment Flow:
1. User clicks "Place Order"
2. Form submits normally (no interception for new cards)
3. **WooCommerce creates order** normally
4. `process_payment()` is called
5. Flow component detects 3DS challenge
6. **3DS redirect happens** (Flow SDK handles this)
7. After 3DS → Redirects to `/?wc-api=wc_checkoutcom_flow_process?cko-payment-id=xxx&cko-payment-session-id=xxx`
8. `handle_3ds_return()` finds order by:
   - Payment session ID (from URL or payment metadata)
   - Payment ID (from URL)
9. Calls `process_payment()` to complete order
10. Redirects directly to order-received page (no checkout page flash)

## Key Changes Needed

### 1. Remove AJAX Order Creation
- Remove `handle_create_order()` endpoint
- Remove AJAX call from JavaScript
- Remove duplicate prevention hooks

### 2. Simplify JavaScript
- Remove order creation logic from "Place Order" click handler
- Let form submit normally for new card payments
- Keep saved card logic (direct form submit)

### 3. Improve 3DS Return Handling
- Ensure `handle_3ds_return()` can find order reliably by payment session ID
- Make sure payment session ID is saved to order before 3DS redirect
- Direct redirect to order-received page (already working)

### 4. Payment Session ID Storage
- Save payment session ID to order in `process_payment()` BEFORE any redirects
- This ensures `handle_3ds_return()` can find the order

## Benefits of Old Design

1. **No Duplicate Orders**: WooCommerce creates order once, naturally
2. **Simpler Code**: No complex duplicate prevention logic
3. **More Reliable**: Uses WooCommerce's standard flow
4. **Better Error Handling**: Standard WooCommerce error handling
5. **Easier to Debug**: Standard flow, easier to trace

## Potential Challenges

1. **Payment Session ID Timing**: Need to ensure payment session ID is saved to order before 3DS redirect
2. **3DS Order Lookup**: Must reliably find order by payment session ID after 3DS return
3. **Form Submission**: Need to ensure Flow component submits before form submission (already handled by `onPaymentCompleted`)

## Implementation Steps

1. Remove AJAX order creation endpoint and JavaScript
2. Remove duplicate prevention hooks
3. Simplify "Place Order" click handler
4. Ensure payment session ID is saved early in `process_payment()`
5. Test 3DS flow to ensure order lookup works
6. Test non-3DS flow to ensure it works smoothly

