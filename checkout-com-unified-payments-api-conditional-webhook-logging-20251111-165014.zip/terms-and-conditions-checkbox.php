<?php
/**
 * Plugin Name: Terms and Conditions Checkbox
 * Description: Adds a required terms and conditions checkbox before the Place Order button on WooCommerce checkout
 * Version: 1.0.0
 * Author: Your Name
 * 
 * Add this code to your theme's functions.php file or create a custom plugin
 */

// Add terms and conditions checkbox before Place Order button
add_action( 'woocommerce_review_order_before_submit', 'add_custom_terms_and_conditions_checkbox', 10 );

function add_custom_terms_and_conditions_checkbox() {
	?>
	<div class="woocommerce-terms-and-conditions-wrapper" style="margin-bottom: 20px;">
		<p class="form-row terms wc-terms-and-conditions" style="margin: 0 0 15px 0;">
			<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox" style="display: flex; align-items: flex-start; cursor: pointer;">
				<input type="checkbox" 
					   class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" 
					   name="custom_terms_and_conditions" 
					   id="custom_terms_and_conditions" 
					   value="1" 
					   required
					   style="margin-top: 3px; margin-right: 10px; flex-shrink: 0;">
				<span style="font-size: 14px; line-height: 1.5;">
					<strong>Website and Program Terms of Use</strong><br>
					Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.<br><br>
					I have read and agree to the <a href="#" target="_blank" style="text-decoration: underline;">program terms and conditions</a>, I also understand that taking the first trade on the evaluation waives my right to a refund. <span class="required" style="color: #e2401c;">*</span>
				</span>
			</label>
		</p>
	</div>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		var termsCheckbox = $('#custom_terms_and_conditions');
		var placeOrderBtn = $('#place_order');
		
		// Disable Place Order button initially if checkbox is not checked
		if (!termsCheckbox.is(':checked')) {
			placeOrderBtn.prop('disabled', true).addClass('disabled');
		}
		
		// Enable/disable Place Order button based on checkbox state
		termsCheckbox.on('change', function() {
			if ($(this).is(':checked')) {
				placeOrderBtn.prop('disabled', false).removeClass('disabled');
				// Remove error styling when checked
				$(this).closest('.woocommerce-terms-and-conditions-wrapper').removeClass('woocommerce-invalid');
			} else {
				placeOrderBtn.prop('disabled', true).addClass('disabled');
			}
		});
		
		// Also check on form updates (WooCommerce may reset the button)
		$(document.body).on('updated_checkout', function() {
			if (!termsCheckbox.is(':checked')) {
				placeOrderBtn.prop('disabled', true).addClass('disabled');
			} else {
				placeOrderBtn.prop('disabled', false).removeClass('disabled');
			}
		});
	});
	</script>
	<style>
		.woocommerce-terms-and-conditions-wrapper.woocommerce-invalid {
			border: 2px solid #e2401c;
			padding: 10px;
			border-radius: 4px;
			background-color: #fff5f5;
		}
		.woocommerce-terms-and-conditions-wrapper.woocommerce-invalid label {
			color: #e2401c;
		}
	</style>
	<?php
}

// Validate terms and conditions checkbox
add_action( 'woocommerce_checkout_process', 'validate_custom_terms_and_conditions', 10 );

function validate_custom_terms_and_conditions() {
	if ( empty( $_POST['custom_terms_and_conditions'] ) ) {
		wc_add_notice( __( 'Please read and accept the Website and Program Terms of Use to proceed with your order.', 'woocommerce' ), 'error' );
	}
}

