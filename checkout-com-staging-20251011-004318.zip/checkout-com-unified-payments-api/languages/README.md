# Languages

## Generating POT

To generated POT template file for translation, run the following command:

```
wp i18n make-pot . "./languages/checkout-com-unified-payments-api.pot" --domain="checkout-com-unified-payments-api"
```

After the command completes, you'll find a `checkout-com-unified-payments-api.pot` strings file in this directory. 
