<?php
/**
 * FLOW class.
 *
 * @package wc_checkout_com
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/../includes/settings/class-wc-checkoutcom-cards-settings.php';
require_once __DIR__ . '/../includes/api/class-wc-checkoutcom-api-request.php';
require_once __DIR__ . '/../includes/subscription/class-wc-checkoutcom-subscription.php';

/**
 * Class WC_Gateway_Checkout_Com_Flow for FLOW.
 *
 * @package wc_checkout_com
 * @since 5.0.0
 */
#[AllowDynamicProperties]
class WC_Gateway_Checkout_Com_Flow extends WC_Payment_Gateway {

	/**
	 * WC_Gateway_Checkout_Com_Flow constructor.
	 */
	public function __construct() {

		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );

		$this->id                 = 'wc_checkout_com_flow';
		$this->method_title       = __( 'Checkout.com', 'checkout-com-unified-payments-api' );
		$this->method_description = __( 'The Checkout.com extension allows shop owners to process online payments through the <a href="https://www.checkout.com">Checkout.com Payment Gateway.</a>', 'checkout-com-unified-payments-api' );
		// Get title from settings - sanitize user input before using
		$title_setting = ! empty( $core_settings['title'] ) ? trim( sanitize_text_field( $core_settings['title'] ) ) : '';
		$this->title  = ! empty( $title_setting ) ? $title_setting : __( 'Checkout.com', 'checkout-com-unified-payments-api' );
		$this->has_fields         = true;
		$this->supports           = array(
			'products',
			'refunds',
			'tokenization',
			'subscriptions',
			'subscription_cancellation',
			'subscription_suspension',
			'subscription_reactivation',
			'subscription_date_changes',
			// Brought to parity with the Classic Cards gateway (cards.php:40-54). Without
			// these, customers/admins with Flow-created subscriptions had no UI path to
			// change the card on an active subscription, change the amount, or hold
			// multiple subscriptions. The change-payment-method path persists the new
			// source via WC_Checkoutcom_Subscription::save_source_id(), whose guards now
			// also recognise a WC_Subscription object (see process_payment / handle_3ds_return).
			'subscription_amount_changes',
			'subscription_payment_method_change',
			'subscription_payment_method_change_customer',
			'subscription_payment_method_change_admin',
			'multiple_subscriptions',
			// Enables the gateway on My Account → Payment methods → Add payment method, and the
			// "Add payment method" button. The actual save is driven by JS + the
			// wc_checkoutcom_flow_add_payment_method return endpoint (a $0 card verification that
			// tokenises the card), not by the default add_payment_method() submit handler.
			'add_payment_method',
		);

		$this->init_form_fields();
		$this->init_settings();

		$this->flow_enabled();

		// Turn these settings into variables we can use.
		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		// Webhook handler hook - ENABLED for Flow integration
		// Flow integration uses direct redirect for successful payments, but webhooks for 3DS, failures, etc.
		add_action( 'woocommerce_api_wc_checkoutcom_webhook', [ $this, 'webhook_handler' ] );
		
		// WC API endpoint for processing 3DS returns (similar to PayPal)
		// This allows direct redirect to order-received page without showing checkout page
		add_action( 'woocommerce_api_wc_checkoutcom_flow_process', [ $this, 'handle_3ds_return' ] );

		// WC API endpoint for the My Account → Add payment method return. Flow redirects here
		// (incl. after 3DS) once the $0 card verification completes; we tokenise the card.
		add_action( 'woocommerce_api_wc_checkoutcom_flow_add_payment_method', [ $this, 'handle_add_payment_method_return' ] );

		// Detect 3DS return on checkout page load and process server-side (no AJAX)
		// This handles cases where user returns to checkout page with 3DS parameters
		// Priority 1 ensures it runs very early, before other template_redirect hooks
		add_action( 'template_redirect', [ $this, 'detect_and_process_3ds_return_on_checkout' ], 1 );

		// Meta field on subscription edit.
		add_filter( 'woocommerce_subscription_payment_meta', [ $this, 'add_payment_meta_field' ], 10, 2 );
		
		// Store save card preference in order metadata when order is created (before 3DS redirect)
		add_action( 'woocommerce_checkout_create_order', [ $this, 'store_save_card_preference_in_order' ], 10, 2 );
		// Store payment session ID in order metadata when order is created (public checkout flow)
		add_action( 'woocommerce_checkout_create_order', [ $this, 'store_payment_session_id_in_order' ], 10, 2 );
		
		// Add order note with payment session ID after order is saved to database
		add_action( 'woocommerce_checkout_order_created', [ $this, 'add_payment_session_id_order_note' ], 10, 1 );

		// Preserve payment method title after order status changes (webhooks may overwrite it)
		add_action( 'woocommerce_order_status_changed', [ $this, 'preserve_payment_method_title' ], 20, 4 );
		
		// CRITICAL: Prevent order status downgrades (completed→on-hold, processing→on-hold)
		add_filter( 'woocommerce_order_status_changed', [ $this, 'prevent_status_downgrade' ], 5, 4 );
		
		// Filter order notes to use correct payment method title instead of gateway default
		add_filter( 'woocommerce_new_order_note_data', [ $this, 'filter_order_note_payment_method_title' ], 10, 2 );

		// Note: cko_flow_create_payment_session, cko_flow_create_order, and
		// cko_flow_submit_payment_session are registered in cko_register_flow_ajax_handlers()
		// (woocommerce-gateway-checkout-com.php) via init priority 0. Do not re-register here.

		// AJAX handler for creating failed orders when payment is declined before form submission
		add_action( 'wp_ajax_cko_flow_create_failed_order', [ $this, 'ajax_create_failed_order' ] );
		add_action( 'wp_ajax_nopriv_cko_flow_create_failed_order', [ $this, 'ajax_create_failed_order' ] );
		
		// AJAX handler for storing save card preference in WooCommerce session
		add_action( 'wp_ajax_cko_flow_store_save_card_preference', [ $this, 'ajax_store_save_card_preference' ] );
		add_action( 'wp_ajax_nopriv_cko_flow_store_save_card_preference', [ $this, 'ajax_store_save_card_preference' ] );
		
		// AJAX handler for saving payment session ID to order immediately after payment session creation
		add_action( 'wp_ajax_cko_flow_save_payment_session_id', [ $this, 'ajax_save_payment_session_id' ] );
		add_action( 'wp_ajax_nopriv_cko_flow_save_payment_session_id', [ $this, 'ajax_save_payment_session_id' ] );
		add_action( 'wc_ajax_cko_flow_save_payment_session_id', [ $this, 'ajax_save_payment_session_id' ] );

		// Note: cko_flow_submit_payment_session registered in cko_register_flow_ajax_handlers().
		
		// CRITICAL: Hook to prevent WooCommerce from resuming failed orders.
		// This runs early in the checkout process, BEFORE WooCommerce's create_order() is called.
		// Priority 5 ensures this runs before other checkout hooks.
		add_action( 'woocommerce_before_checkout_process', [ $this, 'prevent_failed_order_reuse' ], 5 );
		
		// CRITICAL: Hook into woocommerce_resume_order which fires WHEN WooCommerce is about to resume an order
		// This is our last chance to prevent order reuse - if payment session IDs don't match, clear session
		add_action( 'woocommerce_resume_order', [ $this, 'check_payment_session_on_resume' ], 1 );
		
		// CRITICAL: Clear order_awaiting_payment session BEFORE WooCommerce creates/reuses order
		// Hook into REST API pre-dispatch to clear session BEFORE Store API processes the request
		add_filter( 'rest_pre_dispatch', [ $this, 'clear_session_before_store_api_checkout' ], 1, 3 );
		
		// Also hook into wp_loaded for early session clearing (catches both classic and blocks checkout)
		add_action( 'wp_loaded', [ $this, 'early_clear_order_session_for_new_payment' ], 1 );
		
		// Keep classic checkout hook as backup
		add_filter( 'woocommerce_checkout_get_value', [ $this, 'maybe_clear_order_awaiting_payment' ], 5, 2 );
		
		// OPTIONAL: Exclude payment methods section from checkout fragment updates during coupon operations.
		// This preserves the Flow component (and entered card details) when cart total changes.
		// The payment amount is handled via handleSubmit callback instead of component reload.
		// Only enabled if the admin toggle is ON (default is OFF for compatibility).
		$flow_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_flow_settings' )
			: get_option( 'woocommerce_wc_checkout_com_flow_settings', array() );
		$preserve_card_enabled = isset( $flow_settings['flow_preserve_card_on_update'] ) && 'yes' === $flow_settings['flow_preserve_card_on_update'];
		if ( $preserve_card_enabled ) {
			add_filter( 'woocommerce_update_order_review_fragments', [ $this, 'exclude_payment_method_from_fragments' ], 10, 1 );
		}
	}

	/**
	 * Get payment method title based on payment type.
	 * 
	 * Returns the appropriate payment method title based on the actual payment type used
	 * (Google Pay, Apple Pay, PayPal, etc.) instead of always showing Flow's default title.
	 *
	 * @param WC_Order|null $order Order object (optional, for retrieving payment type from meta).
	 * @param array|null    $payment_details Payment details array (optional, for retrieving payment type from API response).
	 *
	 * @return string Payment method title.
	 */
	public function get_payment_method_title_by_type( $order = null, $payment_details = null ) {
		// Prevent infinite recursion
		static $in_progress = array();
		$order_id = $order ? $order->get_id() : 0;
		if ( isset( $in_progress[ $order_id ] ) ) {
			// Already processing this order, return default title to break recursion
			return $this->get_title();
		}
		$in_progress[ $order_id ] = true;
		
		$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
		
		if ( $gateway_debug ) {
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ========== STARTING PAYMENT METHOD TITLE DETECTION ==========' );
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order ID: ' . ( $order ? $order->get_id() : 'NULL' ) );
		}
		
		$payment_type = '';
		$payment_type_source = '';
		
		// Try to get payment type from multiple sources (priority order)
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ========== CHECKING PAYMENT TYPE SOURCES ==========' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just logging, actual usage is sanitized below
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] POST[cko-flow-payment-type]: ' . ( isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : 'NOT SET' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Just logging, actual usage is sanitized below
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] GET[cko-payment-type]: ' . ( isset( $_GET['cko-payment-type'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-type'] ) ) : 'NOT SET' ) );
		if ( ! empty( $payment_details ) ) {
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] payment_details[payment_type]: ' . ( isset( $payment_details['payment_type'] ) ? $payment_details['payment_type'] : 'NOT SET' ) );
			if ( isset( $payment_details['source'] ) && is_array( $payment_details['source'] ) ) {
				WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] payment_details[source][type]: ' . ( isset( $payment_details['source']['type'] ) ? $payment_details['source']['type'] : 'NOT SET' ) );
			}
		} else {
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] payment_details: EMPTY or NULL' );
		}
		if ( $order ) {
			$order_meta_payment_type = $order->get_meta( '_cko_flow_payment_type' );
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] order meta _cko_flow_payment_type: ' . ( $order_meta_payment_type ?: 'NOT SET' ) );
		}
		
		// 1. POST data (from form submission)
		if ( isset( $_POST['cko-flow-payment-type'] ) ) {
			$payment_type = sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) );
			$payment_type_source = 'POST[cko-flow-payment-type]';
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Using POST[cko-flow-payment-type]: ' . $payment_type );
		}
		// 2. GET data (from URL parameters)
		elseif ( isset( $_GET['cko-payment-type'] ) ) {
			$payment_type = sanitize_text_field( wp_unslash( $_GET['cko-payment-type'] ) );
			$payment_type_source = 'GET[cko-payment-type]';
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Using GET[cko-payment-type]: ' . $payment_type );
		}
		// 3. Payment details from API response - check card_wallet_type FIRST (for Google Pay, Apple Pay)
		// CRITICAL: Google Pay/Apple Pay have payment_type="Regular" but card_wallet_type="GooglePay"/"ApplePay"
		elseif ( ! empty( $payment_details ) && isset( $payment_details['source']['card_wallet_type'] ) ) {
			$card_wallet_type = strtolower( $payment_details['source']['card_wallet_type'] );
			if ( $card_wallet_type === 'googlepay' ) {
				$payment_type = 'googlepay';
				$payment_type_source = 'payment_details[source][card_wallet_type]';
				WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Detected Google Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
			} elseif ( $card_wallet_type === 'applepay' ) {
				$payment_type = 'applepay';
				$payment_type_source = 'payment_details[source][card_wallet_type]';
				WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Detected Apple Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
			} else {
				// Unknown wallet type, fall through to payment_type check
				WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ⚠️ Unknown card_wallet_type: ' . $payment_details['source']['card_wallet_type'] . ' - checking payment_type' );
			}
		}
		// 4. Payment details from API response - check payment_type (for Google Pay, Apple Pay, etc.)
		if ( empty( $payment_type ) && ! empty( $payment_details ) && isset( $payment_details['payment_type'] ) ) {
			$payment_type_raw = $payment_details['payment_type'];
			// CRITICAL FIX: When payment_type is "Regular", check source.type FIRST before normalizing to "card"
			// For APMs (Alma, PayPal, etc.), payment_type="Regular" but source.type="alma"/"paypal"/etc.
			if ( strtolower( $payment_type_raw ) === 'regular' ) {
				// Check if source.type exists and is NOT "card" (i.e., it's an APM)
				if ( isset( $payment_details['source']['type'] ) && strtolower( $payment_details['source']['type'] ) !== 'card' ) {
					$payment_type = strtolower( $payment_details['source']['type'] );
					$payment_type_source = 'payment_details[source][type]';
					WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Found APM via source.type: ' . $payment_type . ' (payment_type was "Regular")' );
				} else {
					// No source.type or source.type is "card" - normalize to "card"
					$payment_type = 'card';
					WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ⚠️ Normalized payment_details[payment_type] from "Regular" to "card"' );
				}
			} else {
				$payment_type = $payment_type_raw;
				WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Using payment_details[payment_type]: ' . $payment_type );
			}
			if ( empty( $payment_type_source ) ) {
				$payment_type_source = 'payment_details[payment_type]';
			}
		}
		// 5. Payment details from API response - check source type (fallback for card payments)
		elseif ( empty( $payment_type ) && ! empty( $payment_details ) && isset( $payment_details['source']['type'] ) ) {
			$payment_type = $payment_details['source']['type'];
			$payment_type_source = 'payment_details[source][type]';
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ⚠️ Using payment_details[source][type] (fallback): ' . $payment_type );
		}
		// 5. Order metadata
		elseif ( $order ) {
			$payment_type = $order->get_meta( '_cko_flow_payment_type' );
			$payment_type_source = 'order_meta[_cko_flow_payment_type]';
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Using order meta _cko_flow_payment_type: ' . ( $payment_type ?: 'NOT SET' ) );
		} else {
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ⚠️ Order object not available for meta check' );
		}
		
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] Final payment_type: ' . ( $payment_type ?: 'EMPTY' ) );
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] Payment type source: ' . ( $payment_type_source ?: 'NONE' ) );
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ========== END CHECKING PAYMENT TYPE SOURCES ==========' );
		
		if ( $gateway_debug ) {
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment type (raw): ' . ( $payment_type ?: 'EMPTY' ) );
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment type source: ' . ( $payment_type_source ?: 'NONE' ) );
			if ( ! empty( $payment_details ) ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment details available: YES' );
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment details keys: ' . implode( ', ', array_keys( $payment_details ) ) );
				if ( isset( $payment_details['source'] ) ) {
					WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment details[source] keys: ' . ( is_array( $payment_details['source'] ) ? implode( ', ', array_keys( $payment_details['source'] ) ) : 'NOT ARRAY' ) );
					if ( isset( $payment_details['source']['type'] ) ) {
						WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment details[source][type]: ' . $payment_details['source']['type'] );
					}
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment details available: NO' );
			}
		}
		
		// Normalize payment type (lowercase, remove spaces)
		$payment_type_normalized = strtolower( trim( $payment_type ) );
		
		if ( $gateway_debug ) {
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment type (normalized): ' . ( $payment_type_normalized ?: 'EMPTY' ) );
		}
		
		// Dynamically get payment method titles from WooCommerce gateways and settings
		// This avoids hardcoding APM titles and makes the code maintainable
		$payment_type_titles = array();
		
		// Special cases for wallet payments (not separate gateways)
		$payment_type_titles['googlepay'] = __( 'Google Pay', 'checkout-com-unified-payments-api' );
		$payment_type_titles['applepay']  = __( 'Apple Pay', 'checkout-com-unified-payments-api' );
		$payment_type_titles['paypal']    = __( 'PayPal', 'checkout-com-unified-payments-api' );
		$payment_type_titles['card']      = $this->get_title(); // Use Flow's default title for card payments
		
		// Get APM titles from settings mapping (same source as admin settings)
		// This is the single source of truth for APM names
		$apm_options = array(
			'alipay'     => __( 'Alipay', 'checkout-com-unified-payments-api' ),
			'boleto'     => __( 'Boleto', 'checkout-com-unified-payments-api' ),
			'ideal'      => __( 'iDEAL', 'checkout-com-unified-payments-api' ),
			'klarna'     => __( 'Klarna', 'checkout-com-unified-payments-api' ),
			'poli'       => __( 'Poli', 'checkout-com-unified-payments-api' ),
			'sepa'       => __( 'Sepa Direct Debit', 'checkout-com-unified-payments-api' ),
			'sofort'     => __( 'Sofort', 'checkout-com-unified-payments-api' ),
			'eps'        => __( 'EPS', 'checkout-com-unified-payments-api' ),
			'bancontact' => __( 'Bancontact', 'checkout-com-unified-payments-api' ),
			'knet'       => __( 'KNET', 'checkout-com-unified-payments-api' ),
			'fawry'      => __( 'Fawry', 'checkout-com-unified-payments-api' ),
			'qpay'       => __( 'QPay', 'checkout-com-unified-payments-api' ),
			'multibanco' => __( 'Multibanco', 'checkout-com-unified-payments-api' ),
			'alma'       => __( 'Alma', 'checkout-com-unified-payments-api' ),
		);
		
		// Merge APM options into payment type titles
		$payment_type_titles = array_merge( $payment_type_titles, $apm_options );
		
		// Try to get APM titles from WooCommerce gateway registry (if available and not already set)
		// This allows custom APM titles if merchants have customized them
		if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
			$available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
			foreach ( $available_gateways as $gateway_id => $gateway ) {
				// Check if this is an APM gateway (e.g., wc_checkout_com_alternative_payments_alipay)
				if ( strpos( $gateway_id, 'wc_checkout_com_alternative_payments_' ) === 0 ) {
					// Extract APM type from gateway ID (e.g., 'alipay' from 'wc_checkout_com_alternative_payments_alipay')
					$apm_type = str_replace( 'wc_checkout_com_alternative_payments_', '', $gateway_id );
					if ( ! empty( $apm_type ) && method_exists( $gateway, 'get_title' ) ) {
						// Use gateway title if it's been customized, otherwise keep default from settings
						$gateway_title = $gateway->get_title();
						if ( isset( $apm_options[ $apm_type ] ) && $gateway_title !== $apm_options[ $apm_type ] ) {
							$payment_type_titles[ $apm_type ] = $gateway_title;
							WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ Using customized APM gateway title for ' . $apm_type . ': ' . $gateway_title );
						}
					}
				}
			}
		}
		
		// Final fallback: if payment type not found in any mapping, capitalize it
		if ( ! empty( $payment_type_normalized ) && ! isset( $payment_type_titles[ $payment_type_normalized ] ) && $payment_type_normalized !== 'card' ) {
			$payment_type_titles[ $payment_type_normalized ] = ucfirst( $payment_type_normalized );
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ⚠️ APM not found in mappings, using capitalized name: ' . ucfirst( $payment_type_normalized ) );
		}
		
		// Return mapped title if found, otherwise default to Flow's title
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] Checking payment_type_titles for: ' . $payment_type_normalized );
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] Available payment types in map: ' . implode( ', ', array_keys( $payment_type_titles ) ) );
		if ( ! empty( $payment_type_normalized ) && isset( $payment_type_titles[ $payment_type_normalized ] ) ) {
			$final_title = $payment_type_titles[ $payment_type_normalized ];
			WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ✅ MATCH FOUND - Payment type: ' . $payment_type_normalized . ', Title: ' . $final_title );
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ✅ MATCH FOUND - Payment type: ' . $payment_type_normalized . ', Title: ' . $final_title );
			}
			unset( $in_progress[ $order_id ] );
			return $final_title;
		}
		
		// Default fallback to Flow's title
		$default_title = $this->get_title();
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] ❌ NO MATCH - Using default title: ' . $default_title );
		WC_Checkoutcom_Utility::logger( '[GET PAYMENT METHOD TITLE] Payment type normalized was: ' . ( $payment_type_normalized ?: 'EMPTY' ) );
		if ( $gateway_debug ) {
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ❌ NO MATCH - Using default title: ' . $default_title );
			WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Available payment types: ' . implode( ', ', array_keys( $payment_type_titles ) ) );
		}
		unset( $in_progress[ $order_id ] );
		return $default_title;
	}

	/**
	 * Preserve payment method title after order status changes.
	 * 
	 * This ensures that when webhooks update order status, the correct payment method title
	 * (e.g., "Google Pay" instead of "Pay by Card with Checkout.com") is preserved.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $old_status Old order status.
	 * @param string $new_status New order status.
	 * @param WC_Order $order Order object.
	 */
	public function preserve_payment_method_title( $order_id, $old_status, $new_status, $order ) {
		// Only process orders for this gateway
		if ( $order->get_payment_method() !== $this->id ) {
			return;
		}

		// Get payment type from order metadata
		$payment_type = $order->get_meta( '_cko_flow_payment_type' );
		$current_title = $order->get_payment_method_title();
		
		// If we have a payment type stored, ensure the title matches
		if ( ! empty( $payment_type ) ) {
			$correct_title = $this->get_payment_method_title_by_type( $order, null );
			
			// Only update if the title doesn't match
			if ( $correct_title !== $current_title ) {
				$order->set_payment_method_title( $correct_title );
				$order->save();
			}
		}
	}

	/**
	 * Prevent order status downgrades for this gateway.
	 * 
	 * This is a critical safety guard that prevents:
	 * - completed → on-hold (NEVER allowed)
	 * - completed → processing (NEVER allowed)
	 * - processing → on-hold (NEVER allowed)
	 * 
	 * But ALLOWS legitimate terminal states from webhooks:
	 * - processing → refunded (allowed from refund webhook)
	 * - completed → refunded (allowed from refund webhook)
	 * - on-hold → cancelled (allowed from void/cancel webhook)
	 * 
	 * This can happen when webhooks arrive out of order or when process_payment()
	 * runs after webhooks have already updated the order to a final state.
	 *
	 * @param int      $order_id   Order ID.
	 * @param string   $old_status Old order status (without wc- prefix).
	 * @param string   $new_status New order status (without wc- prefix).
	 * @param WC_Order $order      Order object.
	 */
	public function prevent_status_downgrade( $order_id, $old_status, $new_status, $order ) {
		// Only process orders for this gateway
		if ( $order->get_payment_method() !== $this->id ) {
			return;
		}

		// Define status hierarchy (higher number = more "complete")
		// Note: refunded and cancelled are terminal states that can be reached from processing/completed
		$status_hierarchy = array(
			'pending'    => 1,
			'failed'     => 2,
			'on-hold'    => 3,
			'processing' => 4,
			'completed'  => 5,
			'refunded'   => 6, // Terminal state - higher than completed
			'cancelled'  => 0, // Special case - handled separately
		);

		// Terminal states that are always allowed as destinations (not downgrades)
		// These represent legitimate end states from payment actions
		$terminal_states = array( 'refunded', 'cancelled' );

		// Always allow transitions TO terminal states (refund/cancel are legitimate actions)
		if ( in_array( $new_status, $terminal_states, true ) ) {
			WC_Checkoutcom_Utility::logger( 
				sprintf(
					'[STATUS GUARD] ✅ ALLOWED transition to terminal state: Order %d from "%s" to "%s"',
					$order_id,
					$old_status,
					$new_status
				)
			);
			return;
		}

		// Re-read actual status from DB — the $old_status parameter comes from the in-memory
		// order object and may be stale if a concurrent process (e.g. capture webhook) has
		// already advanced the order to a higher state between when this process loaded the
		// order and when it called update_status().
		clean_post_cache( $order_id );
		$fresh_order       = wc_get_order( $order_id );
		$actual_old_status = ( $fresh_order ) ? $fresh_order->get_status() : $old_status;

		$old_rank = isset( $status_hierarchy[ $actual_old_status ] ) ? $status_hierarchy[ $actual_old_status ] : 0;
		$new_rank = isset( $status_hierarchy[ $new_status ] )        ? $status_hierarchy[ $new_status ]        : 0;

		// Log any mismatch between the in-memory status and the real DB status.
		// This is a diagnostic signal that a concurrent process updated the order
		// between when this process loaded it and now — even if the transition is allowed.
		if ( $actual_old_status !== $old_status ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[STATUS GUARD] ⚠️ STALE READ DETECTED: Order %d in-memory status was "%s" but DB shows "%s". Requested transition: "%s" → "%s".',
					$order_id,
					$old_status,
					$actual_old_status,
					$actual_old_status,
					$new_status
				)
			);
		}

		// Detect downgrade attempt (excluding terminal state transitions handled above)
		if ( $old_rank > $new_rank && $old_rank >= 3 ) {
			// Allow manual admin changes - only block automated/webhook changes
			$is_admin_request   = is_admin() && current_user_can( 'edit_shop_orders' );
			$is_webhook_context = doing_action( 'woocommerce_api_wc_checkoutcom_flow_webhook' )
				|| doing_action( 'woocommerce_api_wc_checkoutcom_webhook' )
				|| doing_action( 'woocommerce_api_wc_checkoutcom_flow_process' );
			$is_rest_api = defined( 'REST_REQUEST' ) && REST_REQUEST;

			// Allow if admin user is manually changing AND not triggered by webhook/API
			if ( $is_admin_request && ! $is_webhook_context && ! $is_rest_api ) {
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[STATUS GUARD] ✅ ALLOWED manual admin status change: Order %d from "%s" to "%s" by user %d',
						$order_id,
						$actual_old_status,
						$new_status,
						get_current_user_id()
					)
				);
				return; // Allow the manual admin change
			}

			// This is an automated/webhook downgrade - block it
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[STATUS GUARD] ❌ BLOCKED automated status downgrade: Order %d from "%s" (DB) to "%s" - reverting to "%s" (in-memory old_status was "%s")',
					$order_id,
					$actual_old_status,
					$new_status,
					$actual_old_status,
					$old_status
				)
			);

			// Revert the status change by setting it back to the actual DB status.
			// Remove this filter temporarily to avoid infinite loop.
			remove_filter( 'woocommerce_order_status_changed', [ $this, 'prevent_status_downgrade' ], 5 );

			$order->set_status( $actual_old_status, __( 'Status downgrade prevented by payment gateway.', 'checkout-com-unified-payments-api' ) );
			$order->save();

			// Re-add the filter
			add_filter( 'woocommerce_order_status_changed', [ $this, 'prevent_status_downgrade' ], 5, 4 );
		}
	}

	/**
	 * Filter order note data to use correct payment method title.
	 * 
	 * WooCommerce generates "Payment via [gateway title]" notes when order status changes.
	 * This filter ensures the correct payment method title (e.g., "Google Pay") is used
	 * instead of the gateway's default title.
	 *
	 * @param array $note_data Order note data.
	 * @param array $args Note arguments.
	 * @return array Filtered note data.
	 */
	public function filter_order_note_payment_method_title( $note_data, $args ) {
		// Only process if note content contains "Payment via"
		if ( ! isset( $note_data['comment_content'] ) || strpos( $note_data['comment_content'], 'Payment via' ) === false ) {
			return $note_data;
		}
		
		// Get order ID from args or note data
		$order_id = isset( $args['order_id'] ) ? $args['order_id'] : ( isset( $note_data['comment_post_ID'] ) ? $note_data['comment_post_ID'] : 0 );
		
		if ( ! $order_id ) {
			return $note_data;
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order || $order->get_payment_method() !== $this->id ) {
			return $note_data;
		}
		
		// Get payment type from order metadata
		$payment_type = $order->get_meta( '_cko_flow_payment_type' );
		$current_title = $order->get_payment_method_title();
		$gateway_default_title = $this->get_title();
		
		// Only replace if we have a payment type and the note contains the gateway default title
		if ( ! empty( $payment_type ) && ! empty( $current_title ) && $current_title !== $gateway_default_title ) {
			$note_data['comment_content'] = str_replace( 
				'Payment via ' . $gateway_default_title,
				'Payment via ' . $current_title,
				$note_data['comment_content']
			);
		}
		
		return $note_data;
	}

	/**
	 * Check if the gateway is available.
	 * 
	 * Override parent method to ensure gateway is available when enabled and checkout mode is 'flow'.
	 * This bypasses WooCommerce's default currency/country restrictions.
	 *
	 * @return bool
	 */
	public function is_available() {
		// Check if gateway is enabled
		if ( 'yes' !== $this->enabled ) {
			return false;
		}

		// Check if checkout mode is set to 'flow'
		$checkout_setting = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$checkout_mode = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';
		
		if ( 'flow' !== $checkout_mode ) {
			return false;
		}

		// Gateway is available if enabled and checkout mode is 'flow'
		// We bypass currency/country restrictions as Flow supports all currencies/countries
		return true;
	}

	/**
	 * Check if the gateway is valid for use.
	 * 
	 * Override parent method to bypass currency/country restrictions.
	 * Flow supports all currencies and countries, so we always return true
	 * when the gateway is enabled and checkout mode is 'flow'.
	 *
	 * @return bool
	 */
	public function valid_for_use() {
		// Check if gateway is enabled
		if ( 'yes' !== $this->enabled ) {
			return false;
		}

		// Check if checkout mode is set to 'flow'
		$checkout_setting = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$checkout_mode = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';
		
		if ( 'flow' !== $checkout_mode ) {
			return false;
		}

		// Flow supports all currencies and countries, so always return true
		return true;
	}

	/**
	 * Add subscription order payment meta field.
	 *
	 * @param array           $payment_meta associative array of meta data required for automatic payments.
	 * @param WC_Subscription $subscription An instance of a subscription object.
	 * @return array
	 */
	/**
	 * Store save card preference in order metadata when order is created.
	 * This ensures the preference survives 3DS redirects.
	 *
	 * @param WC_Order $order The order object.
	 * @param array    $data  The order data.
	 * @return void
	 */
	public function store_save_card_preference_in_order( $order, $data ) {
		// Only process if this is a Flow payment
		if ( $this->id !== $order->get_payment_method() ) {
			return;
		}
		
		// Check if customer wants to save card (from POST data during order creation)
		$save_card_hidden = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
		$save_card_post = isset( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ) : '';
		$save_card_session = WC()->session->get( 'wc-wc_checkout_com_flow-new-payment-method' );
		
		// Determine if checkbox was checked
		$save_card_preference = 'no';
		if ( 'yes' === $save_card_hidden ) {
			$save_card_preference = 'yes';
		} elseif ( 'true' === $save_card_post || 'yes' === $save_card_post ) {
			$save_card_preference = 'yes';
		} elseif ( 'yes' === $save_card_session ) {
			$save_card_preference = 'yes';
		}
		
		// Store in order metadata
		$order->update_meta_data( '_cko_save_card_preference', $save_card_preference );
		WC_Checkoutcom_Utility::logger( '[FLOW INFO] Save card preference queued for order metadata: ' . $save_card_preference );
	}

	/**
	 * Store payment session ID in order metadata when order is created.
	 * 
	 * MULTI-TAB SUPPORT: This function now tracks ALL payment session IDs for an order.
	 * When WooCommerce reuses an order (e.g., in Blocks checkout), multiple payment sessions
	 * may be created for the same order. We track all of them so webhooks can match correctly.
	 * The FIRST payment session ID remains as the primary (_cko_payment_session_id),
	 * and all sessions are tracked in _cko_payment_attempts.
	 *
	 * @param WC_Order $order The order object.
	 * @param array    $data  The order data.
	 * @return void
	 */
	public function store_payment_session_id_in_order( $order, $data ) {
		// Only process if this is a Flow payment.
		if ( $this->id !== $order->get_payment_method() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified by WooCommerce checkout
		$payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) : '';
		if ( empty( $payment_session_id ) ) {
			return;
		}

		$order_id = $order->get_id();
		$existing_order_ps = $order->get_meta( '_cko_payment_session_id' );
		
		// Get existing payment attempts array
		$payment_attempts = $order->get_meta( '_cko_payment_attempts' );
		if ( empty( $payment_attempts ) || ! is_array( $payment_attempts ) ) {
			$payment_attempts = array();
		}
		
		// Check if this payment session is already tracked
		$session_already_tracked = false;
		foreach ( $payment_attempts as $attempt ) {
			if ( isset( $attempt['session_id'] ) && $attempt['session_id'] === $payment_session_id ) {
				$session_already_tracked = true;
				break;
			}
		}
		
		// If order already has a DIFFERENT payment session ID (multi-tab scenario)
		if ( ! empty( $existing_order_ps ) && $existing_order_ps !== $payment_session_id ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[FLOW PAYMENT SESSION] ⚠️ MULTI-TAB DETECTED: Order %d already has payment session %s, new attempt with session %s',
					$order_id,
					substr( $existing_order_ps, 0, 25 ),
					substr( $payment_session_id, 0, 25 )
				)
			);
			
			// Track this additional payment attempt (don't overwrite primary)
			if ( ! $session_already_tracked ) {
				$payment_attempts[] = array(
					'session_id'  => $payment_session_id,
					'payment_id'  => '', // Will be filled when payment is submitted
					'timestamp'   => current_time( 'mysql' ),
					'is_primary'  => false,
					'status'      => 'initiated',
				);
				$order->update_meta_data( '_cko_payment_attempts', $payment_attempts );
				
				// Add order note about multi-tab attempt
				$order->add_order_note(
					sprintf(
						__( 'Additional payment attempt detected (multi-tab). New Session: %s. Primary Session: %s', 'checkout-com-unified-payments-api' ),
						$payment_session_id,
						$existing_order_ps
					)
				);
				
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[FLOW PAYMENT SESSION] Added secondary payment attempt to order %d. Total attempts: %d',
						$order_id,
						count( $payment_attempts )
					)
				);
			}
			return;
		}

		// First payment session for this order - set as primary
		if ( empty( $existing_order_ps ) ) {
			$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
			
			// Initialize payment attempts array with this as the primary
			if ( ! $session_already_tracked ) {
				$payment_attempts[] = array(
					'session_id'  => $payment_session_id,
					'payment_id'  => '', // Will be filled when payment is submitted
					'timestamp'   => current_time( 'mysql' ),
					'is_primary'  => true,
					'status'      => 'initiated',
				);
				$order->update_meta_data( '_cko_payment_attempts', $payment_attempts );
			}
			
			WC_Checkoutcom_Utility::logger( '[FLOW INFO] Payment session ID queued for order metadata: ' . $payment_session_id );
		}
	}
	
	/**
	 * Add order note with payment session ID after order is saved.
	 *
	 * This runs on woocommerce_checkout_order_created hook which fires AFTER
	 * the order is saved to the database, ensuring the note is persisted.
	 *
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function add_payment_session_id_order_note( $order ) {
		// Only process if this is a Flow payment.
		if ( $this->id !== $order->get_payment_method() ) {
			return;
		}
		
		$payment_session_id = $order->get_meta( '_cko_payment_session_id' );
		if ( empty( $payment_session_id ) ) {
			return;
		}
		
		$order_id = $order->get_id();
		
		// Log order creation with real Order ID and billing email for debugging email mismatches
		WC_Checkoutcom_Utility::logger( '[FLOW INFO] Order created successfully - Order ID: ' . $order_id . ', Payment Session ID: ' . $payment_session_id . ', Billing Email: ' . ( $order->get_billing_email() ?: '(not set)' ) );
		
		// Add order note with payment session ID and order ID for tracking
		$order->add_order_note(
			sprintf(
				/* translators: 1: order ID, 2: payment session ID */
				__( 'Order #%1$s created with Payment Session ID: %2$s', 'checkout-com-unified-payments-api' ),
				$order_id,
				esc_html( $payment_session_id )
			)
		);
	}

	public function add_payment_meta_field( $payment_meta, $subscription ) {
		$source_id = $subscription->get_meta( '_cko_source_id' );

		$payment_meta[ $this->id ] = [
			'post_meta' => [
				'_cko_source_id' => [
					'value' => $source_id,
					'label' => 'Checkout.com FLOW Source ID',
				],
			],
		];

		return $payment_meta;
	}

	/**
	 * Show module configuration in backend.
	 *
	 * @return string|void
	 */
	public function init_form_fields() {
		$this->form_fields = WC_Checkoutcom_Cards_Settings::flow_settings();
		$this->form_fields = array_merge(
			$this->form_fields,
			array(
				'screen_button' => array(
					'id'    => 'screen_button',
					'type'  => 'screen_button',
					'title' => __( 'Other Settings', 'checkout-com-unified-payments-api' ),
				),
			)
		);
	}

	/**
	 * Generate links for the admin page.
	 *
	 * @param string $key The key.
	 * @param array  $value The value.
	 */
	public function generate_screen_button_html( $key, $value ) {
		WC_Checkoutcom_Admin::generate_links( $key, $value );
	}

	/**
	 * Show frames js on checkout page.
	 */
	public function payment_fields() {

		$save_card = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
		
		// Safely get flow saved card setting with fallback
		// Check Card settings first (new location), then Flow settings (backward compatibility)
		$card_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$flow_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_flow_settings' )
			: get_option( 'woocommerce_wc_checkout_com_flow_settings', array() );
		$flow_saved_card = isset( $card_settings['flow_saved_payment'] ) ? $card_settings['flow_saved_payment'] : ( isset( $flow_settings['flow_saved_payment'] ) ? $flow_settings['flow_saved_payment'] : 'saved_cards_first' );
		$flow_debug_logging = isset( $flow_settings['flow_debug_logging'] ) && 'yes' === $flow_settings['flow_debug_logging'];

		$order_pay_order_id = null;
		$order_pay_order = null;
		if ( is_wc_endpoint_url( 'order-pay' ) ) {
			global $wp;
			// We are on the order-pay page. Retrives order_id from order-pay page
			$order_pay_order_id = absint( $wp->query_vars['order-pay'] ?? 0 );
			$order_pay_order = wc_get_order( $order_pay_order_id );
		}

		if ( ! empty( $this->get_option( 'description' ) ) ) {
			echo esc_html( $this->get_option( 'description' ) ); 
		}
		?>
			<div></div>
			<div id="loading-overlay" class="cko-flow__overlay cko-flow__overlay--primary"><?php esc_html_e( 'Loading...', 'checkout-com-unified-payments-api' ); ?></div>
			<div id="loading-overlay2" class="cko-flow__overlay cko-flow__overlay--secondary"><?php esc_html_e( 'Loading...Do NOT refresh.', 'checkout-com-unified-payments-api' ); ?></div>
			<?php if ( is_user_logged_in() ) : ?>

				<?php if ( $order_pay_order ) : ?>
					<?php 
					// Only hide save card options for MOTO orders (Admin order + Order-pay page + Guest customer)
					$is_admin_created = $order_pay_order->is_created_via( 'admin' );
					$is_guest_customer = $order_pay_order->get_customer_id() == 0;
					$is_moto_order = $is_admin_created && $is_guest_customer;
					?>
					<?php if ( $is_moto_order ) : ?>
						<script>
							const orderPayTargetNode = document.body;

							// Hide Saved payment method for MOTO orders (Admin order + Order-pay page + Guest customer).
							// IMPORTANT: Hide the accordion container, not just the list inside
							const orderPayObserver = new MutationObserver((mutationsList, observer) => {
								// Hide the accordion container (which contains the saved cards)
								const $accordion = jQuery('.cko-flow__saved-cards-accordion-container');
								if ($accordion.length) {
									$accordion.hide();
									if (flowDebugLogging) console.log('[FLOW] Hiding saved cards accordion for MOTO order');
								}
								
								// Also hide any saved payment methods that aren't wrapped yet
								const $element = jQuery('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');
								if ($element.length) {
									$element.hide();
								}
								
								// Hide the "Save to account" checkbox for MOTO orders (Admin order + Order-pay page + Guest customer)
								const $saveNew = jQuery('.woocommerce-SavedPaymentMethods-saveNew');
								if ($saveNew.length) {
									$saveNew.hide();
									if (flowDebugLogging) console.log('[FLOW] Hiding save to account checkbox for MOTO order');
								}
								
								// Also hide the checkbox by its ID
								const $saveCheckbox = jQuery('#wc-wc_checkout_com_flow-new-payment-method').closest('p');
								if ($saveCheckbox.length) {
									$saveCheckbox.hide();
								}
								
								// Keep observer running to catch late additions
							});

							const orderPayConfig = {
								childList: true,
								subtree: true
							};

							orderPayObserver.observe(orderPayTargetNode, orderPayConfig);

							// Try to hide it immediately in case it's already present.
							jQuery('.cko-flow__saved-cards-accordion-container').hide();
							jQuery('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods').hide();
							
							// Hide the "Save to account" checkbox for MOTO orders (Admin order + Order-pay page + Guest customer)
							jQuery('.woocommerce-SavedPaymentMethods-saveNew').hide();
							jQuery('#wc-wc_checkout_com_flow-new-payment-method').closest('p').hide();
						</script>
					<?php else : ?>
					<script>
						// Expose saved payment display order to JavaScript
						window.saved_payment = '<?php echo esc_js( $flow_saved_card ); ?>';
						
						jQuery(document).ready(function($) {
							
							// Enhance payment method label styling
							function enhancePaymentLabel() {
								const $label = $('.payment_method_wc_checkout_com_flow > label[for="payment_method_wc_checkout_com_flow"]');
								
								if ($label.length && !$label.find('.cko-flow__payment-method-text').length) {
									const labelText = $label.text().trim();
									
									// Wrap label text in styled containers
									$label.html(`
										<span class="cko-flow__payment-method-text">
											<span class="cko-flow__payment-method-title">${labelText}</span>
											<span class="cko-flow__payment-method-subtitle">Secure payment powered by Checkout.com</span>
										</span>
									`);
									
									flowLog('Payment method label enhanced');
								}
							}
							
							// Run immediately and after checkout updates
							enhancePaymentLabel();
							$(document.body).on('updated_checkout', enhancePaymentLabel);
							
							// Customize "Save to account" checkbox label
							function customizeSaveCardLabel() {
								const $checkbox = $('#wc-wc_checkout_com_flow-new-payment-method');
								const $label = $('label[for="wc-wc_checkout_com_flow-new-payment-method"]');
								
								if ($label.length) {
									$label.html('<span class="cko-flow__save-card-label-text">Save card for future purchases</span>');
									flowLog('Save card label customized');
								}
								
								// Apply Flow customization styles to the save card checkbox
								if (typeof window.appearance !== 'undefined') {
									const colors = window.appearance;
									
									// Style the checkbox container
									$('.cko-save-card-checkbox').css({
										'padding': '12px 16px',
										'background-color': colors.colorFormBackground || '#f8f9fa',
										'border': '1px solid ' + (colors.colorBorder || '#e0e0e0'),
										'border-radius': colors.borderRadius ? colors.borderRadius[0] : '8px',
										'margin': '12px 0',
									});
									
									// Style the label text
									$('.cko-flow__save-card-label-text').css({
										'color': colors.colorPrimary || '#1a1a1a',
										'font-family': colors.label?.fontFamily || 'inherit',
										'font-size': colors.label?.fontSize || '14px',
										'font-weight': colors.label?.fontWeight || '500',
										'margin-left': '8px',
									});
									
									flowLog('Save card checkbox styled with Flow colors');
								}
							}
							
							// Apply label customization
							customizeSaveCardLabel();
							$(document.body).on('updated_checkout', function() {
								setTimeout(customizeSaveCardLabel, 100);
							});
							
							// Re-apply styles after Flow customization loads
							$(window).on('load', function() {
								setTimeout(customizeSaveCardLabel, 600);
							});
							
							// Remove "Use a new payment method" radio button from DOM
							function removeNewPaymentMethodButton() {
								$('.woocommerce-SavedPaymentMethods-new').remove();
								$('li.woocommerce-SavedPaymentMethods-new').remove();
								$('input[value="new"][name*="payment-token"]').closest('li').remove();
								flowLog('Removed "Use a new payment method" button');
							}
							
							// Remove immediately and after checkout updates
							removeNewPaymentMethodButton();
							$(document.body).on('updated_checkout', function() {
								setTimeout(removeNewPaymentMethodButton, 100);
							});
							
							// Apply payment method label customization settings
							function applyPaymentLabelCustomization() {
								if (typeof cko_flow_customization_vars === 'undefined') {
									setTimeout(applyPaymentLabelCustomization, 100);
									return;
								}
								
								const settings = cko_flow_customization_vars;
								const root = document.documentElement;
								
								// Background
								const bg = settings.flow_payment_label_background || 'transparent';
								root.style.setProperty('--cko-payment-label-bg', bg === 'transparent' || bg === '' ? 'transparent' : bg);
								
								// Border
								const borderColor = settings.flow_payment_label_border_color || '';
								const borderWidth = settings.flow_payment_label_border_width || '0px';
								root.style.setProperty('--cko-payment-label-border-color', borderColor || 'transparent');
								root.style.setProperty('--cko-payment-label-border-width', borderWidth);
								
								// Border radius
								const borderRadius = settings.flow_payment_label_border_radius || '0px';
								root.style.setProperty('--cko-payment-label-border-radius', borderRadius);
								
								// Icon position
								const iconPosition = settings.flow_payment_label_icon_position || 'right';
								if (iconPosition === 'right') {
									root.style.setProperty('--cko-payment-label-icon-display-left', 'none');
									root.style.setProperty('--cko-payment-label-icon-display-right', 'inline-block');
									root.style.setProperty('--cko-payment-label-icon-order-right', '2');
								} else if (iconPosition === 'left') {
									root.style.setProperty('--cko-payment-label-icon-display-left', 'inline-block');
									root.style.setProperty('--cko-payment-label-icon-display-right', 'none');
								} else { // none
									root.style.setProperty('--cko-payment-label-icon-display-left', 'none');
									root.style.setProperty('--cko-payment-label-icon-display-right', 'none');
								}
								
								// Text colors
								const textColor = settings.flow_payment_label_text_color || '';
								const subtitleColor = settings.flow_payment_label_subtitle_color || '';
								root.style.setProperty('--cko-payment-label-text-color', textColor || 'inherit');
								root.style.setProperty('--cko-payment-label-subtitle-color', subtitleColor || 'inherit');
								
								// Text alignment
								const textAlign = settings.flow_payment_label_text_align || 'left';
								root.style.setProperty('--cko-payment-label-text-align', textAlign);
								
								flowLog('Payment label customization applied:', {
									background: bg,
									border: `${borderWidth} ${borderColor || 'transparent'}`,
									iconPosition: iconPosition,
									textColor: textColor || 'inherit',
									textAlign: textAlign
								});
							}
							
							// Apply Flow customization colors to payment label and saved cards
							let appearanceRetryCount = 0;
							const maxAppearanceRetries = 50; // Max 5 seconds (50 * 100ms)
							function applyFlowCustomization() {
								if (typeof window.appearance === 'undefined') {
									appearanceRetryCount++;
									if (appearanceRetryCount < maxAppearanceRetries) {
										setTimeout(applyFlowCustomization, 100);
										return;
									} else {
										flowLog('Appearance settings not available after ' + maxAppearanceRetries + ' retries - skipping customization');
										return;
									}
								}
								
								const colors = window.appearance;
								const borderRadius = colors.borderRadius ? colors.borderRadius[0] : '8px';
								
								flowLog('Applying Flow customization colors:', colors);
								
								// Note: Payment method label styling is now handled by applyPaymentLabelCustomization()
								// This function only applies to saved cards accordion and Flow container
								
								// Apply to saved cards accordion
								const $accordion = $('.cko-flow__saved-cards-accordion');
								if ($accordion.length) {
									$accordion.css({
										'background-color': colors.colorFormBackground || '#ffffff',
										'border-color': colors.colorPrimary || '#186aff',
										'border-radius': borderRadius,
									});
									
									// Apply to saved cards header text
									$('.cko-flow__saved-cards-label-text').css({
										'color': colors.colorPrimary || '#1a1a1a',
										'font-family': colors.label?.fontFamily || 'inherit',
										'font-size': colors.label?.fontSize || '15px',
										'font-weight': colors.label?.fontWeight || '600',
									});
									
									$('.cko-flow__saved-cards-label-subtext').css({
										'color': colors.colorSecondary || '#666',
										'font-family': colors.footnote?.fontFamily || 'inherit',
										'font-size': colors.footnote?.fontSize || '13px',
									});
								}
								
								// Apply to Flow container border
								const $flowContainer = $('#flow-container');
								if ($flowContainer.length && $('.cko-flow__saved-cards-accordion-container').length) {
									$flowContainer.css({
										'background-color': colors.colorFormBackground || '#ffffff',
										'border-color': colors.colorPrimary || '#186aff',
										'border-radius': borderRadius,
									});
								}
								
								flowLog('Flow customization colors applied');
							}
							
							// Apply payment label customization on page load and after checkout updates
							jQuery(document).ready(function() {
								applyPaymentLabelCustomization();
								jQuery(document.body).on('updated_checkout', function() {
									setTimeout(applyPaymentLabelCustomization, 100);
								});
							});
							
							// Apply on page load and after checkout updates
							$(window).on('load', function() {
								setTimeout(applyFlowCustomization, 500);
							});
							$(document.body).on('updated_checkout', function() {
								setTimeout(applyFlowCustomization, 200);
							});
							
							const $savedMethods = $('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');

						const totalCount = $savedMethods.toArray().reduce((sum, el) => {
							return sum + parseInt($(el).data('count') || 0, 10);
						}, 0);

				// Show both Flow and saved cards on the same page
				const displayOrder = '<?php echo esc_js( $flow_saved_card ); ?>';
				flowLog('Display order:', displayOrder, 'Total saved cards:', totalCount);
				flowLog('CSS will control saved cards visibility via data-saved-payment-order attribute');

				// Wrap saved payment methods in styled accordion container
				function wrapSavedCardsInAccordion() {
					if (totalCount > 0 && !$('.cko-flow__saved-cards-accordion-container').length && $savedMethods.length > 0) {
						// Wait for Flow container or use payment method container as fallback
						let $insertionPoint = $('#flow-container');
						let $fallbackPoint = $('.payment_method_wc_checkout_com_flow').first();
						
						if (!$insertionPoint.length) {
							$insertionPoint = $fallbackPoint;
						}
						
						flowLog('Insertion point found:', $insertionPoint.length > 0, 'Display order:', displayOrder);
						
						if ($insertionPoint.length || $fallbackPoint.length) {
							// Create accordion container
							const accordionHTML = `
								<div class="cko-flow__saved-cards-accordion-container">
									<div class="cko-flow__saved-cards-accordion">
										<div class="cko-flow__saved-cards-accordion-header">
											<div class="cko-flow__saved-cards-accordion-left">
												<div class="cko-flow__saved-cards-icon">
													<svg width="40" height="24" viewBox="0 0 40 24" xmlns="http://www.w3.org/2000/svg" fill="none">
														<rect x="0.5" y="0.5" width="39" height="23" rx="3.5" stroke="#186aff"></rect>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M26.8571 6.85714H13.1428V17.1429H26.8571V6.85714ZM12.2857 6V18H27.7143V6H12.2857Z" fill="#186aff"></path>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M26.8571 9.42857H13.1428V7.71429H26.8571V9.42857Z" fill="#186aff"></path>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2857 15.4286H14.8571V14.5714H18.2857V15.4286Z" fill="#186aff"></path>
													</svg>
												</div>
												<div class="cko-flow__saved-cards-label">
													<span class="cko-flow__saved-cards-label-text">Saved cards</span>
													<span class="cko-flow__saved-cards-label-subtext">${totalCount} card${totalCount !== 1 ? 's' : ''} available</span>
												</div>
											</div>
										</div>
										<div class="cko-flow__saved-cards-accordion-panel">
											<!-- Saved payment methods will be moved here -->
										</div>
									</div>
								</div>
							`;
							
							// CRITICAL FIX: Insert accordion in a safe location that won't become flow-container
							// The payment method <li> structure is: radio, label, [accordion/payment_box]
							const $paymentMethodLi = $('.payment_method_wc_checkout_com_flow').first();
							const $label = $paymentMethodLi.find('label').first();
							
							if (displayOrder === 'saved_cards_first') {
								// Insert accordion AFTER the label, BEFORE any divs
								// This way it can never be mistaken for the payment_box div
								if ($label.length) {
									$label.after(accordionHTML);
									flowLog('Accordion inserted AFTER label (saved_cards_first)');
								} else {
									// Fallback: insert before first div
									const $firstDiv = $paymentMethodLi.children('div').first();
									if ($firstDiv.length) {
										$firstDiv.before(accordionHTML);
										flowLog('Accordion inserted BEFORE div (saved_cards_first fallback)');
									}
								}
							} else {
								// new_payment_first: Insert accordion AFTER the payment_box div (which contains flow-container)
								const $paymentBox = $paymentMethodLi.find('.payment_box').first();
								if ($paymentBox.length) {
									$paymentBox.after(accordionHTML);
									flowLog('Accordion inserted AFTER payment_box (new_payment_first)');
								} else {
									// Fallback: insert after label
									if ($label.length) {
										$label.after(accordionHTML);
										flowLog('Accordion inserted AFTER label (new_payment_first fallback)');
									}
								}
							}
							
							// Move saved payment methods into the accordion panel
							$savedMethods.each(function() {
								$(this).appendTo('.cko-flow__saved-cards-accordion-panel');
							});
							
							flowLog('Saved cards wrapped in accordion');
							
						// REMOVED: No default card selection - user must explicitly select a saved card
						// This prevents issues with default card detection
						flowLog('No default card selection - user must explicitly select');
						
						// Ensure no saved cards are auto-selected (remove any defaults)
						$('.cko-flow__saved-cards-accordion-panel input[name="wc-wc_checkout_com_flow-payment-token"]:not(#wc-wc_checkout_com_flow-payment-token-new)').prop('checked', false).removeAttr('checked');
						
						// Ensure "new" card option is selected by default
						const $newCardRadio = $('#wc-wc_checkout_com_flow-payment-token-new');
						if ($newCardRadio.length) {
							$newCardRadio.prop('checked', true);
							flowLog('"New card" option selected by default');
						}
						
						// Reset flags
						window.flowSavedCardSelected = false;
						window.flowUserInteracted = false;
						flowLog('Unchecked all saved cards and selected new payment method');
							
							// CRITICAL: After moving cards, ensure visibility rules are applied
							// Remove any inline display styles that might have been set during the move
							$('.cko-flow__saved-cards-accordion-container').each(function() {
								// Remove inline style to let CSS handle visibility
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from accordion container');
								}
							});
							
							$('.cko-flow__saved-cards-accordion-panel').each(function() {
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from accordion panel');
								}
							});
							
							$savedMethods.each(function() {
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from saved methods');
								}
							});
							
							flowLog('CSS will handle visibility via data-saved-payment-order:', displayOrder);
						} else {
							flowLog('No insertion point found, retrying...');
							setTimeout(wrapSavedCardsInAccordion, 100);
						}
					}
				}
				
				// Try immediately and also set a timeout as fallback
				wrapSavedCardsInAccordion();
				setTimeout(wrapSavedCardsInAccordion, 500);
				
				// CRITICAL: Re-wrap saved cards after WooCommerce updates checkout
				// WooCommerce's updated_checkout event destroys and recreates the payment methods HTML
				// Use a flag to prevent multiple simultaneous executions
				let accordionRecreationInProgress = false;
				jQuery(document.body).on('updated_checkout', function() {
					// Prevent multiple simultaneous executions
					if (accordionRecreationInProgress) {
						flowLog('Accordion recreation already in progress, skipping...');
						return;
					}
					
					flowLog('updated_checkout fired - re-wrapping saved cards...');
					accordionRecreationInProgress = true;
					
					setTimeout(function() {
						// Check if accordion AND panel exist, and if saved methods are inside
						const $existingAccordion = $('.cko-flow__saved-cards-accordion-container');
						const $existingPanel = $('.cko-flow__saved-cards-accordion-panel');
						const $panelMethods = $('.cko-flow__saved-cards-accordion-panel .woocommerce-SavedPaymentMethods');
						const $allMethods = $('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');
						
						flowLog('After updated_checkout:', {
							accordion: $existingAccordion.length,
							panel: $existingPanel.length,
							methodsInPanel: $panelMethods.length,
							totalMethods: $allMethods.length
						});
						
						// Recreate if accordion doesn't exist OR panel is missing OR methods not in panel
						if ($existingAccordion.length === 0 || $existingPanel.length === 0 || ($allMethods.length > 0 && $panelMethods.length === 0)) {
							flowLog('Accordion incomplete after updated_checkout, recreating...');
							// Remove any incomplete accordion first
							$existingAccordion.remove();
							// Recreate with fresh saved methods
							wrapSavedCardsInAccordion();
						} else {
							flowLog('Accordion complete after updated_checkout');
						}
						
						// Reset flag after a delay to allow for any follow-up updates
						setTimeout(function() {
							accordionRecreationInProgress = false;
						}, 500);
					}, 100);
				});

					});

						// Don't hide save card checkbox on page load - let Flow component control it

						document.addEventListener('DOMContentLoaded', function () {
							const radios = document.querySelectorAll('input[name="wc-wc_checkout_com_flow-payment-token"]');
							radios.forEach(radio => {
								radio.checked = false;
							});
						});
					</script>
					<?php endif; ?>
				<?php else : ?>
				<script>
					// Expose saved payment display order to JavaScript
					window.saved_payment = '<?php echo esc_js( $flow_saved_card ); ?>';
					
					jQuery(document).ready(function($) {
						
						// Customize "Save to account" checkbox label
						function customizeSaveCardLabel() {
							const $checkbox = $('#wc-wc_checkout_com_flow-new-payment-method');
							const $label = $('label[for="wc-wc_checkout_com_flow-new-payment-method"]');
							
							if ($label.length) {
								$label.html('<span class="cko-flow__save-card-label-text">Save card for future purchases</span>');
								flowLog('Save card label customized (section 2)');
							}
							
							// Apply Flow customization styles to the save card checkbox
							if (typeof window.appearance !== 'undefined') {
								const colors = window.appearance;
								
								// Style the checkbox container
								$('.cko-save-card-checkbox').css({
									'padding': '12px 16px',
									'background-color': colors.colorFormBackground || '#f8f9fa',
									'border': '1px solid ' + (colors.colorBorder || '#e0e0e0'),
									'border-radius': colors.borderRadius ? colors.borderRadius[0] : '8px',
									'margin': '12px 0',
								});
								
								// Style the label text
								$('.cko-flow__save-card-label-text').css({
									'color': colors.colorPrimary || '#1a1a1a',
									'font-family': colors.label?.fontFamily || 'inherit',
									'font-size': colors.label?.fontSize || '14px',
									'font-weight': colors.label?.fontWeight || '500',
									'margin-left': '8px',
								});
								
								flowLog('Save card checkbox styled with Flow colors (section 2)');
							}
						}
						
						// Apply label customization
						customizeSaveCardLabel();
						$(document.body).on('updated_checkout', function() {
							setTimeout(customizeSaveCardLabel, 100);
						});
						
						// Re-apply styles after Flow customization loads
						$(window).on('load', function() {
							setTimeout(customizeSaveCardLabel, 600);
						});
						
						// Remove "Use a new payment method" radio button from DOM
						function removeNewPaymentMethodButton() {
							$('.woocommerce-SavedPaymentMethods-new').remove();
							$('li.woocommerce-SavedPaymentMethods-new').remove();
							$('input[value="new"][name*="payment-token"]').closest('li').remove();
							flowLog('Removed "Use a new payment method" button (section 2)');
						}
						
						// Remove immediately and after checkout updates
						removeNewPaymentMethodButton();
						$(document.body).on('updated_checkout', function() {
							setTimeout(removeNewPaymentMethodButton, 100);
						});
						
						// Apply payment method label customization settings (section 2)
						function applyPaymentLabelCustomization() {
							if (typeof cko_flow_customization_vars === 'undefined') {
								setTimeout(applyPaymentLabelCustomization, 100);
								return;
							}
							
							const settings = cko_flow_customization_vars;
							const root = document.documentElement;
							
							// Background
							const bg = settings.flow_payment_label_background || 'transparent';
							root.style.setProperty('--cko-payment-label-bg', bg === 'transparent' || bg === '' ? 'transparent' : bg);
							
							// Border
							const borderColor = settings.flow_payment_label_border_color || '';
							const borderWidth = settings.flow_payment_label_border_width || '0px';
							root.style.setProperty('--cko-payment-label-border-color', borderColor || 'transparent');
							root.style.setProperty('--cko-payment-label-border-width', borderWidth);
							
							// Border radius
							const borderRadius = settings.flow_payment_label_border_radius || '0px';
							root.style.setProperty('--cko-payment-label-border-radius', borderRadius);
							
							// Icon position
							const iconPosition = settings.flow_payment_label_icon_position || 'right';
							if (iconPosition === 'right') {
								root.style.setProperty('--cko-payment-label-icon-display-left', 'none');
								root.style.setProperty('--cko-payment-label-icon-display-right', 'inline-block');
								root.style.setProperty('--cko-payment-label-icon-order-right', '2');
							} else if (iconPosition === 'left') {
								root.style.setProperty('--cko-payment-label-icon-display-left', 'inline-block');
								root.style.setProperty('--cko-payment-label-icon-display-right', 'none');
							} else { // none
								root.style.setProperty('--cko-payment-label-icon-display-left', 'none');
								root.style.setProperty('--cko-payment-label-icon-display-right', 'none');
							}
							
							// Text colors
							const textColor = settings.flow_payment_label_text_color || '';
							const subtitleColor = settings.flow_payment_label_subtitle_color || '';
							root.style.setProperty('--cko-payment-label-text-color', textColor || 'inherit');
							root.style.setProperty('--cko-payment-label-subtitle-color', subtitleColor || 'inherit');
							
							// Text alignment
							const textAlign = settings.flow_payment_label_text_align || 'left';
							root.style.setProperty('--cko-payment-label-text-align', textAlign);
							
							flowLog('Payment label customization applied (section 2):', {
								background: bg,
								border: `${borderWidth} ${borderColor || 'transparent'}`,
								iconPosition: iconPosition,
								textColor: textColor || 'inherit',
								textAlign: textAlign
							});
						}
						
						// Apply Flow customization colors to payment label and saved cards
						let appearanceRetryCount = 0;
						const maxAppearanceRetries = 50; // Max 5 seconds (50 * 100ms)
						function applyFlowCustomization() {
							if (typeof window.appearance === 'undefined') {
								appearanceRetryCount++;
								if (appearanceRetryCount < maxAppearanceRetries) {
									setTimeout(applyFlowCustomization, 100);
									return;
								} else {
									flowLog('Appearance settings not available after ' + maxAppearanceRetries + ' retries - skipping customization');
									return;
								}
							}
							
							const colors = window.appearance;
							const borderRadius = colors.borderRadius ? colors.borderRadius[0] : '8px';
							
							flowLog('Applying Flow customization colors (section 2):', colors);
							
							// Note: Payment method label styling is now handled by applyPaymentLabelCustomization()
							// This function only applies to saved cards accordion and Flow container
							
							// Apply to saved cards accordion
							const $accordion = $('.cko-flow__saved-cards-accordion');
							if ($accordion.length) {
								$accordion.css({
									'background-color': colors.colorFormBackground || '#ffffff',
									'border-color': colors.colorPrimary || '#186aff',
									'border-radius': borderRadius,
								});
								
								// Apply to saved cards header text
								$('.cko-flow__saved-cards-label-text').css({
									'color': colors.colorPrimary || '#1a1a1a',
									'font-family': colors.label?.fontFamily || 'inherit',
									'font-size': colors.label?.fontSize || '15px',
									'font-weight': colors.label?.fontWeight || '600',
								});
								
								$('.cko-flow__saved-cards-label-subtext').css({
									'color': colors.colorSecondary || '#666',
									'font-family': colors.footnote?.fontFamily || 'inherit',
									'font-size': colors.footnote?.fontSize || '13px',
								});
							}
							
							// Apply to Flow container border
							const $flowContainer = $('#flow-container');
							if ($flowContainer.length && $('.cko-flow__saved-cards-accordion-container').length) {
								$flowContainer.css({
									'background-color': colors.colorFormBackground || '#ffffff',
									'border-color': colors.colorPrimary || '#186aff',
									'border-radius': borderRadius,
								});
							}
							
							flowLog('Flow customization colors applied (section 2)');
						}
						
						// Apply payment label customization on page load and after checkout updates (section 2)
						jQuery(document).ready(function() {
							applyPaymentLabelCustomization();
							jQuery(document.body).on('updated_checkout', function() {
								setTimeout(applyPaymentLabelCustomization, 100);
							});
						});
						
						// Apply on page load and after checkout updates
						$(window).on('load', function() {
							setTimeout(applyFlowCustomization, 500);
						});
						$(document.body).on('updated_checkout', function() {
							setTimeout(applyFlowCustomization, 200);
						});
						
						const $savedMethods = $('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');

				const totalCount = $savedMethods.toArray().reduce((sum, el) => {
					return sum + parseInt($(el).data('count') || 0, 10);
				}, 0);

				// Show both Flow and saved cards on the same page
				const displayOrder = '<?php echo esc_js( $flow_saved_card ); ?>';
				flowLog('Display order:', displayOrder, 'Total saved cards:', totalCount);
				flowLog('CSS will control saved cards visibility via data-saved-payment-order attribute');

				// Wrap saved payment methods in styled accordion container
				function wrapSavedCardsInAccordion() {
					if (totalCount > 0 && !$('.cko-flow__saved-cards-accordion-container').length && $savedMethods.length > 0) {
						// Wait for Flow container or use payment method container as fallback
						let $insertionPoint = $('#flow-container');
						let $fallbackPoint = $('.payment_method_wc_checkout_com_flow').first();
						
						if (!$insertionPoint.length) {
							$insertionPoint = $fallbackPoint;
						}
						
						flowLog('Insertion point found:', $insertionPoint.length > 0, 'Display order:', displayOrder);
						
						if ($insertionPoint.length || $fallbackPoint.length) {
							// Create accordion container
							const accordionHTML = `
								<div class="cko-flow__saved-cards-accordion-container">
									<div class="cko-flow__saved-cards-accordion">
										<div class="cko-flow__saved-cards-accordion-header">
											<div class="cko-flow__saved-cards-accordion-left">
												<div class="cko-flow__saved-cards-icon">
													<svg width="40" height="24" viewBox="0 0 40 24" xmlns="http://www.w3.org/2000/svg" fill="none">
														<rect x="0.5" y="0.5" width="39" height="23" rx="3.5" stroke="#186aff"></rect>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M26.8571 6.85714H13.1428V17.1429H26.8571V6.85714ZM12.2857 6V18H27.7143V6H12.2857Z" fill="#186aff"></path>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M26.8571 9.42857H13.1428V7.71429H26.8571V9.42857Z" fill="#186aff"></path>
														<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2857 15.4286H14.8571V14.5714H18.2857V15.4286Z" fill="#186aff"></path>
													</svg>
												</div>
												<div class="cko-flow__saved-cards-label">
													<span class="cko-flow__saved-cards-label-text">Saved cards</span>
													<span class="cko-flow__saved-cards-label-subtext">${totalCount} card${totalCount !== 1 ? 's' : ''} available</span>
												</div>
											</div>
										</div>
										<div class="cko-flow__saved-cards-accordion-panel">
											<!-- Saved payment methods will be moved here -->
										</div>
									</div>
								</div>
							`;
							
							// CRITICAL FIX: Insert accordion in a safe location that won't become flow-container
							// The payment method <li> structure is: radio, label, [accordion/payment_box]
							const $paymentMethodLi = $('.payment_method_wc_checkout_com_flow').first();
							const $label = $paymentMethodLi.find('label').first();
							
							if (displayOrder === 'saved_cards_first') {
								// Insert accordion AFTER the label, BEFORE any divs
								// This way it can never be mistaken for the payment_box div
								if ($label.length) {
									$label.after(accordionHTML);
									flowLog('Accordion inserted AFTER label (saved_cards_first)');
								} else {
									// Fallback: insert before first div
									const $firstDiv = $paymentMethodLi.children('div').first();
									if ($firstDiv.length) {
										$firstDiv.before(accordionHTML);
										flowLog('Accordion inserted BEFORE div (saved_cards_first fallback)');
									}
								}
							} else {
								// new_payment_first: Insert accordion AFTER the payment_box div (which contains flow-container)
								const $paymentBox = $paymentMethodLi.find('.payment_box').first();
								if ($paymentBox.length) {
									$paymentBox.after(accordionHTML);
									flowLog('Accordion inserted AFTER payment_box (new_payment_first)');
								} else {
									// Fallback: insert after label
									if ($label.length) {
										$label.after(accordionHTML);
										flowLog('Accordion inserted AFTER label (new_payment_first fallback)');
									}
								}
							}
							
							// Move saved payment methods into the accordion panel
							$savedMethods.each(function() {
								$(this).appendTo('.cko-flow__saved-cards-accordion-panel');
							});
							
							flowLog('Saved cards wrapped in accordion');
							
						// REMOVED: No default card selection - user must explicitly select a saved card
						// This prevents issues with default card detection
						flowLog('No default card selection - user must explicitly select');
						
						// Ensure no saved cards are auto-selected (remove any defaults)
						$('.cko-flow__saved-cards-accordion-panel input[name="wc-wc_checkout_com_flow-payment-token"]:not(#wc-wc_checkout_com_flow-payment-token-new)').prop('checked', false).removeAttr('checked');
						
						// Ensure "new" card option is selected by default
						const $newCardRadio = $('#wc-wc_checkout_com_flow-payment-token-new');
						if ($newCardRadio.length) {
							$newCardRadio.prop('checked', true);
							flowLog('"New card" option selected by default');
						}
						
						// Reset flags
						window.flowSavedCardSelected = false;
						window.flowUserInteracted = false;
						flowLog('Unchecked all saved cards and selected new payment method');
							
							// CRITICAL: After moving cards, ensure visibility rules are applied
							// Remove any inline display styles that might have been set during the move
							$('.cko-flow__saved-cards-accordion-container').each(function() {
								// Remove inline style to let CSS handle visibility
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from accordion container');
								}
							});
							
							$('.cko-flow__saved-cards-accordion-panel').each(function() {
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from accordion panel');
								}
							});
							
							$savedMethods.each(function() {
								if (this.style.display) {
									this.style.removeProperty('display');
									flowLog('Removed inline display style from saved methods');
								}
							});
							
							flowLog('CSS will handle visibility via data-saved-payment-order:', displayOrder);
						} else {
							flowLog('No insertion point found, retrying...');
							setTimeout(wrapSavedCardsInAccordion, 100);
						}
					}
				}
				
				// Try immediately and also set a timeout as fallback
				wrapSavedCardsInAccordion();
				setTimeout(wrapSavedCardsInAccordion, 500);
				
				// CRITICAL: Re-wrap saved cards after WooCommerce updates checkout
				// WooCommerce's updated_checkout event destroys and recreates the payment methods HTML
				// Use a flag to prevent multiple simultaneous executions
				let accordionRecreationInProgress = false;
				jQuery(document.body).on('updated_checkout', function() {
					// Prevent multiple simultaneous executions
					if (accordionRecreationInProgress) {
						flowLog('Accordion recreation already in progress, skipping...');
						return;
					}
					
					flowLog('updated_checkout fired - re-wrapping saved cards...');
					accordionRecreationInProgress = true;
					
					setTimeout(function() {
						// Check if accordion AND panel exist, and if saved methods are inside
						const $existingAccordion = $('.cko-flow__saved-cards-accordion-container');
						const $existingPanel = $('.cko-flow__saved-cards-accordion-panel');
						const $panelMethods = $('.cko-flow__saved-cards-accordion-panel .woocommerce-SavedPaymentMethods');
						const $allMethods = $('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');
						
						flowLog('After updated_checkout:', {
							accordion: $existingAccordion.length,
							panel: $existingPanel.length,
							methodsInPanel: $panelMethods.length,
							totalMethods: $allMethods.length
						});
						
						// Recreate if accordion doesn't exist OR panel is missing OR methods not in panel
						if ($existingAccordion.length === 0 || $existingPanel.length === 0 || ($allMethods.length > 0 && $panelMethods.length === 0)) {
							flowLog('Accordion incomplete after updated_checkout, recreating...');
							// Remove any incomplete accordion first
							$existingAccordion.remove();
							// Recreate with fresh saved methods
							wrapSavedCardsInAccordion();
						} else {
							flowLog('Accordion complete after updated_checkout');
						}
						
						// Reset flag after a delay to allow for any follow-up updates
						setTimeout(function() {
							accordionRecreationInProgress = false;
						}, 500);
					}, 100);
				});

					});

					// Don't hide save card checkbox on page load - let Flow component control it

					document.addEventListener('DOMContentLoaded', function () {
						const radios = document.querySelectorAll(
							'input[name="wc-wc_checkout_com_flow-payment-token"], input[name="wc-wc_checkout_com_cards-payment-token"]'
						);
						radios.forEach(radio => {
							radio.checked = false;
						});
					});
				</script>
				<?php endif; ?>

		<?php endif; ?>

		<?php if ( $order_pay_order_id === null ) : ?>
			<div id="cart-info" data-cart='<?php echo wp_json_encode( WC_Checkoutcom_Api_Request::get_cart_info(true) ); ?>'></div>
		<?php else : ?>
			<div id="order-pay-info" data-order-pay='<?php echo wp_json_encode( WC_Checkoutcom_Api_Request::get_order_info($order_pay_order_id, true) ); ?>'></div>
		<?php endif; ?>
		
		<!-- Skeleton loader for better UX while Flow component loads -->
		<div id="flow-skeleton" class="flow-skeleton-loader cko-flow__skeleton">
			<div class="flow-skeleton-line cko-flow__skeleton-line"></div>
			<div class="flow-skeleton-line cko-flow__skeleton-line"></div>
			<div class="flow-skeleton-line short cko-flow__skeleton-line cko-flow__skeleton-line--short"></div>
		</div>
		
	<!-- Inline script to immediately hide place order button before CSS/JS loads (prevents flash) -->
	<script>
		// Expose saved payment display order to JavaScript
		window.saved_payment = '<?php echo esc_js( $flow_saved_card ); ?>';
		// Debug logging flag for PHP-generated JavaScript
		// Use window object to prevent duplicate declaration errors
		if (typeof window.flowDebugLogging === 'undefined') {
			window.flowDebugLogging = <?php echo $flow_debug_logging ? 'true' : 'false'; ?>;
		}
		// Use window.flowDebugLogging directly and check for existing flowLog to avoid redeclaration errors
		if (typeof window.flowLog === 'undefined') {
			window.flowLog = window.flowDebugLogging ? console.log.bind(console, '[FLOW PHP]') : function() {};
		}
		// Use window.flowLog instead of const to avoid redeclaration
		var flowLog = window.flowLog;
		
		(function() {
			var displayOrder = '<?php echo esc_js( $flow_saved_card ); ?>';
			
			// CRITICAL: Set data attribute on body immediately for CSS targeting
			document.body.setAttribute('data-saved-payment-order', displayOrder);
			if (flowDebugLogging) console.log('[FLOW] Body data attribute set:', displayOrder);
			
			// This runs immediately, before DOMContentLoaded
			var checkButton = function() {
				var placeOrderBtn = document.getElementById('place_order');
				if (placeOrderBtn) {
					// Check if Flow is the selected/only payment method
					var flowRadio = document.getElementById('payment_method_wc_checkout_com_flow');
					if (flowRadio && flowRadio.checked) {
						// Get saved cards count
						var savedCardElements = document.querySelectorAll('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');
						var hasSavedCards = false;
						savedCardElements.forEach(function(el) {
							var count = parseInt(el.getAttribute('data-count') || '0', 10);
							if (count > 0) {
								hasSavedCards = true;
							}
						});
						
						// Use Case 1: saved_cards_first - Always show Place Order button immediately
						// Use Case 2: new_payment_first - Hide Place Order button until Flow is ready
						if (displayOrder === 'saved_cards_first' && hasSavedCards) {
							// Keep button visible (saved cards are already visible)
							if (flowDebugLogging) console.log('[FLOW BUTTON] Keeping Place Order button visible - saved_cards_first mode with saved cards');
						} else {
							// Hide button until Flow is ready
							placeOrderBtn.style.opacity = '0';
							placeOrderBtn.style.visibility = 'hidden';
							if (flowDebugLogging) console.log('[FLOW BUTTON] Hiding Place Order button - Display order:', displayOrder, 'Has saved cards:', hasSavedCards);
						}
					}
				}
			};
			
			// Run immediately
			checkButton();
			
			// Also run when DOM is ready (belt and suspenders)
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', checkButton);
			}
		})();
	</script>
		
		<input type="hidden" id="cko-flow-payment-id" name="cko-flow-payment-id" value="" />
		<input type="hidden" id="cko-flow-payment-type" name="cko-flow-payment-type" value="" />
		<input type="hidden" id="cko-flow-payment-session-id" name="cko-flow-payment-session-id" value="" />
		<input type="hidden" id="cko-flow-3ds-status" name="cko-flow-3ds-status" value="" />
		<input type="hidden" id="cko-flow-3ds-auth-id" name="cko-flow-3ds-auth-id" value="" />
		<input type="hidden" id="cko-flow-save-card-persist" name="cko-flow-save-card-persist" value="" />
		<?php 

		if ( ! is_user_logged_in() ) :
			?>
			<script>
				// Use var instead of const to prevent redeclaration errors when updated_checkout fires
				var targetNode = document.body;

				// Hide Saved payment method for non logged in users.
				// IMPORTANT: Hide the accordion container, not just the list inside
				// Only create observer if it doesn't already exist to prevent duplicates
				if (typeof window.flowGuestObserver === 'undefined') {
					window.flowGuestObserver = new MutationObserver((mutationsList, observer) => {
					// Hide the accordion container (which contains the saved cards)
					const $accordion = jQuery('.cko-flow__saved-cards-accordion-container');
					if ($accordion.length) {
						$accordion.hide();
						if (flowDebugLogging) console.log('[FLOW] Hiding saved cards accordion for non-logged-in user');
					}
					
					// Also hide any saved payment methods that aren't wrapped yet
					const $element = jQuery('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods');
					if ($element.length) {
						$element.hide();
					}
					
					// Keep observer running to catch late additions
				});

					const config = {
						childList: true,
						subtree: true
					};

					window.flowGuestObserver.observe(targetNode, config);
				}

				// Try to hide it immediately in case it's already present.
				jQuery('.cko-flow__saved-cards-accordion-container').hide();
				jQuery('.woocommerce-SavedPaymentMethods.wc-saved-payment-methods').hide();
			</script>
		<?php endif; ?>
		<?php

		// On the Add Payment Method page (My Account → Payment methods → Add payment method) the
		// sole purpose is to add a NEW card, so don't show the customer's existing saved cards or
		// the "save card for future purchases" checkbox (the card is saved regardless here).
		$is_add_pm_page = function_exists( 'is_add_payment_method_page' ) && is_add_payment_method_page();

		// check if saved card enable from module setting.
		if ( $save_card && ! $is_add_pm_page ) {
			// Show saved cards from BOTH Flow and Classic Cards gateways
			// No migration needed - backend already handles both token types
			$this->saved_payment_methods();
		}

		// Render Save Card input (hidden on the Add Payment Method page).
		if ( ! $is_add_pm_page ) {
			$this->element_form_save_card( $save_card );
		}
	}

	/**
	 * Override saved_payment_methods to show tokens from BOTH Flow and Classic Cards gateways.
	 * This allows merchants upgrading from Classic Cards to Flow to see their existing saved cards.
	 * No migration needed - the backend already handles both token types seamlessly.
	 *
	 * @since 5.0.0
	 * @return void
	 */
	public function saved_payment_methods() {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$user_id = get_current_user_id();

		// Get tokens from BOTH gateways
		$flow_tokens = WC_Payment_Tokens::get_customer_tokens( $user_id, $this->id );
		
		$classic_gateway = new WC_Gateway_Checkout_Com_Cards();
		$classic_tokens = WC_Payment_Tokens::get_customer_tokens( $user_id, $classic_gateway->id );

		// Merge both token arrays
		$all_tokens = array_merge( $flow_tokens, $classic_tokens );

		// Log token retrieval for debugging
		WC_Checkoutcom_Utility::logger( '=== MULTI-GATEWAY TOKEN RETRIEVAL ===' );
		WC_Checkoutcom_Utility::logger( 'User ID: ' . $user_id );
		WC_Checkoutcom_Utility::logger( 'Flow tokens found: ' . count( $flow_tokens ) );
		WC_Checkoutcom_Utility::logger( 'Classic Cards tokens found: ' . count( $classic_tokens ) );
		WC_Checkoutcom_Utility::logger( 'Total tokens (before dedup): ' . count( $all_tokens ) );

		if ( empty( $all_tokens ) ) {
			WC_Checkoutcom_Utility::logger( 'No saved cards found - skipping display' );
			return;
		}

		// Remove duplicates based on token value (source ID)
		$unique_tokens = array();
		$seen_tokens = array();
		foreach ( $all_tokens as $token ) {
			$token_value = $token->get_token();
			if ( ! in_array( $token_value, $seen_tokens, true ) ) {
				$unique_tokens[] = $token;
				$seen_tokens[] = $token_value;
			}
		}
		
		WC_Checkoutcom_Utility::logger( 'Unique tokens (after dedup): ' . count( $unique_tokens ) );
		WC_Checkoutcom_Utility::logger( '=== END MULTI-GATEWAY TOKEN RETRIEVAL ===' );

		// Display saved payment methods (without extra label - already handled by accordion)
		?>
		<ul class="woocommerce-SavedPaymentMethods wc-saved-payment-methods" data-count="<?php echo count( $unique_tokens ); ?>">
			<?php
			$default_token_id = WC_Payment_Tokens::get_customer_default_token( $user_id );
			foreach ( $unique_tokens as $token ) {
				$is_default = ( $token->get_id() == $default_token_id );
				$gateway_source = ( $token->get_gateway_id() === $this->id ) ? 'Flow' : 'Classic';
				?>
				<li class="woocommerce-SavedPaymentMethods-token">
					<input id="wc-<?php echo esc_attr( $this->id ); ?>-payment-token-<?php echo esc_attr( $token->get_id() ); ?>" 
						type="radio" 
						name="wc-<?php echo esc_attr( $this->id ); ?>-payment-token" 
						value="<?php echo esc_attr( $token->get_id() ); ?>" 
						<?php checked( $is_default, true ); ?> 
						class="woocommerce-SavedPaymentMethods-tokenInput" 
						data-gateway-source="<?php echo esc_attr( $gateway_source ); ?>" />
					<label for="wc-<?php echo esc_attr( $this->id ); ?>-payment-token-<?php echo esc_attr( $token->get_id() ); ?>">
						<?php echo esc_html( sprintf( __( '%s ending in %s (expires %s/%s)', 'checkout-com-unified-payments-api' ), $token->get_card_type(), $token->get_last4(), $token->get_expiry_month(), $token->get_expiry_year() ) ); ?>
						<?php if ( $is_default ) : ?>
							<span class="woocommerce-SavedPaymentMethods-token-default"><?php esc_html_e( '(default)', 'checkout-com-unified-payments-api' ); ?></span>
						<?php endif; ?>
					</label>
				</li>
				<?php
			}
			?>
			<li class="woocommerce-SavedPaymentMethods-new">
				<input id="wc-<?php echo esc_attr( $this->id ); ?>-payment-token-new" 
					type="radio" 
					name="wc-<?php echo esc_attr( $this->id ); ?>-payment-token" 
					value="new" 
					<?php checked( empty( $default_token_id ), true ); ?> />
				<label for="wc-<?php echo esc_attr( $this->id ); ?>-payment-token-new">
					<?php esc_html_e( 'Use a new payment method', 'checkout-com-unified-payments-api' ); ?>
				</label>
			</li>
		</ul>
		<?php
	}

	/**
	 * Handle a WooCommerce Subscriptions "Change payment method" request.
	 *
	 * WCS calls process_payment() with the WC_Subscription as the order when a customer or admin
	 * updates the card on an active subscription. The normal process_payment() flow is invalid for
	 * a subscription object (order statuses, stock, cart, amount validation), so process_payment()
	 * routes here instead. We:
	 *   1. Fetch the verification payment's details to get the new card's source.id + scheme.
	 *   2. Persist them on the subscription so future MIT renewals charge the new card.
	 *   3. Best-effort void the verification authorisation (the session is created amount=0/
	 *      capture:false, so there is usually nothing to void — purely defensive).
	 *   4. Return success so WCS switches the subscription's stored payment method.
	 *
	 * @param WC_Subscription $subscription    The subscription whose card is being changed.
	 * @param string          $flow_payment_id Checkout.com payment id from the new-card verification.
	 * @return array WC process_payment response.
	 */
	public function handle_subscription_payment_method_change( $subscription, $flow_payment_id ) {
		$subscription_id = $subscription->get_id();
		WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] Handling subscription card change — Subscription ID: ' . $subscription_id . ', payment_id: ' . ( $flow_payment_id ?: 'MISSING' ) );

		if ( empty( $flow_payment_id ) ) {
			WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] ERROR: No Flow payment id — cannot retrieve the new card source.' );
			WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Could not update the payment method. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			return array( 'result' => 'failure' );
		}

		// Fetch payment details via direct call — the REST endpoint needs a browser-scoped nonce
		// we don't have server-side (same pattern as flow_save_cards / the subscription source save).
		$request = new \WP_REST_Request( 'GET', '/ckoplugin/v1/payment-status' );
		$request->set_query_params( [ 'paymentId' => $flow_payment_id ] );
		$response = cko_get_payment_status( $request );
		$status   = $response instanceof \WP_REST_Response ? $response->get_status() : 500;
		$data     = $response instanceof \WP_REST_Response ? $response->get_data() : null;

		if ( $status >= 400 || ! is_array( $data ) || isset( $data['error'] ) || empty( $data['source']['id'] ) ) {
			$err = is_array( $data ) && isset( $data['error'] ) ? $data['error'] : 'Unknown error (HTTP ' . $status . ')';
			WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] ERROR: Could not fetch payment details: ' . $err );
			WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Could not verify the new card. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			return array( 'result' => 'failure' );
		}

		$source_id = $data['source']['id'];

		// Persist the new source on the subscription so future MIT renewals charge the new card.
		WC_Checkoutcom_Subscription::save_source_id( $subscription_id, $subscription, $source_id );
		if ( ! empty( $data['source']['scheme'] ) ) {
			$this->save_preferred_card_scheme( $subscription_id, $subscription, $data['source']['scheme'] );
		}
		// NOTE: deliberately do NOT store the verification's _cko_payment_id on the subscription —
		// doing so gives the payment webhooks another way to resolve the subscription as an "order"
		// (by payment id) and flip its status. The source_id is all renewals need.
		$subscription->save();
		WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] ✅ Saved new source_id ' . $source_id . ' on subscription ' . $subscription_id );

		// Best-effort void of the verification authorisation (amount=0 sessions usually have
		// nothing to void; this is defensive in case an auth was raised).
		$this->cko_flow_void_payment( $flow_payment_id );

		$subscription->add_order_note( __( 'Checkout.com: subscription payment method updated.', 'checkout-com-unified-payments-api' ) );

		return array(
			'result'   => 'success',
			'redirect' => $subscription->get_view_order_url(),
		);
	}

	/**
	 * WC API return handler for My Account → Payment methods → Add payment method.
	 *
	 * Flow redirects here (with cko-payment-id appended) once the $0 card verification completes —
	 * for both the no-3DS and post-3DS paths. We fetch the verified card's source, save it as a
	 * WC_Payment_Token_CC against the logged-in user, best-effort void the (zero-amount) auth, and
	 * redirect back to the Payment methods page. No order is involved, so there is no status/stock.
	 *
	 * @return void
	 */
	public function handle_add_payment_method_return() {
		$payment_methods_url = wc_get_account_endpoint_url( 'payment-methods' );

		// Must be logged in.
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wc_get_page_permalink( 'myaccount' ) );
			exit;
		}

		// Verify nonce (issued in cko_flow_vars.save_card_nonce).
		$nonce = isset( $_GET['cko-apm-nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-apm-nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cko_flow_save_card' ) ) {
			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ERROR: invalid/missing nonce on return.' );
			wc_add_notice( __( 'Security check failed. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			wp_safe_redirect( $payment_methods_url );
			exit;
		}

		// Explicit failure return from Flow.
		if ( ! empty( $_GET['cko-apm-failed'] ) ) {
			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] Flow returned failure — card not added.' );
			wc_add_notice( __( 'The card could not be verified. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			wp_safe_redirect( wc_get_endpoint_url( 'add-payment-method', '', wc_get_page_permalink( 'myaccount' ) ) );
			exit;
		}

		$payment_id = isset( $_GET['cko-payment-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-id'] ) ) : '';
		if ( empty( $payment_id ) ) {
			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ERROR: missing cko-payment-id on return.' );
			wc_add_notice( __( 'Could not add the card. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			wp_safe_redirect( $payment_methods_url );
			exit;
		}

		$user_id = get_current_user_id();
		WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] Return — user_id=' . $user_id . ', payment_id=' . $payment_id );

		// Fetch payment details (direct call — REST endpoint needs a browser nonce we don't have).
		$request = new \WP_REST_Request( 'GET', '/ckoplugin/v1/payment-status' );
		$request->set_query_params( [ 'paymentId' => $payment_id ] );
		$response = cko_get_payment_status( $request );
		$status   = $response instanceof \WP_REST_Response ? $response->get_status() : 500;
		$data     = $response instanceof \WP_REST_Response ? $response->get_data() : null;

		if ( $status >= 400 || ! is_array( $data ) || isset( $data['error'] ) || empty( $data['source']['id'] ) ) {
			$err = is_array( $data ) && isset( $data['error'] ) ? $data['error'] : 'Unknown error (HTTP ' . $status . ')';
			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ERROR: could not fetch card details: ' . $err );
			wc_add_notice( __( 'Could not retrieve the card details. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			wp_safe_redirect( $payment_methods_url );
			exit;
		}

		$source = $data['source'];

		// Duplicate check by fingerprint for this user + gateway.
		if ( ! empty( $source['fingerprint'] ) ) {
			$existing_tokens = WC_Payment_Tokens::get_tokens( array(
				'user_id'    => $user_id,
				'gateway_id' => $this->id,
				'limit'      => 100,
			) );
			foreach ( $existing_tokens as $existing_token ) {
				if ( $existing_token->get_meta( 'fingerprint', true ) === $source['fingerprint'] ) {
					WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] Card already saved (fingerprint match) — voiding placeholder.' );
					$this->cko_flow_void_payment( $payment_id );
					wc_add_notice( __( 'This card is already saved to your account.', 'checkout-com-unified-payments-api' ), 'notice' );
					wp_safe_redirect( $payment_methods_url );
					exit;
				}
			}
		}

		// Save the token.
		try {
			$token = new WC_Payment_Token_CC();
			$token->set_token( (string) $source['id'] );
			$token->set_gateway_id( $this->id );
			$token->set_card_type( isset( $source['scheme'] ) ? strtolower( (string) $source['scheme'] ) : '' );
			$token->set_last4( isset( $source['last4'] ) ? (string) $source['last4'] : '' );
			$token->set_expiry_month( isset( $source['expiry_month'] ) ? sprintf( '%02d', (int) $source['expiry_month'] ) : '' );
			$token->set_expiry_year( isset( $source['expiry_year'] ) ? (string) $source['expiry_year'] : '' );
			$token->set_user_id( $user_id );
			if ( ! empty( $source['fingerprint'] ) ) {
				$token->add_meta_data( 'fingerprint', $source['fingerprint'], true );
			}

			if ( ! $token->save() ) {
				WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ERROR: token save returned falsy.' );
				wc_add_notice( __( 'Could not save the card. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				wp_safe_redirect( $payment_methods_url );
				exit;
			}

			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ✅ Saved token id=' . $token->get_id() . ' for user ' . $user_id );
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[ADD PAYMENT METHOD] ERROR: exception saving token: ' . $e->getMessage() );
			wc_add_notice( __( 'Could not save the card. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			wp_safe_redirect( $payment_methods_url );
			exit;
		}

		// Best-effort void of the $0 verification auth (usually nothing to void).
		$this->cko_flow_void_payment( $payment_id );

		wc_add_notice( __( 'Payment method successfully added.', 'checkout-com-unified-payments-api' ), 'success' );
		wp_safe_redirect( $payment_methods_url );
		exit;
	}

	/**
	 * Best-effort void of a Checkout.com authorisation. Used by the subscription change-payment
	 * flow to release any hold left by a card-verification session. Errors are logged, not thrown.
	 *
	 * @param string $payment_id Checkout.com payment id (e.g. pay_xxx).
	 * @return bool True on HTTP 2xx.
	 */
	protected function cko_flow_void_payment( $payment_id ) {
		if ( empty( $payment_id ) ) {
			return false;
		}

		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );

		$secret_key = isset( $core_settings['ckocom_sk'] ) ? $core_settings['ckocom_sk'] : '';
		if ( empty( $secret_key ) ) {
			WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] Void skipped — secret key not configured.' );
			return false;
		}

		$env  = isset( $core_settings['ckocom_environment'] ) ? $core_settings['ckocom_environment'] : 'sandbox';
		$base = ( 'sandbox' === $env ) ? 'https://api.sandbox.checkout.com' : 'https://api.checkout.com';

		$response = wp_remote_post( $base . '/payments/' . rawurlencode( $payment_id ) . '/voids', array(
			'timeout' => 15,
			'headers' => array(
				'Authorization' => 'Bearer ' . $secret_key,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( array( 'reference' => 'subscription-card-change-verification-void' ) ),
		) );

		if ( is_wp_error( $response ) ) {
			WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] Void request failed: ' . $response->get_error_message() );
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		WC_Checkoutcom_Utility::logger( '[CHANGE PAYMENT METHOD] Void of ' . $payment_id . ' returned HTTP ' . $code );
		return $code >= 200 && $code < 300;
	}

	/**
	 * Process payment with card payment.
	 *
	 * @param int $order_id Order ID.
	 * @return array|void
	 */

	public function process_payment( $order_id ) {
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order ID: ' . $order_id );

		if ( ! session_id() ) {
			session_start();
		}

		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ========== ENTRY POINT ==========' );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order ID: ' . $order_id );
		
		// Fetch payment details early (before order lookup) so we can use them as fallback if order lookup fails
		$flow_payment_id_from_post = isset( $_POST['cko-flow-payment-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-id'] ) ) : '';
		$payment_details = null;
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] flow_payment_id_from_post: ' . $flow_payment_id_from_post );
		
		if ( ! empty( $flow_payment_id_from_post ) ) {
			try {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Fetching payment details early (before order lookup) - Payment ID: ' . $flow_payment_id_from_post );
				$checkout = new Checkout_SDK();
				$builder = $checkout->get_builder();
				
				if ( $builder ) {
					$payment_details = $builder->getPaymentsClient()->getPaymentDetails( $flow_payment_id_from_post );
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment details fetched successfully (early fetch) - Payment ID: ' . $flow_payment_id_from_post );
					// Log payment session ID if available in metadata
					if ( isset( $payment_details['metadata']['cko_payment_session_id'] ) ) {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment session ID found in early fetch: ' . substr( $payment_details['metadata']['cko_payment_session_id'], 0, 20 ) . '...' );
					} else {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ Payment session ID NOT found in early fetch metadata' );
					}
					// Log cardholder name from payment details
					if ( isset( $payment_details['source']['name'] ) ) {
						WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] Cardholder name from payment details (early fetch): ' . $payment_details['source']['name'] );
					} elseif ( isset( $payment_details['source']['cardholder_name'] ) ) {
						WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] Cardholder name from payment details (early fetch): ' . $payment_details['source']['cardholder_name'] );
					} else {
						WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] ⚠️ Cardholder name NOT found in payment details (early fetch). Available source keys: ' . ( isset( $payment_details['source'] ) ? implode( ', ', array_keys( $payment_details['source'] ) ) : 'source not set' ) );
					}
				}
			} catch ( Exception $e ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] WARNING: Failed to fetch payment details early: ' . $e->getMessage() . ' - will retry later if needed' );
				// Don't fail here - we'll retry later if needed
			}
		}
		
		if ( empty( $order_id ) ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ERROR: No order ID provided' );
			
			// Check if order was created via AJAX (early order creation)
			// Order ID might be in POST data or session
			$order_id_from_post = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
			if ( $order_id_from_post ) {
				$early_order = wc_get_order( $order_id_from_post );
				if ( $early_order && $early_order->get_status() === 'pending' ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Found order created via AJAX - Order ID: ' . $order_id_from_post );
					$order_id = $order_id_from_post;
					$order = $early_order;
				}
			}
			
			// If still no order ID, try to create minimal order from payment details as fallback
			if ( empty( $order_id ) && ! empty( $payment_details ) && ! empty( $flow_payment_id_from_post ) ) {
				try {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Attempting to create minimal order from payment details (no order ID provided)...' );
					$order = $this->create_minimal_order_from_payment_details( $flow_payment_id_from_post, $payment_details );
					
					if ( ! is_wp_error( $order ) && $order ) {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Minimal order created successfully (no order ID) - Order ID: ' . $order->get_id() );
						$order_id = $order->get_id();
						// Continue with normal flow - order now exists
					} else {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Failed to create minimal order: ' . ( is_wp_error( $order ) ? $order->get_error_message() : 'Unknown error' ) );
						WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
						return;
					}
				} catch ( Exception $fallback_exception ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Exception during minimal order creation: ' . $fallback_exception->getMessage() );
					WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
					return;
				}
			} else {
				WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				return;
			}
		}

		$order = wc_get_order( $order_id );
		
		if ( ! $order ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ERROR: Order ' . $order_id . ' does not exist' );
			
			// Try to create minimal order from payment details as fallback
			if ( ! empty( $payment_details ) && ! empty( $flow_payment_id_from_post ) ) {
				try {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Attempting to create minimal order from payment details (order not found)...' );
					$order = $this->create_minimal_order_from_payment_details( $flow_payment_id_from_post, $payment_details );
					
					if ( ! is_wp_error( $order ) && $order ) {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Minimal order created successfully (order not found) - Order ID: ' . $order->get_id() );
						$order_id = $order->get_id();
						// Continue with normal flow - order now exists
					} else {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Failed to create minimal order: ' . ( is_wp_error( $order ) ? $order->get_error_message() : 'Unknown error' ) );
						WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
						return;
					}
				} catch ( Exception $fallback_exception ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Exception during minimal order creation: ' . $fallback_exception->getMessage() );
					WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
					return;
				}
			} else {
				WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Order not found. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				return;
			}
		}

		// Order pre-creation mode: allow WooCommerce to create the order/subscription
		// without attempting to process payment yet (Flow will submit payment afterward).
		if ( isset( $_POST['cko_flow_precreate_order'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['cko_flow_precreate_order'] ) ) ) {
			WC_Checkoutcom_Utility::logger( '[FLOW PRECREATE] Skipping payment processing - order created via WC checkout for Flow.' );
			// Ensure order is pending (do not charge yet).
			if ( 'pending' !== $order->get_status() ) {
				$order->set_status( 'pending' );
				$order->save();
			}

			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( true ),
			);
		}

		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order found - ID: ' . $order->get_id() . ', Status: ' . $order->get_status() . ', Payment Method: ' . $order->get_payment_method() );
		
		// DEBUG: Log current address state BEFORE setting addresses
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] BEFORE setting addresses - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
		
		// CRITICAL: Set addresses consistently for both successful and failed payments
		// This ensures addresses are always visible regardless of payment outcome
		// Priority: 1) payment_details (if available), 2) POST data, 3) WC()->customer, 4) Preserve existing
		// Note: payment_details will be available after payment is fetched, so we'll call this again after fetching payment_details
		$this->set_order_addresses_consistently( $order );
		
		// CRITICAL: Add shipping from payment_details if available (from early fetch)
		if ( ! empty( $payment_details ) ) {
			$this->add_shipping_from_payment_details( $order, $payment_details );
		}
		
		// Save addresses immediately to ensure they persist
		$order->save();
		
		// DEBUG: Log address state AFTER setting and saving
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] AFTER setting addresses - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Set and saved billing and shipping addresses - Order ID: ' . $order_id );
		
		// DUPLICATE PREVENTION: Check if this order has already been processed
		$existing_transaction_id = $order->get_transaction_id();
		$flow_payment_id = isset( $_POST['cko-flow-payment-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-id'] ) ) : '';
		
		// Fallback 1: Get payment ID from GET parameter (from handle_3ds_return URL)
		if ( empty( $flow_payment_id ) && isset( $_GET['cko-payment-id'] ) ) {
			$flow_payment_id = sanitize_text_field( wp_unslash( $_GET['cko-payment-id'] ) );
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Payment ID retrieved from GET parameter: ' . $flow_payment_id );
		}
		
		// Fallback 2: Get payment ID from order metadata if not in POST/GET (webhook may have set it, or 3DS return stored it)
		if ( empty( $flow_payment_id ) ) {
			$flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			if ( empty( $flow_payment_id ) ) {
				$flow_payment_id = $order->get_meta( '_cko_payment_id' );
			}
			if ( ! empty( $flow_payment_id ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Payment ID retrieved from order metadata: ' . $flow_payment_id );
			}
		}
		
		// ── Subscription "Change payment method" (customer/admin) ──────────────────────────────
		// WCS hands process_payment() the WC_Subscription itself as $order when a customer or admin
		// changes the card on an existing subscription. The remainder of this method assumes a
		// normal order (it sets ORDER statuses like 'processing', reduces stock, empties the cart,
		// validates amount) — all invalid for a subscription, which is why it previously fataled
		// with "Unable to change subscription status to processing" and stranded the sub on-hold.
		// Route it to a dedicated, side-effect-free handler instead. The card-verification session
		// was built amount=0/capture:false in ajax_create_payment_session, so no charge occurs.
		if ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) {
			return $this->handle_subscription_payment_method_change( $order, $flow_payment_id );
		}

		if ( ! empty( $existing_transaction_id ) ) {
			WC_Checkoutcom_Utility::logger( 'DUPLICATE PREVENTION: Order ' . $order_id . ' already has transaction ID: ' . $existing_transaction_id . ' - skipping processing' );
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Payment ID check - POST: ' . ( isset( $_POST['cko-flow-payment-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-id'] ) ) : 'NOT SET' ) . ', Order meta _cko_flow_payment_id: ' . $order->get_meta( '_cko_flow_payment_id' ) . ', Order meta _cko_payment_id: ' . $order->get_meta( '_cko_payment_id' ) . ', Final flow_payment_id: ' . $flow_payment_id );
			
			// MULTI-TAB DETECTION: Check if this is a different payment attempt
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Just reading payment session ID
			$current_payment_session_id = isset( $_GET['cko-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-session-id'] ) ) : '';
			$order_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
			$incoming_payment_id = $flow_payment_id;
			$order_primary_payment_id = $order->get_meta( '_cko_payment_id' );
			
			// If this payment attempt has a different payment session ID or payment ID, it's from another tab
			$is_different_tab = false;
			if ( ! empty( $current_payment_session_id ) && ! empty( $order_payment_session_id ) && $current_payment_session_id !== $order_payment_session_id ) {
				$is_different_tab = true;
			}
			if ( ! empty( $incoming_payment_id ) && ! empty( $order_primary_payment_id ) && $incoming_payment_id !== $order_primary_payment_id ) {
				$is_different_tab = true;
			}
			
			if ( $is_different_tab ) {
				WC_Checkoutcom_Utility::logger( 
					sprintf(
						'[DUPLICATE PREVENTION] ⚠️ MULTI-TAB: Different payment attempt detected. Order PS: %s, Incoming PS: %s, Order Payment: %s, Incoming Payment: %s',
						$order_payment_session_id ? substr( $order_payment_session_id, 0, 20 ) : '(none)',
						$current_payment_session_id ? substr( $current_payment_session_id, 0, 20 ) : '(none)',
						$order_primary_payment_id ? substr( $order_primary_payment_id, 0, 20 ) : '(none)',
						$incoming_payment_id ? substr( $incoming_payment_id, 0, 20 ) : '(none)'
					)
				);
				
				// Add order note about the duplicate payment attempt from different tab
				$order->add_order_note(
					sprintf(
						__( 'Duplicate payment attempt from different tab/session blocked. This payment (ID: %s, Session: %s) was processed after another payment already completed for this order. The customer may have opened multiple checkout tabs.', 'checkout-com-unified-payments-api' ),
						$incoming_payment_id ? $incoming_payment_id : 'unknown',
						$current_payment_session_id ? $current_payment_session_id : 'unknown'
					)
				);
				
				// Update the payment attempt status in our tracking array
				$payment_attempts = $order->get_meta( '_cko_payment_attempts' );
				if ( ! empty( $payment_attempts ) && is_array( $payment_attempts ) ) {
					foreach ( $payment_attempts as $index => $attempt ) {
						if ( isset( $attempt['payment_id'] ) && $attempt['payment_id'] === $incoming_payment_id ) {
							$payment_attempts[ $index ]['status'] = 'duplicate_blocked';
							$payment_attempts[ $index ]['blocked_at'] = current_time( 'mysql' );
							$payment_attempts[ $index ]['blocked_reason'] = 'Order already processed by another payment';
							break;
						}
					}
					$order->update_meta_data( '_cko_payment_attempts', $payment_attempts );
				}
				
				$order->save();
			}
			
				// Still check for card saving even when duplicate prevention kicks in
				// The payment may have been processed by webhook, but card saving might not have run yet
			if ( ! empty( $flow_payment_id ) ) {
				// Get payment type from POST, GET, or order metadata
				$flow_payment_type_for_save = isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : '';
				if ( empty( $flow_payment_type_for_save ) && isset( $_GET['cko-payment-type'] ) ) {
					$flow_payment_type_for_save = sanitize_text_field( wp_unslash( $_GET['cko-payment-type'] ) );
				}
				if ( empty( $flow_payment_type_for_save ) ) {
					$flow_payment_type_for_save = $order->get_meta( '_cko_flow_payment_type' );
				}
				// Default to 'card' if still empty (most common case)
				if ( empty( $flow_payment_type_for_save ) ) {
					$flow_payment_type_for_save = 'card';
				}
				$save_card_enabled = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
				
				// Check order metadata first (stored before 3DS redirect - most reliable)
				$save_card_from_order = $order->get_meta( '_cko_save_card_preference' );
				
				// Check GET parameter (from URL after 3DS redirect)
				$save_card_from_get = isset( $_GET['cko-save-card'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-save-card'] ) ) : '';
				
				// Check hidden field (POST data - may not be available after 3DS redirect)
				$save_card_hidden = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
				
				// Fallback to POST checkbox
				$save_card_post = isset( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ) : '';
				
				// Fallback to session
				$save_card_session = WC()->session->get( 'wc-wc_checkout_com_flow-new-payment-method' );
				
				WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Checking save card preference - Order meta: ' . $save_card_from_order . ', GET: ' . $save_card_from_get . ', Hidden: ' . $save_card_hidden . ', POST: ' . $save_card_post . ', Session: ' . $save_card_session );
				
				// Determine if checkbox was checked (priority: order metadata > GET > hidden field > POST > session)
				$save_card_checkbox = false;
				if ( 'yes' === $save_card_from_order ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in order metadata: YES' );
				} elseif ( 'yes' === $save_card_from_get ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in GET parameter: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'yes' === $save_card_hidden ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in hidden field: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'true' === $save_card_post || 'yes' === $save_card_post ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in POST checkbox: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'yes' === $save_card_session ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in session: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				}
				
				WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Final check - Payment type: ' . $flow_payment_type_for_save . ', Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
				
				if ( 'card' === $flow_payment_type_for_save && $save_card_enabled && $save_card_checkbox ) {
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] ✅ All conditions met - calling flow_save_cards()' );
					$this->flow_save_cards( $order, $flow_payment_id );
					// Clear the session variable after processing
					WC()->session->__unset( 'wc-wc_checkout_com_flow-new-payment-method' );
				} else {
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] ❌ Conditions NOT met - Payment type: ' . $flow_payment_type_for_save . ' (expected: card), Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
				}
			}
			
			// CRITICAL FIX: Update order status if still 'failed' or 'pending'
			// When a retry payment succeeds, duplicate prevention triggers but order is still 'failed' from first attempt
			// IMPORTANT: Refresh order from database to get latest status (webhooks may have updated it)
			$order = wc_get_order( $order_id );
			$current_order_status_txn = $order->get_status();
			
			// NEVER downgrade orders that are already in a final/successful state
			$protected_statuses = array( 'processing', 'completed', 'on-hold' );
			if ( in_array( $current_order_status_txn, $protected_statuses, true ) ) {
				WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Order already in protected status: ' . $current_order_status_txn . ' - skipping status update to prevent downgrade. Order ID: ' . $order_id );
			} elseif ( 'failed' === $current_order_status_txn || 'pending' === $current_order_status_txn ) {
				$payment_authorized = $order->get_meta( 'cko_payment_authorized' );
				$payment_captured = $order->get_meta( 'cko_payment_captured' );
				
				// Determine if this is a retry payment (from failed) or just normal processing (from pending)
				$is_retry_payment_txn = ( 'failed' === $current_order_status_txn );
				
				if ( $payment_authorized || $payment_captured ) {
					$auth_status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
					$new_status = $payment_captured ? 'processing' : $auth_status;
					if ( $is_retry_payment_txn ) {
						$order->update_status( $new_status, __( 'Order status updated after successful retry payment.', 'checkout-com-unified-payments-api' ) );
					}
					// Don't add a note for pending->on-hold, the webhook note is sufficient
					WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] ✅ Updated order status from ' . $current_order_status_txn . ' to ' . $new_status . ' (transaction ID check) - Order ID: ' . $order_id );
				} else {
					$auth_status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
					if ( $is_retry_payment_txn ) {
						$order->update_status( $auth_status, __( 'Payment authorized (retry after previous failure).', 'checkout-com-unified-payments-api' ) );
					} else {
						// Fresh DB read before writing — a concurrent capture webhook may have already
						// advanced the order to on-hold/processing/completed between when we first read
						// the order and now. Writing on-hold over completed would be a regression.
						clean_post_cache( $order_id );
						$order        = wc_get_order( $order_id );
						$fresh_status = $order->get_status();
						if ( in_array( $fresh_status, array( 'on-hold', 'processing', 'completed' ), true ) ) {
							WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Fresh DB read shows order already ' . $fresh_status . ' - skipping on-hold write to prevent overwrite. Order ID: ' . $order_id );
						} else {
							WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Fresh DB read confirms order still ' . $fresh_status . ' - proceeding with ' . $auth_status . ' write. Order ID: ' . $order_id );
							$order->set_status( $auth_status );
							$order->save();
						}
					}
					WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] ✅ Updated order status from ' . $current_order_status_txn . ' to ' . $auth_status . ' (no webhook yet, transaction ID check) - Order ID: ' . $order_id );
				}
			}
			
			// Return success to prevent error, but don't process again
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			);
		}
		
		// DUPLICATE PREVENTION: Check if this payment ID already has an order (global check)
		if ( ! empty( $flow_payment_id ) ) {
			// Check if payment ID already has an order (prevents duplicate orders)
			$existing_orders = wc_get_orders( array(
				'limit'      => 1,
				'meta_key'   => '_cko_payment_id',
				'meta_value' => $flow_payment_id,
				'return'     => 'objects',
			) );
			
			if ( ! empty( $existing_orders ) ) {
				$existing_order = $existing_orders[0];
				if ( $existing_order->get_id() !== $order_id ) {
					WC_Checkoutcom_Utility::logger( 'DUPLICATE PREVENTION: Payment ID ' . $flow_payment_id . ' already has order ' . $existing_order->get_id() . ' - reusing existing order instead of ' . $order_id );
					$order = $existing_order;
					$order_id = $order->get_id();
				}
			}
			
			// Check if current order already processed with this payment ID
			$existing_payment = $order->get_meta( '_cko_payment_id' );
			if ( $existing_payment === $flow_payment_id ) {
				WC_Checkoutcom_Utility::logger( 'DUPLICATE PREVENTION: Order ' . $order_id . ' already processed with payment ID: ' . $flow_payment_id . ' - skipping processing' );
				
				// CRITICAL: Still check for card saving even when duplicate prevention kicks in
				// Get payment type from POST, GET, or order metadata
				$flow_payment_type_for_save = isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : '';
				if ( empty( $flow_payment_type_for_save ) && isset( $_GET['cko-payment-type'] ) ) {
					$flow_payment_type_for_save = sanitize_text_field( wp_unslash( $_GET['cko-payment-type'] ) );
				}
				if ( empty( $flow_payment_type_for_save ) ) {
					$flow_payment_type_for_save = $order->get_meta( '_cko_flow_payment_type' );
				}
				// Default to 'card' if still empty (most common case)
				if ( empty( $flow_payment_type_for_save ) ) {
					$flow_payment_type_for_save = 'card';
				}
				$save_card_enabled = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
				
				// Check order metadata first (stored before 3DS redirect - most reliable)
				$save_card_from_order = $order->get_meta( '_cko_save_card_preference' );
				
				// Check GET parameter (from URL after 3DS redirect)
				$save_card_from_get = isset( $_GET['cko-save-card'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-save-card'] ) ) : '';
				
				// Check hidden field (POST data - may not be available after 3DS redirect)
				$save_card_hidden = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
				
				// Fallback to POST checkbox
				$save_card_post = isset( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ) : '';
				
				// Fallback to session
				$save_card_session = WC()->session->get( 'wc-wc_checkout_com_flow-new-payment-method' );
				
				WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Checking save card preference - Order meta: ' . $save_card_from_order . ', GET: ' . $save_card_from_get . ', Hidden: ' . $save_card_hidden . ', POST: ' . $save_card_post . ', Session: ' . $save_card_session );
				
				// Determine if checkbox was checked (priority: order metadata > GET > hidden field > POST > session)
				$save_card_checkbox = false;
				if ( 'yes' === $save_card_from_order ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in order metadata: YES' );
				} elseif ( 'yes' === $save_card_from_get ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in GET parameter: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'yes' === $save_card_hidden ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in hidden field: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'true' === $save_card_post || 'yes' === $save_card_post ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in POST checkbox: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				} elseif ( 'yes' === $save_card_session ) {
					$save_card_checkbox = true;
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Save card preference found in session: YES' );
					$order->update_meta_data( '_cko_save_card_preference', 'yes' );
					$order->save();
				}
				
				WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] Final check - Payment type: ' . $flow_payment_type_for_save . ', Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
				
				if ( 'card' === $flow_payment_type_for_save && $save_card_enabled && $save_card_checkbox ) {
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] ✅ All conditions met - calling flow_save_cards()' );
					$this->flow_save_cards( $order, $flow_payment_id );
					// Clear the session variable after processing
					WC()->session->__unset( 'wc-wc_checkout_com_flow-new-payment-method' );
				} else {
					WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] [DUPLICATE PREVENTION] ❌ Conditions NOT met - Payment type: ' . $flow_payment_type_for_save . ' (expected: card), Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
				}
				
				// CRITICAL FIX: Clear any error notices from previous failed payment attempts
				// This prevents stale error messages from showing on the success page after a retry payment succeeds
				if ( function_exists( 'wc_clear_notices' ) ) {
					wc_clear_notices();
					WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Cleared WooCommerce notices before success redirect (prevents stale error messages from failed retries)' );
				}
				
				// CRITICAL FIX: Update order status if still 'failed' or 'pending'
				// When a retry payment succeeds, duplicate prevention triggers but order is still 'failed' from first attempt
				// This causes WooCommerce to show "payment declined" message on order-received page
				// IMPORTANT: Refresh order from database to get latest status (webhooks may have updated it)
				$order = wc_get_order( $order_id );
				$current_order_status = $order->get_status();
				
				// NEVER downgrade orders that are already in a final/successful state
				$protected_statuses = array( 'processing', 'completed', 'on-hold' );
				if ( in_array( $current_order_status, $protected_statuses, true ) ) {
					WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Order already in protected status: ' . $current_order_status . ' - skipping status update to prevent downgrade. Order ID: ' . $order_id );
				} elseif ( 'failed' === $current_order_status || 'pending' === $current_order_status ) {
					// Check if payment was actually approved (via order meta set by webhook or API verification)
					$payment_authorized = $order->get_meta( 'cko_payment_authorized' );
					$payment_captured = $order->get_meta( 'cko_payment_captured' );
					
					// Determine if this is a retry payment (from failed) or just normal processing (from pending)
					$is_retry_payment = ( 'failed' === $current_order_status );
					
					if ( $payment_authorized || $payment_captured ) {
						$auth_status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
						$new_status = $payment_captured ? 'processing' : $auth_status;
						if ( $is_retry_payment ) {
							$order->update_status( $new_status, __( 'Order status updated after successful retry payment.', 'checkout-com-unified-payments-api' ) );
						}
						// Don't add a note for pending->on-hold, the webhook note is sufficient
						WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] ✅ Updated order status from ' . $current_order_status . ' to ' . $new_status . ' - Order ID: ' . $order_id );
					} else {
						// No webhook received yet - set to authorized status anyway since payment ID exists and we're returning success
						// Webhook will update to processing when captured
						$auth_status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
						if ( $is_retry_payment ) {
							$order->update_status( $auth_status, __( 'Payment authorized (retry after previous failure).', 'checkout-com-unified-payments-api' ) );
						} else {
							// Fresh DB read before writing — a concurrent capture webhook may have already
							// advanced the order to on-hold/processing/completed between when we first read
							// the order and now. Writing on-hold over completed would be a regression.
							clean_post_cache( $order_id );
							$order        = wc_get_order( $order_id );
							$fresh_status = $order->get_status();
							if ( in_array( $fresh_status, array( 'on-hold', 'processing', 'completed' ), true ) ) {
								WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Fresh DB read shows order already ' . $fresh_status . ' - skipping on-hold write to prevent overwrite. Order ID: ' . $order_id );
							} else {
								WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] Fresh DB read confirms order still ' . $fresh_status . ' - proceeding with ' . $auth_status . ' write. Order ID: ' . $order_id );
								$order->set_status( $auth_status );
								$order->save();
							}
						}
						WC_Checkoutcom_Utility::logger( '[DUPLICATE PREVENTION] ✅ Updated order status from ' . $current_order_status . ' to ' . $auth_status . ' (no webhook yet) - Order ID: ' . $order_id );
					}
				}
				
				// Return success to prevent error, but don't process again
				return array(
					'result'   => 'success',
					'redirect' => $this->get_return_url( $order ),
				);
			}
		}
		
	$flow_result = null;

	$subs_payment_type = null;

	// 3DS RETURN HANDLER: If we already have a payment ID from Flow (after 3DS redirect),
	// don't create a new payment - just fetch the payment details and complete the order
	// CRITICAL FIX: Check for payment type from GET, POST, or order metadata (not just POST)
	// After 3DS redirect, POST is empty, so we need to check GET and order meta
	$flow_payment_type_for_3ds_check = isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : '';
	if ( empty( $flow_payment_type_for_3ds_check ) && isset( $_GET['cko-payment-type'] ) ) {
		$flow_payment_type_for_3ds_check = sanitize_text_field( wp_unslash( $_GET['cko-payment-type'] ) );
	}
	if ( empty( $flow_payment_type_for_3ds_check ) && $order ) {
		$flow_payment_type_for_3ds_check = $order->get_meta( '_cko_flow_payment_type' );
	}
	// Default to 'card' if still empty (most common case for Flow payments)
	if ( empty( $flow_payment_type_for_3ds_check ) ) {
		$flow_payment_type_for_3ds_check = 'card';
	}
	
	// CRITICAL FIX: Enter 3DS handler if we have payment ID from GET (3DS return) OR from POST
	// Payment type can be defaulted to 'card' if not found
	$is_3ds_return = ! empty( $flow_payment_id ) && ( isset( $_GET['cko-payment-id'] ) || isset( $_POST['cko-flow-payment-id'] ) );
	
	if ( $is_3ds_return ) {
		// Payment type will be handled below with wp_unslash()
		
	// Fetch the payment details from Checkout.com to verify and get status
		try {
		$checkout = new Checkout_SDK();
		$builder = $checkout->get_builder();
		
		// Check if SDK was properly initialized
		if ( ! $builder ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] WARNING: Checkout.com SDK not initialized - vendor/autoload.php may be missing' );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] For Flow payments, payment details are handled via webhooks, so this may not be critical' );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Creating mock result with payment ID: ' . $flow_payment_id );
			
			// For Flow payments, when SDK is not available, create a mock result
			// Flow handles payment approval client-side, so we assume it's approved
			// Webhooks will verify the final status
			$result = array(
				'id' => $flow_payment_id,
				'action_id' => $flow_payment_id,
				'status' => 'Authorized', // Assume authorized since Flow component handled it
				'approved' => true, // Assume approved - Flow component handles approval client-side
				'response_code' => '10000', // Success code
				'response_summary' => 'Approved', // Success summary
				'3d' => null, // No 3DS redirect needed, we're returning from 3DS
			);
			
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Using mock result (SDK unavailable) - Payment ID: ' . $flow_payment_id . ', Approved: true' );
			// Set payment_details to the mock result for consistency
			$payment_details = $result;
		} else {
			$payment_details = $builder->getPaymentsClient()->getPaymentDetails( $flow_payment_id );
			
			// Log cardholder name from payment details
			if ( isset( $payment_details['source']['name'] ) ) {
				WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] Cardholder name from payment details (3DS return): ' . $payment_details['source']['name'] );
			} elseif ( isset( $payment_details['source']['cardholder_name'] ) ) {
				WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] Cardholder name from payment details (3DS return): ' . $payment_details['source']['cardholder_name'] );
			} else {
				WC_Checkoutcom_Utility::logger( '[CARDHOLDER NAME] ⚠️ Cardholder name NOT found in payment details (3DS return). Available source keys: ' . ( isset( $payment_details['source'] ) ? implode( ', ', array_keys( $payment_details['source'] ) ) : 'source not set' ) );
			}
			
			// Convert to result format expected by the rest of the code
			$result = array(
				'id' => $payment_details['id'],
				'action_id' => isset( $payment_details['actions'][0]['id'] ) ? $payment_details['actions'][0]['id'] : '',
				'status' => $payment_details['status'],
				'approved' => isset( $payment_details['approved'] ) ? $payment_details['approved'] : false,
				'response_code' => isset( $payment_details['response_code'] ) ? $payment_details['response_code'] : '',
				'response_summary' => isset( $payment_details['response_summary'] ) ? $payment_details['response_summary'] : '',
				'3d' => null, // No 3DS redirect needed, we're returning from 3DS
			);
		}
		
		// CRITICAL: Check if payment is approved before processing
		// If payment_details is null (SDK not available), check if we have a payment ID
		// For Flow payments, if payment ID exists, payment was processed by Flow component
		if ( empty( $payment_details ) && ! empty( $flow_payment_id ) ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment details not available (SDK missing), but payment ID exists: ' . $flow_payment_id );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Assuming payment approved - Flow component handles approval client-side, webhooks will verify' );
			$is_approved = true; // Assume approved if payment ID exists and SDK unavailable
		} else {
			$is_approved = isset( $result['approved'] ) ? $result['approved'] : ( isset( $payment_details['approved'] ) ? $payment_details['approved'] : false );
		}
		
		if ( ! $is_approved ) {
			// PERFORMANCE: Only log verbose details in debug mode
			$is_debug = defined( 'WP_DEBUG' ) && WP_DEBUG;
			
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment not approved (3DS return) - Order ID: ' . $order_id . ', Payment ID: ' . $flow_payment_id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment details: ' . wp_json_encode( $payment_details, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			}
			
			// CRITICAL: Set addresses consistently for failed payments (same logic as successful payments)
			// This ensures addresses are always visible regardless of payment outcome
			// Priority: 1) payment_details (if available), 2) POST data, 3) WC()->customer, 4) Preserve existing
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] Payment failed - Setting addresses consistently' );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] Payment details available: ' . ( $payment_details ? 'YES' : 'NO' ) . ', billing_address in payment_details: ' . ( isset( $payment_details['billing_address'] ) ? 'YES' : 'NO' ) );
			}
			$this->set_order_addresses_consistently( $order, $payment_details );
			
			// Set transaction ID and payment ID in order meta for tracking
			$order->set_transaction_id( $result['action_id'] );
			$order->update_meta_data( '_cko_payment_id', $flow_payment_id );
			
			// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			if ( empty( $existing_flow_payment_id ) ) {
				$order->update_meta_data( '_cko_flow_payment_id', $flow_payment_id );
			} else {
				WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment ID already exists in order (failed payment) - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $flow_payment_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
			}
			
			// Save addresses BEFORE marking as failed
			$order->save();
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] Addresses saved BEFORE marking as failed - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
			}
			
			// Get error message from payment details if available
			$error_message = __( 'Payment was not approved. Please try again.', 'checkout-com-unified-payments-api' );
			if ( isset( $payment_details['response_summary'] ) && ! empty( $payment_details['response_summary'] ) ) {
				$error_message = $payment_details['response_summary'];
			} elseif ( isset( $payment_details['status'] ) ) {
				$error_message = sprintf( __( 'Payment failed with status: %s', 'checkout-com-unified-payments-api' ), $payment_details['status'] );
			}
			
			// Update order status to failed
			$order->update_status( 'failed', __( 'Payment was not approved by Checkout.com', 'checkout-com-unified-payments-api' ) );
			$order->add_order_note( sprintf( __( 'Payment declined - Payment ID: %s, Reason: %s', 'checkout-com-unified-payments-api' ), $flow_payment_id, $error_message ) );
			
			// Save order again after marking as failed
			$order->save();
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] Addresses saved AFTER marking as failed - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
			}
			
			// Add error notice
			WC_Checkoutcom_Utility::wc_add_notice_self( $error_message, 'error' );
			
			// Return error - don't proceed with success flow
			return;
		}
		
		// CRITICAL: Update addresses from payment_details for successful payments (if available)
		// This ensures we have the most accurate addresses from Checkout.com API
		// Priority: 1) payment_details (most accurate), 2) POST data, 3) WC()->customer, 4) Preserve existing
		if ( isset( $payment_details ) ) {
			$this->set_order_addresses_consistently( $order, $payment_details );
			// CRITICAL: Add shipping from payment_details items if not already present
			$this->add_shipping_from_payment_details( $order, $payment_details );
			$order->save(); // Save addresses before proceeding
		} else {
		}
		
		// Set transaction ID and payment ID in order meta
			$order->set_transaction_id( $result['action_id'] );
			$order->update_meta_data( '_cko_payment_id', $flow_payment_id );
			
			// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			if ( empty( $existing_flow_payment_id ) ) {
				$order->update_meta_data( '_cko_flow_payment_id', $flow_payment_id );
			} else {
				WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment ID already exists in order - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $flow_payment_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
			}
			
			// Use the payment type we already retrieved for the 3DS check (from POST, GET, or order meta)
			$flow_payment_type = $flow_payment_type_for_3ds_check;
			// Fallback: Get payment type from payment_details if not found elsewhere
			// CRITICAL: Check card_wallet_type FIRST before checking payment_type
			// Google Pay/Apple Pay have payment_type="Regular" but card_wallet_type="GooglePay"/"ApplePay"
			if ( empty( $flow_payment_type ) && ! empty( $payment_details ) ) {
				if ( isset( $payment_details['source']['card_wallet_type'] ) ) {
					$card_wallet_type = strtolower( $payment_details['source']['card_wallet_type'] );
					if ( $card_wallet_type === 'googlepay' ) {
						$flow_payment_type = 'googlepay';
					} elseif ( $card_wallet_type === 'applepay' ) {
						$flow_payment_type = 'applepay';
					}
				}
				// If card_wallet_type didn't identify it, check payment_type
				if ( empty( $flow_payment_type ) && isset( $payment_details['payment_type'] ) ) {
					$payment_type_raw = $payment_details['payment_type'];
					// CRITICAL FIX: When payment_type is "Regular", check source.type FIRST before normalizing to "card"
					// For APMs (Alma, PayPal, etc.), payment_type="Regular" but source.type="alma"/"paypal"/etc.
					if ( strtolower( $payment_type_raw ) === 'regular' ) {
						// Check if source.type exists and is NOT "card" (i.e., it's an APM)
						if ( isset( $payment_details['source']['type'] ) && strtolower( $payment_details['source']['type'] ) !== 'card' ) {
							$flow_payment_type = strtolower( $payment_details['source']['type'] );
						} else {
							// No source.type or source.type is "card" - normalize to "card"
							$flow_payment_type = 'card';
						}
					} else {
						$flow_payment_type = $payment_type_raw;
					}
				} elseif ( empty( $flow_payment_type ) && isset( $payment_details['source']['type'] ) ) {
					$flow_payment_type = $payment_details['source']['type'];
				}
			}
			if ( empty( $flow_payment_type ) ) {
				$flow_payment_type = 'card'; // Default fallback
			}
			$order->update_meta_data( '_cko_flow_payment_type', $flow_payment_type );
			
			// Set payment method title based on actual payment type used
			$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Setting payment method title - Location: process_payment() successful payment path around line 2054' );
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order ID: ' . $order->get_id() );
			}
			$payment_method_title = $this->get_payment_method_title_by_type( $order, $payment_details );
			$order->set_payment_method_title( $payment_method_title );
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ✅ Title set to: ' . $payment_method_title );
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order payment method title after setting: ' . $order->get_payment_method_title() );
			}
			
			// Store order number/reference for webhook lookup (works with Sequential Order Numbers plugins)
			$order->update_meta_data( '_cko_order_reference', $order->get_order_number() );
			
			// CRITICAL: Save payment session ID for webhook matching (METHOD 2)
			// Priority: 1) POST data (from form), 2) Payment metadata (from payment_details)
			// Only save if order doesn't already have a payment session ID
			$existing_order_session_id = $order->get_meta( '_cko_payment_session_id' );
			
			if ( empty( $existing_order_session_id ) ) {
				// Order doesn't have payment session ID yet - try to get it
				$payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) : '';
				if ( empty( $payment_session_id ) && isset( $payment_details['metadata']['cko_payment_session_id'] ) ) {
					$payment_session_id = $payment_details['metadata']['cko_payment_session_id'];
					WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment session ID retrieved from payment_details metadata: ' . substr( $payment_session_id, 0, 20 ) . '...' );
				}
				
				if ( ! empty( $payment_session_id ) ) {
					// Check if payment_session_id already exists in another order (prevent duplicates)
					$existing_orders = wc_get_orders( array(
						'meta_key'   => '_cko_payment_session_id',
						'meta_value' => $payment_session_id,
						'limit'      => 1,
						'exclude'    => array( $order_id ),
						'return'     => 'ids',
					) );
					
					if ( ! empty( $existing_orders ) ) {
						WC_Checkoutcom_Utility::logger( '[3DS RETURN] ❌ CRITICAL ERROR: Payment session ID already used by order: ' . $existing_orders[0] );
					} else {
						$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
						WC_Checkoutcom_Utility::logger( '[3DS RETURN] ✅ Saved payment session ID to order - Order ID: ' . $order_id . ', Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '...' );
					}
				} else {
					WC_Checkoutcom_Utility::logger( '[3DS RETURN] ⚠️ WARNING: Payment session ID is empty - Order ID: ' . $order_id . ', Payment ID: ' . $flow_payment_id );
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment session ID already exists in order - Order ID: ' . $order_id . ', Payment Session ID: ' . substr( $existing_order_session_id, 0, 20 ) . '... (skipping save)' );
			}
			
			// CRITICAL: Save order immediately so webhooks can find it (especially for fast APM payments)
			$order->save();
			WC_Checkoutcom_Utility::logger( 'Order meta saved immediately for webhook lookup (3DS return) - Order ID: ' . $order_id . ', Payment ID: ' . $flow_payment_id );
			
		// Process any pending webhooks for this order
		if ( class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
			WC_Checkout_Com_Webhook_Queue::process_pending_webhooks_for_order( $order );
		}
		
		// CRITICAL: Reload order object after webhook processing to get latest status and meta
		// Webhooks may have updated the order status/meta, but the order object in memory is stale
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			WC_Checkoutcom_Utility::logger( '[3DS RETURN] ERROR: Order not found after webhook processing - Order ID: ' . $order_id );
			return;
		}
		
	// Set variables for card saving logic below
	$flow_pay_id = $flow_payment_id;
	
	// Check if payment is already captured or authorized (webhook may have arrived first)
	$already_captured = $order->get_meta( 'cko_payment_captured' );
	$already_authorized = $order->get_meta( 'cko_payment_authorized' );
	$current_status = $order->get_status();
	$action_id = isset( $result['action_id'] ) ? $result['action_id'] : '';
	
	// Set status and message for the order
	// Skip status update if:
	// 1. Payment already captured (webhook set it to processing)
	// 2. Payment already authorized AND status is already on-hold/processing/completed (webhook already updated)
	// 3. Order is already in advanced state (processing/completed) - don't downgrade
	$auth_status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
	
	// Format order amount for notes
	$formatted_order_amount = wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) );
	
	if ( $already_captured ) {
		// Payment already captured - just add note, don't change status
		$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - using FLOW (3DS return): %s - Payment ID: %s, Amount: %s', 'checkout-com-unified-payments-api' ), $flow_payment_type, $flow_payment_id, $formatted_order_amount );
		$status = null; // Signal to skip status update
	} elseif ( $already_authorized && ( $current_status === $auth_status || in_array( $current_status, array( 'processing', 'completed' ), true ) ) ) {
		// Already authorized and status matches - webhook already handled it, just add note
		$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - using FLOW (3DS return): %s - Payment ID: %s, Amount: %s', 'checkout-com-unified-payments-api' ), $flow_payment_type, $flow_payment_id, $formatted_order_amount );
		$status = null; // Signal to skip status update
	} elseif ( in_array( $current_status, array( 'processing', 'completed' ), true ) ) {
		// Order already in advanced state - don't downgrade, just add note
		$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - using FLOW (3DS return): %s - Payment ID: %s, Amount: %s', 'checkout-com-unified-payments-api' ), $flow_payment_type, $flow_payment_id, $formatted_order_amount );
		$status = null; // Signal to skip status update
	} else {
		// Payment not yet processed - set status to authorized
		$status = $auth_status;
		$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - using FLOW (3DS return): %s - Payment ID: %s, Amount: %s', 'checkout-com-unified-payments-api' ), $flow_payment_type, $flow_payment_id, $formatted_order_amount );
		
		// Check if payment was flagged
		if ( isset( $result['risk']['flagged'] ) && $result['risk']['flagged'] ) {
			$status = WC_Admin_Settings::get_option( 'ckocom_order_flagged', 'flagged' );
			$message = sprintf( esc_html__( 'Checkout.com Payment Flagged (3DS return) - Payment ID: %s, Amount: %s', 'checkout-com-unified-payments-api' ), $flow_payment_id, $formatted_order_amount );
		}
	}
		
		// Mark as authorized for APM payments
		if ( ! in_array( $flow_payment_type, array( 'card', 'googlepay', 'applepay' ), true ) ) {
			$order->update_meta_data( 'cko_payment_authorized', true );
		}
		
		// Continue with card saving logic after this if/elseif/else structure
			
	} catch ( Exception $e ) {
		WC_Checkoutcom_Utility::logger( '3DS return error: ' . $e->getMessage() );
		WC_Checkoutcom_Utility::wc_add_notice_self( __( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ) );
		return;
	}
	
	// Skip saved card and normal Flow payment logic since we're returning from 3DS
	// Jump directly to card saving logic below
	} elseif ( WC_Checkoutcom_Api_Request::is_using_saved_payment_method() ) {
		$token = 'wc-wc_checkout_com_flow-payment-token';

			if ( ! isset( $_POST[ $token ] ) ) {
				// Token check - will be sanitized when accessed
				$token = 'wc-wc_checkout_com_cards-payment-token';
			} else {
				$token = 'wc-wc_checkout_com_flow-payment-token';
			}

			// Saved card selected.
			$arg = sanitize_text_field( wp_unslash( $_POST[ $token ] ) );
			
			// CRITICAL: Validate token exists before processing payment (especially for newly saved cards)
			// Try to get token directly first
			$token_obj = WC_Payment_Tokens::get( $arg );
			
			// If token not found, try refreshing cache and searching across both gateways
			if ( ! $token_obj ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token not found directly - Token ID: ' . $arg );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] User ID: ' . $order->get_user_id() );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Gateway ID: ' . $this->id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token field: ' . $token );
				
				// Clear any token cache
				wp_cache_delete( 'customer_tokens_' . $order->get_user_id() . '_' . $this->id, 'woocommerce' );
				$classic_gateway = new WC_Gateway_Checkout_Com_Cards();
				wp_cache_delete( 'customer_tokens_' . $order->get_user_id() . '_' . $classic_gateway->id, 'woocommerce' );
				
				// Try to find token in Flow gateway (refresh cache)
				$flow_tokens = WC_Payment_Tokens::get_customer_tokens( $order->get_user_id(), $this->id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Flow tokens found: ' . count( $flow_tokens ) );
				
				// Try to find token in Classic Cards gateway (refresh cache)
				$classic_tokens = WC_Payment_Tokens::get_customer_tokens( $order->get_user_id(), $classic_gateway->id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Classic Cards tokens found: ' . count( $classic_tokens ) );
				
				// Try to find token by ID in all tokens
				$all_tokens = array_merge( $flow_tokens, $classic_tokens );
				$found_token = null;
				foreach ( $all_tokens as $check_token ) {
					if ( $check_token->get_id() == $arg ) {
						$found_token = $check_token;
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Token found in tokens list - Gateway: ' . $check_token->get_gateway_id() . ', Token ID: ' . $check_token->get_id() . ', Source ID: ' . substr( $check_token->get_token(), 0, 20 ) . '...' );
						break;
					}
				}
				
				if ( ! $found_token ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ❌ ERROR: Token ID ' . $arg . ' not found in any gateway tokens' );
					$available_token_ids = array_map( function( $t ) { return $t->get_id(); }, $all_tokens );
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Available token IDs: ' . ( ! empty( $available_token_ids ) ? implode( ', ', $available_token_ids ) : 'NONE' ) );
					WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Saved payment method not found. Please try using a new payment method or refresh the page.', 'checkout-com-unified-payments-api' ), 'error' );
					$order->update_status( 'failed', __( 'Payment failed - Saved card token not found', 'checkout-com-unified-payments-api' ) );
					$order->add_order_note( sprintf( __( 'Payment failed - Token ID %s not found. Available tokens: %s', 'checkout-com-unified-payments-api' ), $arg, implode( ', ', $available_token_ids ) ) );
					$order->save();
					return;
				} else {
					// Token found - use it
					$token_obj = $found_token;
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Token found - proceeding with payment - Gateway: ' . $token_obj->get_gateway_id() );
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Token found successfully - Token ID: ' . $token_obj->get_id() . ', Gateway: ' . $token_obj->get_gateway_id() . ', Source ID: ' . substr( $token_obj->get_token(), 0, 20 ) . '...' );
			}

			// Create payment with card token.
			$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg );

			if ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order->get_id() ) ) {
				$flow_result = $result;
			}

			if ( isset( $result['3d_redirection_error'] ) && true === $result['3d_redirection_error'] ) {
				// Retry Create payment with card token.
				$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg, null, true );
			}
	
			// check if result has error and return error message.
			if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Saved card payment failed - Order ID: ' . $order_id . ', Error: ' . $result['error'] );
				
				// DEBUG: Log addresses before marking as failed
				if ( $order && $order->get_id() ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] Saved card payment failed - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
				}
				
				// CRITICAL: Mark order as failed to track payment failure
				if ( $order && $order->get_id() ) {
					$order->update_status( 'failed', __( 'Payment failed - Saved card payment error', 'checkout-com-unified-payments-api' ) );
					$order->add_order_note( sprintf( __( 'Payment failed - Error: %s', 'checkout-com-unified-payments-api' ), $result['error'] ) );
					$order->save();
					
					// DEBUG: Log addresses AFTER marking as failed
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] [ADDRESS DEBUG] After saved card payment failed save - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order marked as failed - Order ID: ' . $order_id );
				}
				
				WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
	
				return;
			}

			// Get save card config from module setting.
			$save_card = WC_Admin_Settings::get_option( 'ckocom_card_saved' );

			$subs_payment_type = "card";

			// Check if result contains 3d redirection url.
			if ( isset( $result['3d'] ) && ! empty( $result['3d'] ) ) {

				// Check if save card is enable and customer select to save card.
				if ( $save_card && isset( $_POST['wc-wc_checkout_com_cards-new-payment-method'] ) && sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_cards-new-payment-method'] ) ) ) {
					// Save in session for 3D secure payment.
					WC()->session->set( 'wc-wc_checkout_com_cards-new-payment-method', 'yes' );
				} else {
					WC()->session->set( 'wc-wc_checkout_com_cards-new-payment-method', 'no' );
				}

				$payment_id = isset( $result['id'] ) ? $result['id'] : '';
				$order->add_order_note(
					sprintf(
						esc_html__( 'Checkout.com 3d Redirect waiting - Payment ID: %1$s, URL: %2$s', 'checkout-com-unified-payments-api' ),
						$payment_id,
						$result['3d']
					)
				);

				// Redirect to 3D secure page.
				return [
					'result'   => 'success',
					'redirect' => $result['3d'],
				];
			}

			// Set action id as woo transaction id.
			$order->set_transaction_id( $result['action_id'] );
			$order->update_meta_data( '_cko_payment_id', $result['id'] );

			// Check if payment is already captured (webhook may have arrived first)
			$already_captured = $order->get_meta( 'cko_payment_captured' );
			$payment_id = isset( $result['id'] ) ? $result['id'] : '';
			$action_id = isset( $result['action_id'] ) ? $result['action_id'] : '';

			// Get cko auth status configured in admin.
			// Only set to 'on-hold' if payment is not already captured
			if ( ! $already_captured ) {
				$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );

				/* translators: %1$s: Payment ID, %2$s: Action ID. */
				$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );

				// Check if payment was flagged.
				if ( $result['risk']['flagged'] ) {
					// Get cko auth status configured in admin.
					$status = WC_Admin_Settings::get_option( 'ckocom_order_flagged', 'flagged' );

					/* translators: %1$s: Payment ID, %2$s: Action ID. */
					$message = sprintf( esc_html__( 'Checkout.com Payment Flagged - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
				}
			} else {
				// Payment already captured - just add note, don't change status
				/* translators: %1$s: Payment ID, %2$s: Action ID. */
				$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
				// Status should remain as set by capture webhook (Processing)
				$status = null; // Signal to skip status update
			}

			$order_status = $order->get_status();

			if ( 'pending' === $order_status || 'failed' === $order_status ) {
				$order->update_meta_data( 'cko_payment_authorized', true );
			}
		}
	else {
		// CRITICAL: Check for saved card token even if is_using_saved_payment_method() returned false
		// This handles cases where saved card detection fails but token is present in POST
		// Clear cache first to ensure we get the latest tokens (especially for newly saved cards)
		if ( $order->get_user_id() > 0 ) {
			wp_cache_delete( 'customer_tokens_' . $order->get_user_id() . '_' . $this->id, 'woocommerce' );
			$classic_gateway = new WC_Gateway_Checkout_Com_Cards();
			wp_cache_delete( 'customer_tokens_' . $order->get_user_id() . '_' . $classic_gateway->id, 'woocommerce' );
		}
		
		$saved_card_token = isset( $_POST['wc-wc_checkout_com_flow-payment-token'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-payment-token'] ) ) : '';
		if ( empty( $saved_card_token ) ) {
			$saved_card_token = isset( $_POST['wc-wc_checkout_com_cards-payment-token'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_cards-payment-token'] ) ) : '';
		}
		
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Fallback check - Token value: ' . ( $saved_card_token ? $saved_card_token : 'EMPTY' ) . ', Is "new": ' . ( 'new' === $saved_card_token ? 'YES' : 'NO' ) );
		
		// If we have a saved card token (and it's not "new"), treat as saved card payment
		if ( ! empty( $saved_card_token ) && 'new' !== $saved_card_token ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Saved card token detected in fallback check - Token ID: ' . $saved_card_token );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Processing as saved card payment (fallback detection)' );
			
			// Process as saved card payment
			$token = 'wc-wc_checkout_com_flow-payment-token';
			if ( ! isset( $_POST[ $token ] ) || empty( $_POST[ $token ] ) || 'new' === sanitize_text_field( wp_unslash( $_POST[ $token ] ) ) ) {
				$token = 'wc-wc_checkout_com_cards-payment-token';
			}
			
			$arg = sanitize_text_field( wp_unslash( $_POST[ $token ] ) );
			
			// CRITICAL: Validate token exists before processing payment
			$token_obj = WC_Payment_Tokens::get( $arg );
			if ( ! $token_obj ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ERROR: Token not found for ID: ' . $arg );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] User ID: ' . $order->get_user_id() );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Gateway ID: ' . $this->id );
				
				// Try to find token in Flow gateway
				$flow_tokens = WC_Payment_Tokens::get_customer_tokens( $order->get_user_id(), $this->id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Flow tokens found: ' . count( $flow_tokens ) );
				
				// Try to find token in Classic Cards gateway
				$classic_gateway = new WC_Gateway_Checkout_Com_Cards();
				$classic_tokens = WC_Payment_Tokens::get_customer_tokens( $order->get_user_id(), $classic_gateway->id );
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Classic Cards tokens found: ' . count( $classic_tokens ) );
				
				// Try to find token by ID in all tokens
				$all_tokens = array_merge( $flow_tokens, $classic_tokens );
				$found_token = null;
				foreach ( $all_tokens as $check_token ) {
					if ( $check_token->get_id() == $arg ) {
						$found_token = $check_token;
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token found in tokens list - Gateway: ' . $check_token->get_gateway_id() . ', Token ID: ' . $check_token->get_id() );
						break;
					}
				}
				
				if ( ! $found_token ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ERROR: Token ID ' . $arg . ' not found in any gateway tokens' );
					WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Saved payment method not found. Please try using a new payment method or refresh the page.', 'checkout-com-unified-payments-api' ), 'error' );
					$order->update_status( 'failed', __( 'Payment failed - Saved card token not found', 'checkout-com-unified-payments-api' ) );
					$order->save();
					return;
				} else {
					// Use the found token
					$token_obj = $found_token;
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Using found token - Gateway: ' . $token_obj->get_gateway_id() );
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token found successfully - Token ID: ' . $token_obj->get_id() . ', Gateway: ' . $token_obj->get_gateway_id() . ', Source ID: ' . substr( $token_obj->get_token(), 0, 20 ) . '...' );
			}
			
			// Create payment with card token
			$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg );
			
			if ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order->get_id() ) ) {
				$flow_result = $result;
			}
			
			if ( isset( $result['3d_redirection_error'] ) && true === $result['3d_redirection_error'] ) {
				// Retry Create payment with card token
				$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg, null, true );
			}
			
			// Check if result has error
			if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Saved card payment failed (fallback) - Order ID: ' . $order_id . ', Error: ' . $result['error'] );
				$order->update_status( 'failed', __( 'Payment failed - Saved card payment error', 'checkout-com-unified-payments-api' ) );
				$order->add_order_note( sprintf( __( 'Payment failed - Error: %s', 'checkout-com-unified-payments-api' ), $result['error'] ) );
				$order->save();
				WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
				return;
			}
			
			// Handle 3DS redirect if needed
			if ( isset( $result['3d'] ) && ! empty( $result['3d'] ) ) {
				$payment_id = isset( $result['id'] ) ? $result['id'] : '';
				$order->add_order_note(
					sprintf(
						esc_html__( 'Checkout.com 3d Redirect waiting - Payment ID: %1$s, URL: %2$s', 'checkout-com-unified-payments-api' ),
						$payment_id,
						$result['3d']
					)
				);
				return [
					'result'   => 'success',
					'redirect' => $result['3d'],
				];
			}
			
			// Set transaction ID and payment ID
			$order->set_transaction_id( $result['action_id'] );
			$order->update_meta_data( '_cko_payment_id', $result['id'] );
			
			// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			if ( empty( $existing_flow_payment_id ) ) {
				$order->update_meta_data( '_cko_flow_payment_id', $result['id'] );
			} else {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment ID already exists in order (saved card) - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $result['id'], 0, 20 ) . '... (skipping save to prevent overwrite)' );
			}
			
			$order->update_meta_data( '_cko_flow_payment_type', 'card' );
			$order->update_meta_data( '_cko_order_reference', $order->get_order_number() );
			
			// Check if payment is already captured
			$already_captured = $order->get_meta( 'cko_payment_captured' );
			$payment_id = isset( $result['id'] ) ? $result['id'] : '';
			$action_id = isset( $result['action_id'] ) ? $result['action_id'] : '';
			
			// Set status
			if ( ! $already_captured ) {
				$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
				$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
				
				if ( isset( $result['risk']['flagged'] ) && $result['risk']['flagged'] ) {
					$status = WC_Admin_Settings::get_option( 'ckocom_order_flagged', 'flagged' );
					$message = sprintf( esc_html__( 'Checkout.com Payment Flagged - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
				}
			} else {
				$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
				$status = null; // Skip status update
			}
			
			$order_status = $order->get_status();
			if ( 'pending' === $order_status || 'failed' === $order_status ) {
				$order->update_meta_data( 'cko_payment_authorized', true );
			}
			
			// Continue to card saving logic below (same as normal saved card flow)
			$flow_pay_id = $payment_id;
			$flow_payment_type = 'card';
		} else {
			// Normal Flow payment (new card)
			$flow_pay_id = isset( $_POST['cko-flow-payment-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-id'] ) ) : '';
			$payment_processed_via_fallback = false;
			
			// Log detailed information for debugging
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Normal Flow payment branch - Payment ID: ' . ( $flow_pay_id ? $flow_pay_id : 'EMPTY' ) );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token value from POST: ' . ( isset( $_POST['wc-wc_checkout_com_flow-payment-token'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-payment-token'] ) ) : 'NOT SET' ) );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] is_using_saved_payment_method() result: ' . ( WC_Checkoutcom_Api_Request::is_using_saved_payment_method() ? 'TRUE' : 'FALSE' ) );

			// Check if $flow_pay_id is not empty.
			if ( empty( $flow_pay_id ) ) {
				// Check if there's a recently saved token that should be used (for newly saved cards)
				$recent_token_id = null;
				if ( $order->get_user_id() > 0 ) {
					// Get all tokens for this user
					$flow_tokens = WC_Payment_Tokens::get_customer_tokens( $order->get_user_id(), $this->id );
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Checking for recently saved tokens - Found ' . count( $flow_tokens ) . ' Flow tokens' );
					
					// Find the most recently created token (within last 5 minutes)
					$most_recent_token = null;
					$most_recent_time = 0;
					foreach ( $flow_tokens as $token ) {
						$token_created = $token->get_date_created();
						if ( $token_created ) {
							$token_time = strtotime( $token_created );
							$current_time = current_time( 'timestamp' );
							$time_diff = $current_time - $token_time;
							
							// Check if token was created recently (within last 5 minutes) and is more recent than current
							if ( $time_diff < 300 && $token_time > $most_recent_time ) {
								$most_recent_token = $token;
								$most_recent_time = $token_time;
							}
						}
					}
					
					// If there's exactly one token, it might be a newly saved card that wasn't selected in the form
					if ( count( $flow_tokens ) === 1 ) {
						$single_token = reset( $flow_tokens );
						$recent_token_id = $single_token->get_id();
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Found single token - ID: ' . $recent_token_id . ', Created: ' . $single_token->get_date_created() );
						
						// Check if token was created recently (within last 5 minutes)
						$token_created = $single_token->get_date_created();
						if ( $token_created ) {
							$token_time = strtotime( $token_created );
							$current_time = current_time( 'timestamp' );
							$time_diff = $current_time - $token_time;
							
							if ( $time_diff < 300 ) { // 5 minutes
								WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Token was created recently (' . $time_diff . ' seconds ago) - using as fallback' );
								// Use this token as fallback
								$arg = $recent_token_id;
								$token_obj = $single_token;
								
								// Process as saved card payment
								$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg );
								
								if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
									WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Fallback saved card payment failed - Order ID: ' . $order_id . ', Error: ' . $result['error'] );
									$order->update_status( 'failed', __( 'Payment failed - Saved card payment error', 'checkout-com-unified-payments-api' ) );
									$order->add_order_note( sprintf( __( 'Payment failed - Error: %s', 'checkout-com-unified-payments-api' ), $result['error'] ) );
									$order->save();
									WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
									return;
								}
								
								// Handle 3DS redirect if needed
								if ( isset( $result['3d'] ) && ! empty( $result['3d'] ) ) {
									$payment_id = isset( $result['id'] ) ? $result['id'] : '';
									$order->add_order_note(
										sprintf(
											esc_html__( 'Checkout.com 3d Redirect waiting - Payment ID: %1$s, URL: %2$s', 'checkout-com-unified-payments-api' ),
											$payment_id,
											$result['3d']
										)
									);
									return [
										'result'   => 'success',
										'redirect' => $result['3d'],
									];
								}
								
								// Set transaction ID and payment ID
								$order->set_transaction_id( $result['action_id'] );
								$order->update_meta_data( '_cko_payment_id', $result['id'] );
								
								// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
								$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
								if ( empty( $existing_flow_payment_id ) ) {
									$order->update_meta_data( '_cko_flow_payment_id', $result['id'] );
								} else {
									WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment ID already exists in order (saved card fallback 1) - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $result['id'], 0, 20 ) . '... (skipping save to prevent overwrite)' );
								}
								
								$order->update_meta_data( '_cko_flow_payment_type', 'card' );
								$order->update_meta_data( '_cko_order_reference', $order->get_order_number() );
								
								// Check if payment is already captured
								$already_captured = $order->get_meta( 'cko_payment_captured' );
								$payment_id = isset( $result['id'] ) ? $result['id'] : '';
								$action_id = isset( $result['action_id'] ) ? $result['action_id'] : '';
								
								// Set status
								if ( ! $already_captured ) {
									$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
									$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									
									if ( isset( $result['risk']['flagged'] ) && $result['risk']['flagged'] ) {
										$status = WC_Admin_Settings::get_option( 'ckocom_order_flagged', 'flagged' );
										$message = sprintf( esc_html__( 'Checkout.com Payment Flagged - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									}
								} else {
									$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									$status = null; // Skip status update
								}
								
								$order_status = $order->get_status();
								if ( 'pending' === $order_status || 'failed' === $order_status ) {
									$order->update_meta_data( 'cko_payment_authorized', true );
								}
								
								// Payment processed successfully via fallback
								$flow_pay_id = $payment_id;
								$flow_payment_type = 'card';
								$payment_processed_via_fallback = true;
								
								WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment processed successfully via fallback - Payment ID: ' . $payment_id );
							}
						} elseif ( $most_recent_token ) {
							// Use the most recently created token (within 5 minutes) as fallback
							$recent_token_id = $most_recent_token->get_id();
							$time_diff = current_time( 'timestamp' ) - strtotime( $most_recent_token->get_date_created() );
							WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Found most recent token - ID: ' . $recent_token_id . ', Created: ' . $most_recent_token->get_date_created() . ' (' . $time_diff . ' seconds ago)' );
							
							if ( $time_diff < 300 ) { // 5 minutes
								WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Most recent token was created recently (' . $time_diff . ' seconds ago) - using as fallback' );
								// Use this token as fallback
								$arg = $recent_token_id;
								$token_obj = $most_recent_token;
								
								// Process as saved card payment
								$result = (array) WC_Checkoutcom_Api_Request::create_payment( $order, $arg );
								
								if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
									WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Fallback saved card payment failed - Order ID: ' . $order_id . ', Error: ' . $result['error'] );
									$order->update_status( 'failed', __( 'Payment failed - Saved card payment error', 'checkout-com-unified-payments-api' ) );
									$order->add_order_note( sprintf( __( 'Payment failed - Error: %s', 'checkout-com-unified-payments-api' ), $result['error'] ) );
									$order->save();
									WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
									return;
								}
								
								// Handle 3DS redirect if needed
								if ( isset( $result['3d'] ) && ! empty( $result['3d'] ) ) {
									$payment_id = isset( $result['id'] ) ? $result['id'] : '';
									$order->add_order_note(
										sprintf(
											esc_html__( 'Checkout.com 3d Redirect waiting - Payment ID: %1$s, URL: %2$s', 'checkout-com-unified-payments-api' ),
											$payment_id,
											$result['3d']
										)
									);
									return [
										'result'   => 'success',
										'redirect' => $result['3d'],
									];
								}
								
								// Set transaction ID and payment ID
								$order->set_transaction_id( $result['action_id'] );
								$order->update_meta_data( '_cko_payment_id', $result['id'] );
								
								// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
								$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
								if ( empty( $existing_flow_payment_id ) ) {
									$order->update_meta_data( '_cko_flow_payment_id', $result['id'] );
								} else {
									WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment ID already exists in order (saved card fallback 1) - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $result['id'], 0, 20 ) . '... (skipping save to prevent overwrite)' );
								}
								
								$order->update_meta_data( '_cko_flow_payment_type', 'card' );
								$order->update_meta_data( '_cko_order_reference', $order->get_order_number() );
								
								// Check if payment is already captured
								$already_captured = $order->get_meta( 'cko_payment_captured' );
								$payment_id = isset( $result['id'] ) ? $result['id'] : '';
								$action_id = isset( $result['action_id'] ) ? $result['action_id'] : '';
								
								// Set status
								if ( ! $already_captured ) {
									$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
									$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									
									if ( isset( $result['risk']['flagged'] ) && $result['risk']['flagged'] ) {
										$status = WC_Admin_Settings::get_option( 'ckocom_order_flagged', 'flagged' );
										$message = sprintf( esc_html__( 'Checkout.com Payment Flagged - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									}
								} else {
									$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - Payment ID: %1$s, Action ID: %2$s', 'checkout-com-unified-payments-api' ), $payment_id, $action_id );
									$status = null; // Skip status update
								}
								
								$order_status = $order->get_status();
								if ( 'pending' === $order_status || 'failed' === $order_status ) {
									$order->update_meta_data( 'cko_payment_authorized', true );
								}
								
								// Payment processed successfully via fallback
								$flow_pay_id = $payment_id;
								$flow_payment_type = 'card';
								$payment_processed_via_fallback = true;
								
								WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment processed successfully via fallback (most recent token) - Payment ID: ' . $payment_id );
							}
						}
					}
				}
				
				// Only show error if payment wasn't processed via fallback
				if ( ! $payment_processed_via_fallback ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ERROR: No payment ID and no saved card token found - Order ID: ' . $order_id );
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] POST data keys: ' . implode( ', ', array_keys( $_POST ) ) );
					WC_Checkoutcom_Utility::wc_add_notice_self( __( 'There was an issue completing the payment. Please complete the payment.', 'checkout-com-unified-payments-api' ), 'error' );

					return;
				}
			}
		}

	// Get payment type from POST, or fallback to order meta (for 3DS returns that stored it in meta)
	$flow_payment_type = isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : '';
	if ( empty( $flow_payment_type ) && $order ) {
		$flow_payment_type = $order->get_meta( '_cko_flow_payment_type' );
	}
	if ( empty( $flow_payment_type ) ) {
		$flow_payment_type = 'card'; // Default fallback
	}

	if ( "card" === $flow_payment_type ) {
		$subs_payment_type = $flow_payment_type;
	}

	$order->update_meta_data( '_cko_payment_id', $flow_pay_id );
	
	// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
	$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
	if ( empty( $existing_flow_payment_id ) ) {
		$order->update_meta_data( '_cko_flow_payment_id', $flow_pay_id );
	} else {
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment ID already exists in order - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $flow_pay_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
	}
	
	$order->update_meta_data( '_cko_flow_payment_type', $flow_payment_type );
	// Store order number/reference for webhook lookup (works with Sequential Order Numbers plugins)
	$order->update_meta_data( '_cko_order_reference', $order->get_order_number() );
	
	// Store payment session ID for 3DS return lookup
	// Priority: 1) POST data (from form), 2) Already-fetched payment details, 3) Payment metadata (fetch if needed)
	$payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) : '';
	WC_Checkoutcom_Utility::logger( 'Payment session ID from POST: ' . ( ! empty( $payment_session_id ) ? $payment_session_id : 'EMPTY' ) );
	
	$payment_details_for_shipping = null;
	if ( empty( $payment_session_id ) && ! empty( $flow_pay_id ) ) {
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment session ID is empty, checking payment details - Payment ID: ' . $flow_pay_id );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Has already-fetched payment_details: ' . ( ! empty( $payment_details ) ? 'YES' : 'NO' ) );
		
		// CRITICAL: First try to use already-fetched payment details (from early fetch at line 1474)
		// This avoids unnecessary API calls and works better for APM payments
		if ( ! empty( $payment_details ) ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Checking already-fetched payment_details for payment session ID...' );
			if ( isset( $payment_details['metadata']['cko_payment_session_id'] ) ) {
				$payment_session_id = $payment_details['metadata']['cko_payment_session_id'];
				$payment_details_for_shipping = $payment_details;
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Payment session ID retrieved from already-fetched payment details: ' . substr( $payment_session_id, 0, 20 ) . '...' );
			} else {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ Payment session ID not found in already-fetched payment_details metadata' );
				if ( isset( $payment_details['metadata'] ) ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Available metadata keys: ' . implode( ', ', array_keys( $payment_details['metadata'] ) ) );
				} else {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ No metadata key found in payment_details' );
				}
			}
		}
		
		// Fallback: Fetch payment details if not already fetched or if payment session ID not found
		if ( empty( $payment_session_id ) ) {
			// Fallback: Fetch payment details if not already fetched
			try {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Fetching payment details to get payment session ID - Payment ID: ' . $flow_pay_id );
				$checkout = new Checkout_SDK();
				$builder = $checkout->get_builder();
				if ( $builder ) {
					$payment_details_for_shipping = $builder->getPaymentsClient()->getPaymentDetails( $flow_pay_id );
					$payment_session_id = isset( $payment_details_for_shipping['metadata']['cko_payment_session_id'] ) ? $payment_details_for_shipping['metadata']['cko_payment_session_id'] : '';
					if ( ! empty( $payment_session_id ) ) {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Payment session ID retrieved from payment metadata: ' . substr( $payment_session_id, 0, 20 ) . '...' );
					} else {
						WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ Payment session ID not found in payment metadata' );
					}
				}
			} catch ( Exception $e ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ Could not fetch payment details to get payment session ID: ' . $e->getMessage() );
			}
		}
	}
	
	// CRITICAL: Add shipping from payment_details if available and order doesn't have shipping yet
	if ( $payment_details_for_shipping ) {
		$this->add_shipping_from_payment_details( $order, $payment_details_for_shipping );
		$order->save(); // Save after adding shipping
	}
	
	// Always save payment session ID if we have it (even if empty, log it)
	// CRITICAL: Ensure payment_session_id is unique - one order = one payment session ID
	if ( ! empty( $payment_session_id ) ) {
		// Check if payment_session_id already exists in another order (prevent duplicates)
		$existing_orders = wc_get_orders( array(
			'meta_key'   => '_cko_payment_session_id',
			'meta_value' => $payment_session_id,
			'limit'      => 1,
			'exclude'    => array( $order_id ), // Exclude current order
			'return'     => 'ids',
		) );
		
		if ( ! empty( $existing_orders ) ) {
			// Payment session ID already used by another order - CRITICAL ERROR
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ❌ CRITICAL ERROR: Payment session ID already used by order: ' . $existing_orders[0] );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ❌ Cannot save duplicate payment_session_id to order: ' . $order_id );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ❌ Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '...' );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ❌ This violates one-order-one-payment-session-id rule' );
			// Don't save duplicate - this prevents webhook matching wrong order
			// Log error but continue processing (order already exists)
		} else {
			// Safe to save - payment_session_id is unique
			$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ Saved payment session ID to order - Order ID: ' . $order_id . ', Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '... (Unique - no duplicates found)' );
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ✅ One order = one payment session ID: Order ' . $order_id . ' = Payment Session ' . substr( $payment_session_id, 0, 20 ) . '...' );
		}
	} else {
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ WARNING: Payment session ID is empty - Order ID: ' . $order_id . ', Payment ID: ' . $flow_pay_id );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ This may cause issues with 3DS return order lookup and webhook matching' );
	}
	
	// CRITICAL: Save order immediately so webhooks can find it (especially for fast APM payments)
	$order->save();
	WC_Checkoutcom_Utility::logger( 'Order meta saved immediately for webhook lookup - Order ID: ' . $order_id . ', Payment ID: ' . $flow_pay_id );
	
	// Process any pending webhooks for this order
	if ( class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
		WC_Checkout_Com_Webhook_Queue::process_pending_webhooks_for_order( $order );
	}

		if ( ! in_array( $flow_payment_type, array( 'card', 'googlepay', 'applepay' ), true ) ) {
				$order->update_meta_data( 'cko_payment_authorized', true );
			}

			// Check if payment is already captured (webhook may have arrived first)
			$already_captured = $order->get_meta( 'cko_payment_captured' );

			// translators: %1$s: payment type (e.g., card, applepay), %2$s: Payment ID.
			$message = sprintf( esc_html__( 'Checkout.com Payment Authorised - using FLOW : %1$s - Payment ID: %2$s', 'checkout-com-unified-payments-api' ), $flow_payment_type, $flow_pay_id );

			// Get cko auth status configured in admin.
			// Only set to 'on-hold' if payment is not already captured
			if ( ! $already_captured ) {
				$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );
			} else {
				// Payment already captured - just add note, don't change status
				// Status should remain as set by capture webhook (Processing)
				$status = null; // Signal to skip status update
			}

			// Get source ID for the payment id for subscription product.
			// Also true in change-payment-method mode, where $order IS the WC_Subscription
			// itself — wcs_order_contains_subscription() returns false for a subscription
			// object, so we must additionally check wcs_is_subscription() or the new source
			// never gets persisted and the next renewal charges the old card.
			if ( ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order->get_id() ) )
				|| ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) ) {
				// Call cko_get_payment_status() directly instead of rest_do_request() —
				// same reason as in flow_save_cards(): the REST endpoint requires a
				// browser-scoped nonce we don't have server-side, and going through
				// rest_do_request would return an error payload that downstream code
				// would mistake for valid payment data.
				$request = new \WP_REST_Request( 'GET', '/ckoplugin/v1/payment-status' );
				$request->set_query_params( [ 'paymentId' => $flow_pay_id ] );

				$response = cko_get_payment_status( $request );
				$status   = $response instanceof \WP_REST_Response ? $response->get_status() : 500;
				$data     = $response instanceof \WP_REST_Response ? $response->get_data() : null;

				if ( $status >= 400 || ! is_array( $data ) || isset( $data['error'] ) ) {
					$error_message = is_array( $data ) && isset( $data['error'] ) ? $data['error'] : 'Unknown error fetching payment status (HTTP ' . $status . ')';
					WC_Checkoutcom_Utility::logger( "There was an error fetching payment status for subscription source: $error_message" );
				} else {
					$flow_result = $data;
				}
		}
	}

	// Card saving logic (runs for both normal Flow payments and 3DS returns)
	// Check if $flow_pay_id is set (it's set in both the 3DS return handler and normal Flow payment)
	if ( isset( $flow_pay_id ) && ! empty( $flow_pay_id ) ) {
		$flow_payment_type_for_save = isset( $flow_payment_type ) ? $flow_payment_type : ( isset( $_POST['cko-flow-payment-type'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-type'] ) ) : '' );
		
		// Check if customer wants to save card
		// Priority: 1. Order metadata (stored before 3DS redirect), 2. GET parameter (from URL), 3. Hidden field (POST), 4. POST checkbox, 5. Session
		$save_card_enabled = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
		
		// Check order metadata first (stored before 3DS redirect - most reliable)
		$save_card_from_order = $order->get_meta( '_cko_save_card_preference' );
		
		// Check GET parameter (from URL after 3DS redirect)
		$save_card_from_get = isset( $_GET['cko-save-card'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-save-card'] ) ) : '';
		
		// Check hidden field (POST data - may not be available after 3DS redirect)
		$save_card_hidden = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
		
		// Fallback to POST checkbox
		$save_card_post = isset( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ) : '';
		
		// Fallback to session
		$save_card_session = WC()->session->get( 'wc-wc_checkout_com_flow-new-payment-method' );
		
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Checking save card preference - Order meta: ' . $save_card_from_order . ', GET: ' . $save_card_from_get . ', Hidden: ' . $save_card_hidden . ', POST: ' . $save_card_post . ', Session: ' . $save_card_session );
		
		// Determine if checkbox was checked (priority: order metadata > GET > hidden field > POST > session)
		$save_card_checkbox = false;
		if ( 'yes' === $save_card_from_order ) {
			$save_card_checkbox = true;
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference found in order metadata: YES' );
		} elseif ( 'yes' === $save_card_from_get ) {
			$save_card_checkbox = true;
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference found in GET parameter: YES' );
			// Store in order metadata for future reference
			$order->update_meta_data( '_cko_save_card_preference', 'yes' );
			$order->save();
		} elseif ( 'yes' === $save_card_hidden ) {
			$save_card_checkbox = true;
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference found in hidden field: YES' );
			// Store in order metadata for future reference
			$order->update_meta_data( '_cko_save_card_preference', 'yes' );
			$order->save();
		} elseif ( 'true' === $save_card_post || 'yes' === $save_card_post ) {
			$save_card_checkbox = true;
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference found in POST checkbox: YES' );
			// Store in order metadata for future reference
			$order->update_meta_data( '_cko_save_card_preference', 'yes' );
			$order->save();
		} elseif ( 'yes' === $save_card_session ) {
			$save_card_checkbox = true;
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference found in session: YES' );
			// Store in order metadata for future reference
			$order->update_meta_data( '_cko_save_card_preference', 'yes' );
			$order->save();
		} else {
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card preference NOT found - card will NOT be saved' );
		}

	WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Final check - Payment type: ' . $flow_payment_type_for_save . ', Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
	if ( 'card' === $flow_payment_type_for_save && $save_card_enabled && $save_card_checkbox ) {
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] ✅ All conditions met - calling flow_save_cards()' );
		$this->flow_save_cards( $order, $flow_pay_id );
		// Clear the session variable after processing
		WC()->session->__unset( 'wc-wc_checkout_com_flow-new-payment-method' );
	} else {
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] ❌ Conditions NOT met - Payment type: ' . $flow_payment_type_for_save . ' (expected: card), Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
	}
}

	if ( class_exists( 'WC_Subscriptions_Order' ) && $flow_result !== null ) {
			// Save source id for subscription.
				WC_Checkoutcom_Subscription::save_source_id( $order_id, $order, $flow_result['source']['id'] );

			if ( "card" === $subs_payment_type ) {
				$this->save_preferred_card_scheme( $order_id, $order, $flow_result['source']['scheme'] );
			}
		}

		// add notes for the order and update status.
		$order->add_order_note( $message );
		// Only update status if not null (null means payment already captured, keep existing status)
		if ( null !== $status ) {
			// CRITICAL: Refresh order from database and check current status to prevent downgrade
			$order = wc_get_order( $order_id );

			// Change-payment-method mode: $order_id is a WC_Subscription, not an order. WCS
			// subscription statuses are active/on-hold/cancelled/etc. — 'processing'/'completed'
			// are ORDER statuses, and calling update_status() with one throws "Unable to change
			// subscription status to processing" and leaves the subscription on-hold. The card
			// change only needs the new _cko_source_id (saved above); WCS manages the
			// subscription's own status, so we skip the order-status transition entirely here.
			if ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) {
				WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Subscription object (change-payment-method mode) — skipping order-status transition to "' . $status . '". Subscription ID: ' . $order_id );
			} else {
				$current_status = $order->get_status();

				// Define protected statuses that should NEVER be downgraded
				$protected_statuses = array( 'processing', 'completed' );

				// If order is already in a protected state, don't downgrade to on-hold
				if ( in_array( $current_status, $protected_statuses, true ) && 'on-hold' === $status ) {
					WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order already in ' . $current_status . ' status - skipping update to ' . $status . ' to prevent downgrade. Order ID: ' . $order_id );
				} else {
					$order->update_status( $status );
				}
			}
		}

		// CRITICAL: Only proceed with success flow if order status is NOT failed
		// If status is failed, don't clear cart or redirect to success page
		$final_order_status = $order->get_status();
		if ( 'failed' === $final_order_status ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Payment failed - Order status is failed. NOT clearing cart or redirecting to success page.' );
			WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Payment failed. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
			return; // Return early - don't clear cart or redirect
		}

		// Reduce stock levels — skip in change-payment-method mode ($order is a subscription,
		// no purchase is occurring, so reducing stock would be incorrect).
		if ( ! ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) ) {
			wc_reduce_stock_levels( $order_id );
		}

		// Get return URL before emptying cart
		$return_url = $this->get_return_url( $order );
		
		// Check if this is a MOTO order and log additional info
		$is_moto_order = $order->is_created_via( 'admin' );
		$is_guest = $order->get_customer_id() == 0;
		$order_key_in_url = strpos( $return_url, 'key=' ) !== false;
		$order_key_from_order = $order->get_order_key();
		
		if ( $is_moto_order ) {
			WC_Checkoutcom_Utility::logger( 'MOTO order detected - Order ID: ' . $order_id . ', Created via: ' . $order->get_created_via() );
		}
		
		// Log the redirect URL for debugging
		WC_Checkoutcom_Utility::logger( sprintf( 
			'Flow payment successful - redirecting to: %s (MOTO: %s, Guest: %s, Order Key in URL: %s, Order ID: %d)',
			$return_url,
			$is_moto_order ? 'YES' : 'NO',
			$is_guest ? 'YES' : 'NO',
			$order_key_in_url ? 'YES' : 'NO',
			$order_id
		) );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ========== RETURN URL DEBUG ==========' );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order ID: ' . $order_id );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Is guest order?: ' . ( $is_guest ? 'YES' : 'NO' ) );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order key from order object: ' . $order_key_from_order );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Return URL: ' . $return_url );
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] Order key in URL?: ' . ( $order_key_in_url ? 'YES' : 'NO' ) );
		if ( $is_guest && ! $order_key_in_url ) {
			WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ⚠️ WARNING: Guest order but order key NOT in return URL!' );
		}
		WC_Checkoutcom_Utility::logger( '[PROCESS PAYMENT] ========== END RETURN URL DEBUG ==========' );
		WC_Checkoutcom_Utility::logger( 'Order status updated to: ' . $status . ', Order ID: ' . $order_id );
		WC_Checkoutcom_Utility::logger( 'Transaction ID set to: ' . $order->get_transaction_id() );

		// Remove cart - only clear if payment succeeded (order status is not failed)
		WC()->cart->empty_cart();

		// Return thank you page.
		$redirect_result = array(
			'result'   => 'success',
			'redirect' => $return_url,
		);
		
		return $redirect_result;
	}

	
	/**
	 * Detect 3DS return parameters on checkout page and process server-side.
	 * This prevents JavaScript form submission issues in slow environments.
	 *
	 * @return void
	 */
	public function detect_and_process_3ds_return_on_checkout() {
		// Check if 3DS return parameters are present FIRST (before checking is_checkout)
		// This ensures we catch it even if is_checkout() hasn't loaded yet in slow environments
		$payment_id = isset( $_GET['cko-payment-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-id'] ) ) : '';
		$session_id = isset( $_GET['cko-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-session-id'] ) ) : '';
		$payment_session_id = isset( $_GET['cko-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-session-id'] ) ) : '';
		
		// If we have payment ID or session ID, it's a 3DS return
		if ( empty( $payment_id ) && empty( $session_id ) && empty( $payment_session_id ) ) {
			return;
		}
		
		// Only process on checkout page or order-pay page
		$is_checkout_page = is_checkout() || ( isset( $_GET['order_id'] ) && isset( $_GET['key'] ) );
		if ( ! $is_checkout_page ) {
			return;
		}
		
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS CHECKOUT] 3DS return detected on checkout page - Processing server-side' );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS CHECKOUT] Payment ID: ' . $payment_id . ', Session ID: ' . $session_id . ', Payment Session ID: ' . $payment_session_id );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS CHECKOUT] Request URI: ' . ( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : 'N/A' ) );
		
		// Process the 3DS return (this will redirect to success page)
		try {
			$this->handle_3ds_return();
			// If handle_3ds_return doesn't exit/redirect, exit here
			exit;
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS CHECKOUT] Error processing 3DS return: ' . $e->getMessage() );
			
			// Try to find order by payment ID as fallback
			if ( ! empty( $payment_id ) ) {
				$orders = wc_get_orders( array(
					'meta_key'   => '_cko_payment_id',
					'meta_value' => $payment_id,
					'limit'      => 1,
					'orderby'    => 'date',
					'order'      => 'DESC',
				) );
				
				if ( ! empty( $orders ) ) {
					$order = $orders[0];
					$redirect_url = $order->get_checkout_order_received_url();
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS CHECKOUT] Found order by payment ID, redirecting to: ' . $redirect_url );
					wp_safe_redirect( $redirect_url );
					exit;
				}
			}
			
			// If we can't find order, show error but don't die - let JavaScript handle it as fallback
			WC_Checkoutcom_Utility::wc_add_notice_self( __( 'There was an error processing your order. Please check your order history.', 'checkout-com-unified-payments-api' ), 'error' );
			// Don't exit - let the page load so JavaScript can handle it as fallback
			return;
		}
	}

	/**
	 * Handle 3DS return via WC API endpoint (similar to PayPal approach).
	 * Processes payment and redirects directly to order-received page.
	 * 
	 * @return void
	 */
	public function handle_3ds_return() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		
		// PERFORMANCE: Only log verbose details in debug mode
		$is_debug = defined( 'WP_DEBUG' ) && WP_DEBUG;
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== ENTRY POINT ==========' );
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Request URI: ' . ( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : 'N/A' ) );
		}
		
		$payment_id = isset( $_GET['cko-payment-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-id'] ) ) : '';
		$payment_session_id_from_url = isset( $_GET['cko-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-session-id'] ) ) : '';
		$order_id   = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;
		$order_key  = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		
		// CRITICAL: Check for status parameter from Checkout.com redirect
		// Checkout.com adds status=failed or status=succeeded to the redirect URL
		$cko_status = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
		
		// ALWAYS log this for debugging 3DS issues - critical for troubleshooting
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment ID: ' . $payment_id . ', Order ID: ' . $order_id . ', CKO Status: ' . ( $cko_status ?: 'NOT SET' ) . ', Full URL params: ' . wp_json_encode( array_keys( $_GET ) ) );
		
		// EARLY EXIT: If Checkout.com explicitly tells us payment failed, handle it immediately
		if ( 'failed' === $cko_status ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ❌ Checkout.com returned status=failed - Payment was declined' );
			
			// Try to load order if we have order_id
			$order = null;
			if ( ! empty( $order_id ) ) {
				$order = wc_get_order( $order_id );
			}
			
			// Update order status if found
			if ( $order ) {
				$order->update_status( 'failed', __( 'Payment was declined by Checkout.com (3DS failure)', 'checkout-com-unified-payments-api' ) );
				if ( ! empty( $payment_id ) ) {
					$order->update_meta_data( '_cko_payment_id', $payment_id );
					$order->update_meta_data( '_cko_flow_payment_id', $payment_id );
				}
				$order->save();
			}
			
			// Show error and redirect to checkout
			WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Payment was declined. Please try again with a different payment method.', 'checkout-com-unified-payments-api' ), 'error' );
			
			if ( ! empty( $order_id ) && ! empty( $order_key ) ) {
				$redirect_url = wc_get_endpoint_url( 'order-pay', $order_id, wc_get_checkout_url() );
				$redirect_url = add_query_arg( array(
					'pay_for_order'  => 'true',
					'key'            => $order_key,
					'payment_failed' => '1',
				), $redirect_url );
			} else {
				$redirect_url = add_query_arg( 'payment_failed', '1', wc_get_checkout_url() );
			}
			
			wp_safe_redirect( $redirect_url );
			exit;
		}
		
		if ( empty( $payment_id ) ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Missing payment ID in GET params' );
			wp_die( esc_html__( 'Missing payment ID', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
		}
		
		// PERFORMANCE OPTIMIZATION: Initialize SDK and payment details cache (used in both fast and slow paths)
		static $sdk_builder_cache = null;
		static $payment_details_cache = array();
		
		// PERFORMANCE OPTIMIZATION: Early exit - Check order_id FIRST before expensive operations
		// If order_id and order_key are provided (order-pay page), use them directly (fast path)
		$order = null;
		$payment_details = null;
		
		if ( ! empty( $order_id ) && ! empty( $order_key ) ) {
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order ID and key provided - loading order: ' . $order_id );
			}
			$order = wc_get_order( $order_id );
			
			if ( ! $order ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Order not found - Order ID: ' . $order_id );
				wp_die( esc_html__( 'Order not found', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
			}
			
			$order_key_from_order = $order->get_order_key();
			if ( $order_key_from_order !== $order_key ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Order key mismatch' );
				wp_die( esc_html__( 'Invalid order key', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
			}

			// Subscription "Change payment method" 3DS return: $order is the WC_Subscription itself.
			// The amount/currency validation and status transitions further down assume a normal
			// order — for a $0 verification they would fail the amount-match check and try to set the
			// subscription to 'failed'. Delegate straight to process_payment(), which routes
			// subscriptions to handle_subscription_payment_method_change(). process_payment() reads
			// the payment id from the cko-payment-id GET param already present on this return URL.
			if ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Subscription change-payment-method 3DS return — delegating to process_payment. Subscription ID: ' . $order_id );
				$result   = $this->process_payment( $order_id );
				$redirect = ( is_array( $result ) && ! empty( $result['redirect'] ) ) ? $result['redirect'] : $order->get_view_order_url();
				wp_safe_redirect( $redirect );
				exit;
			}

			// PERFORMANCE: Fast path - order found, skip to payment processing
			// Payment details will be fetched later if needed (after duplicate check)
		} else {
			// PERFORMANCE OPTIMIZATION: For regular checkout, look up order by payment session ID
			// Initialize SDK once (if not already initialized)
			if ( null === $sdk_builder_cache ) {
				$checkout = new Checkout_SDK();
				$sdk_builder_cache = $checkout->get_builder();
			}
			$builder = $sdk_builder_cache;
			
			if ( ! $builder ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] WARNING: SDK builder not initialized - vendor/autoload.php may be missing' );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] For Flow payments, payment details are handled via webhooks, so this may not be critical' );
				// For Flow payments, we can continue without fetching payment details here
				// Payment will be processed via webhook or payment ID from form
				// Set payment_details to null and continue
				$payment_details = null;
			} else {
				// PERFORMANCE: Fetch payment details once and cache
				if ( ! isset( $payment_details_cache[ $payment_id ] ) ) {
					try {
						if ( $is_debug ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Fetching payment details - Payment ID: ' . $payment_id );
						}
						$payment_details_cache[ $payment_id ] = $builder->getPaymentsClient()->getPaymentDetails( $payment_id );
					} catch ( Exception $e ) {
						if ( $is_debug ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] WARNING: Failed to fetch payment details: ' . $e->getMessage() );
						}
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Failed to fetch payment details: ' . $e->getMessage() );
						wp_die( esc_html__( 'Payment processing error', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
					}
				}
				$payment_details = $payment_details_cache[ $payment_id ];
			}
			
			try {
				// Get payment session ID from URL first (faster), then from payment metadata if needed
				$payment_session_id = $payment_session_id_from_url;
				
				if ( empty( $payment_session_id ) && ! empty( $payment_details ) ) {
					// Get payment session ID from cached payment details
					$payment_session_id = isset( $payment_details['metadata']['cko_payment_session_id'] ) ? $payment_details['metadata']['cko_payment_session_id'] : '';
					if ( $is_debug && ! empty( $payment_session_id ) ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment session ID from payment metadata: ' . $payment_session_id );
					}
				}
				
				if ( empty( $payment_session_id ) ) {
					if ( $is_debug ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment session ID not found in URL or payment metadata' );
					}
					// Don't die yet - try fallback methods
				} else {
					
					// PERFORMANCE FIX: Use sequential single-key queries instead of OR meta_query
					// OR meta_query causes severe performance issues on large HPOS tables (253K+ orders)
					// Test results: OR query = 2173+ seconds, Sequential queries = 3ms
					// See: https://github.com/woocommerce/woocommerce/issues/32557
					if ( $is_debug ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Looking up order by payment session ID (sequential query)...' );
					}
					
					$orders = array();
					$found_order = null;
					$found_by_payment_session = false;
					
					// First query: Look up by payment_session_id (primary lookup)
					if ( ! empty( $payment_session_id ) ) {
						$orders = wc_get_orders( array(
							'meta_query' => array(
								array(
									'key'   => '_cko_payment_session_id',
									'value' => $payment_session_id,
								),
							),
							'limit'   => 5,
							'orderby' => 'date',
							'order'   => 'DESC',
						) );
						
						if ( ! empty( $orders ) ) {
							foreach ( $orders as $potential_order ) {
								$order_status = $potential_order->get_status();
								if ( in_array( $order_status, array( 'pending', 'failed' ), true ) ) {
									$found_order = $potential_order;
									$found_by_payment_session = true;
									if ( $is_debug ) {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order found by payment session ID - Order ID: ' . $found_order->get_id() . ', Status: ' . $order_status );
									}
									break;
								}
							}
						}
					}
					
					// Second query: Fallback to payment_id if no match found
					if ( ! $found_order && ! empty( $payment_id ) ) {
						if ( $is_debug ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Fallback: Looking up order by payment ID (sequential query)...' );
						}
						
						$orders = wc_get_orders( array(
							'meta_query' => array(
								array(
									'key'   => '_cko_payment_id',
									'value' => $payment_id,
								),
							),
							'limit'   => 5,
							'orderby' => 'date',
							'order'   => 'DESC',
						) );
						
						if ( ! empty( $orders ) ) {
							foreach ( $orders as $potential_order ) {
								$order_status = $potential_order->get_status();
								$existing_transaction_id = $potential_order->get_transaction_id();
								
								// Check if order already has a transaction ID (means it was already fully processed)
								if ( ! empty( $existing_transaction_id ) ) {
									if ( $is_debug ) {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Order found by payment ID already has transaction ID: ' . $existing_transaction_id . ' - NOT reusing (already processed)' );
									}
									continue;
								} elseif ( in_array( $order_status, array( 'pending', 'failed' ), true ) ) {
									$found_order = $potential_order;
									if ( $is_debug ) {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order found by payment ID - Order ID: ' . $found_order->get_id() . ', Status: ' . $order_status );
									}
									break;
								}
							}
						}
					}
					
					if ( $found_order ) {
						$order = $found_order;
						$order_id = $order->get_id();
						if ( $is_debug ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Using order found by ' . ( $found_by_payment_session ? 'payment session ID' : 'payment ID' ) . ' (status: ' . $found_order->get_status() . ') - Order ID: ' . $order_id );
						}
					}
					
					// If order not found or not reusable, try fallback methods
					if ( ! $order ) {
							// Fallback 2: Try to find most recent pending/failed order for this customer
							// IMPORTANT: Apply same duplicate prevention logic as pre-order creation check
							if ( $is_debug ) {
								WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Fallback: Looking for most recent pending/failed order...' );
							}
							if ( $payment_details && isset( $payment_details['customer']['email'] ) ) {
								$customer_email = $payment_details['customer']['email'];
								if ( ! empty( $customer_email ) ) {
									// PERFORMANCE OPTIMIZATION Phase 2: Single query for both pending and failed orders
									// Use date_query to only check recent orders (same time windows as pre-order creation check)
									$date_after_pending = date( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
									
									// Single query for both pending and failed orders (more efficient than two separate queries)
									$orders_by_email = wc_get_orders( array(
										'billing_email' => $customer_email,
										'status'        => array( 'pending', 'failed' ),
										'date_query'    => array(
											array(
												'after' => $date_after_pending, // Use longer window (7 days) for both
												'inclusive' => true,
											),
										),
										'limit'         => 10, // Increased limit to handle both statuses
										'orderby'       => 'date',
										'order'         => 'DESC',
									) );
									
									// Filter failed orders to 2-day window in PHP (more efficient than second query)
									if ( ! empty( $orders_by_email ) ) {
										$date_after_failed = strtotime( '-2 days' );
										$filtered_orders = array();
										
										foreach ( $orders_by_email as $email_order ) {
											$order_status = $email_order->get_status();
											$order_date = $email_order->get_date_created();
											
											// Include pending orders (7-day window) or failed orders (2-day window)
											if ( 'pending' === $order_status || 
											     ( 'failed' === $order_status && $order_date->getTimestamp() >= $date_after_failed ) ) {
												$filtered_orders[] = $email_order;
											}
										}
										
										$orders_by_email = $filtered_orders;
									}
									
									if ( $is_debug ) {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Found ' . count( $orders_by_email ) . ' pending/failed orders for email: ' . $customer_email );
									}
									
									// CRITICAL: Only reuse orders if payment_session_id matches (or is missing)
									// If payment_session_id in URL doesn't match existing order, create new order
									// This ensures every payment session (request to Checkout.com) has corresponding order
									$payment_amount = isset( $payment_details['amount'] ) ? $payment_details['amount'] : 0;
									$payment_currency = isset( $payment_details['currency'] ) ? $payment_details['currency'] : '';
									foreach ( $orders_by_email as $potential_order ) {
										$potential_order_status = $potential_order->get_status();
										// Double-check status (should already be filtered, but be safe)
										if ( ! in_array( $potential_order_status, array( 'pending', 'failed' ), true ) ) {
											continue;
										}
										
										// CRITICAL: Check if order already has a transaction ID or payment ID
										// If it does, it was already processed (even if failed), so don't reuse it
										$existing_transaction_id = $potential_order->get_transaction_id();
										$existing_payment_id = $potential_order->get_meta( '_cko_payment_id' );
										$existing_flow_payment_id = $potential_order->get_meta( '_cko_flow_payment_id' );
										$existing_payment_session_id = $potential_order->get_meta( '_cko_payment_session_id' );
										
										// CRITICAL: Don't reuse if order has different payment_session_id
										// Each payment session should have its own order
										if ( ! empty( $payment_session_id ) && ! empty( $existing_payment_session_id ) && $existing_payment_session_id !== $payment_session_id ) {
											if ( $is_debug ) {
												WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Order ' . $potential_order->get_id() . ' has different payment_session_id (' . $existing_payment_session_id . ' vs ' . $payment_session_id . ') - NOT reusing. Each payment session needs its own order.' );
											}
											continue; // Skip this order, check next one
										}
										
										if ( ! empty( $existing_transaction_id ) || ! empty( $existing_payment_id ) || ! empty( $existing_flow_payment_id ) ) {
											if ( $is_debug ) {
												WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Order ' . $potential_order->get_id() . ' already has payment ID/transaction ID - NOT reusing' );
											}
											continue; // Skip this order, check next one
										}
										
										// CRITICAL FIX: Use utility function to convert order total to currency subunit format
										// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
										$potential_order_currency = $potential_order->get_currency();
										$order_total_decimal = (float) $potential_order->get_total();
										$order_amount = (int) WC_Checkoutcom_Utility::value_to_decimal( $order_total_decimal, $potential_order_currency );
										if ( $order_amount === $payment_amount ) {
											$order = $potential_order;
											$order_id = $order->get_id();
											if ( $is_debug ) {
												WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Order found by email and amount match (fallback) - Order ID: ' . $order_id . ', Status: ' . $potential_order_status );
											}
											break;
										}
									}
								}
							}
							
							if ( ! $order ) {
								// Last resort: Create order from cart and payment details
								// This happens when 3DS redirect occurs before form submission
								if ( $is_debug ) {
									WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order not found - checking for existing order with same session+cart hash before creating new one' );
								}
								
								if ( ! WC()->cart || WC()->cart->is_empty() ) {
									// If we have payment details, create minimal order
									if ( ! empty( $payment_details ) && ! empty( $payment_id ) ) {
										$order = $this->create_minimal_order_from_payment_details( $payment_id, $payment_details );
										
										if ( ! is_wp_error( $order ) && $order ) {
											if ( $is_debug ) {
												WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Minimal order created from payment details - Order ID: ' . $order->get_id() );
											}
											$order_id = $order->get_id();
											// Continue with normal flow - order now exists
										} else {
											WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Cannot create order - cart is empty and minimal order creation failed' );
											wp_die( esc_html__( 'Order not found and cart is empty. Please contact support.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
										}
									} else {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Cart is empty, cannot create order' );
										wp_die( esc_html__( 'Order not found and cart is empty. Please contact support.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
									}
								}
								
								// Get customer info from payment details
								$customer_email = '';
								$customer_id = 0;
								
								if ( $payment_details && isset( $payment_details['customer']['email'] ) ) {
									$customer_email = $payment_details['customer']['email'];
									// Try to find customer by email
									$user = get_user_by( 'email', $customer_email );
									if ( $user ) {
										$customer_id = $user->ID;
									}
								}
								
								// Create new order if no reusable order found
								if ( ! $order ) {
									if ( $is_debug ) {
										WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Creating new order - Customer ID: ' . $customer_id . ', Email: ' . $customer_email );
									}
									
									$order = wc_create_order( array( 'customer_id' => $customer_id ) );
								
									if ( ! $order || is_wp_error( $order ) ) {
										// Try to create minimal order from payment details
										if ( ! empty( $payment_details ) && ! empty( $payment_id ) ) {
											$order = $this->create_minimal_order_from_payment_details( $payment_id, $payment_details );
											
											if ( ! is_wp_error( $order ) && $order ) {
												if ( $is_debug ) {
													WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Minimal order created successfully - Order ID: ' . $order->get_id() );
												}
												$order_id = $order->get_id();
												// Continue with normal flow - order now exists
											} else {
												WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Failed to create order' );
												wp_die( esc_html__( 'Failed to create order. Please contact support.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
											}
										} else {
											WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Failed to create order and payment details not available' );
											wp_die( esc_html__( 'Failed to create order. Please contact support.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
										}
									}
									
									// Set customer email
									if ( ! empty( $customer_email ) ) {
										$order->set_billing_email( $customer_email );
									}
									
									// Set billing address from payment details if available
									if ( $payment_details && isset( $payment_details['billing_address'] ) ) {
										$billing = $payment_details['billing_address'];
										if ( isset( $billing['address_line1'] ) ) $order->set_billing_address_1( $billing['address_line1'] );
										if ( isset( $billing['address_line2'] ) ) $order->set_billing_address_2( $billing['address_line2'] );
										if ( isset( $billing['city'] ) ) $order->set_billing_city( $billing['city'] );
										if ( isset( $billing['state'] ) ) $order->set_billing_state( $billing['state'] );
										if ( isset( $billing['zip'] ) ) $order->set_billing_postcode( $billing['zip'] );
										if ( isset( $billing['country'] ) ) $order->set_billing_country( $billing['country'] );
										if ( isset( $payment_details['customer']['name'] ) ) {
											$name_parts = explode( ' ', $payment_details['customer']['name'], 2 );
											$order->set_billing_first_name( $name_parts[0] ?? '' );
											$order->set_billing_last_name( $name_parts[1] ?? '' );
										}
									}
									
									// Add cart items
									foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
										$product = $cart_item['data'];
										$order->add_product( $product, $cart_item['quantity'], array(
											'subtotal' => $cart_item['line_subtotal'],
											'total'    => $cart_item['line_total'],
										) );
									}
									
									// Set shipping method if available
									$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
									$shipping_added_from_session = false;
									if ( ! empty( $chosen_shipping_methods ) ) {
										$shipping_packages = WC()->shipping->get_packages();
										foreach ( $chosen_shipping_methods as $package_key => $method ) {
											if ( isset( $shipping_packages[ $package_key ] ) ) {
												$package = $shipping_packages[ $package_key ];
												if ( isset( $package['rates'][ $method ] ) ) {
													$shipping_rate = $package['rates'][ $method ];
													$item = new WC_Order_Item_Shipping();
													$item->set_props( array(
														'method_title' => $shipping_rate->get_label(),
														'method_id'    => $shipping_rate->get_id(),
														'total'        => wc_format_decimal( $shipping_rate->get_cost() ),
														'taxes'        => $shipping_rate->get_taxes(),
													) );
													$order->add_item( $item );
													$shipping_added_from_session = true;
												}
											}
										}
									}
									
									// CRITICAL FIX: If shipping wasn't added from session (common after 3DS redirect),
									// add it from payment_details which contains the actual payment items including shipping
									if ( ! $shipping_added_from_session && ! empty( $payment_details ) ) {
										$this->add_shipping_from_payment_details( $order, $payment_details );
									}
									
									// Calculate totals
									$order->calculate_totals();
									
									// Set payment method
									$order->set_payment_method( $this->id );
									
									// CRITICAL: Save payment type to order meta BEFORE getting title (so helper method can find it)
									// Check payment_type first (for Google Pay, Apple Pay, etc.) before checking source type
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ========== PAYMENT TYPE DETECTION FOR TITLE ==========' );
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] Order ID: ' . $order->get_id() );
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] Payment details available?: ' . ( ! empty( $payment_details ) ? 'YES' : 'NO' ) );
									if ( ! empty( $payment_details ) ) {
										WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] Payment details keys: ' . implode( ', ', array_keys( $payment_details ) ) );
										WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] payment_details[payment_type]: ' . ( isset( $payment_details['payment_type'] ) ? $payment_details['payment_type'] : 'NOT SET' ) );
										if ( isset( $payment_details['source'] ) && is_array( $payment_details['source'] ) ) {
											WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] payment_details[source] keys: ' . implode( ', ', array_keys( $payment_details['source'] ) ) );
											WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] payment_details[source][type]: ' . ( isset( $payment_details['source']['type'] ) ? $payment_details['source']['type'] : 'NOT SET' ) );
											WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] payment_details[source][card_wallet_type]: ' . ( isset( $payment_details['source']['card_wallet_type'] ) ? $payment_details['source']['card_wallet_type'] : 'NOT SET' ) );
										}
									}
									$existing_payment_type_meta = $order->get_meta( '_cko_flow_payment_type' );
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] Existing payment_type in order meta: ' . ( $existing_payment_type_meta ?: 'NOT SET' ) );
									
									$flow_payment_type_for_title = '';
									if ( ! empty( $payment_details ) ) {
										// CRITICAL FIX: Check card_wallet_type FIRST before checking payment_type
										// Google Pay/Apple Pay have payment_type="Regular" but card_wallet_type="GooglePay"/"ApplePay"
										if ( isset( $payment_details['source']['card_wallet_type'] ) ) {
											$card_wallet_type = strtolower( $payment_details['source']['card_wallet_type'] );
											if ( $card_wallet_type === 'googlepay' ) {
												$flow_payment_type_for_title = 'googlepay';
												WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ✅ Detected Google Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
											} elseif ( $card_wallet_type === 'applepay' ) {
												$flow_payment_type_for_title = 'applepay';
												WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ✅ Detected Apple Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
											}
										}
										// If card_wallet_type didn't identify it, check payment_type
										if ( empty( $flow_payment_type_for_title ) && isset( $payment_details['payment_type'] ) ) {
											$payment_type_raw = $payment_details['payment_type'];
											// CRITICAL FIX: When payment_type is "Regular", check source.type FIRST before normalizing to "card"
											// For APMs (Alma, PayPal, etc.), payment_type="Regular" but source.type="alma"/"paypal"/etc.
											if ( strtolower( $payment_type_raw ) === 'regular' ) {
												// Check if source.type exists and is NOT "card" (i.e., it's an APM)
												if ( isset( $payment_details['source']['type'] ) && strtolower( $payment_details['source']['type'] ) !== 'card' ) {
													$flow_payment_type_for_title = strtolower( $payment_details['source']['type'] );
													WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ✅ Found APM via source.type: ' . $flow_payment_type_for_title . ' (payment_type was "Regular")' );
												} else {
													// No source.type or source.type is "card" - normalize to "card"
													$flow_payment_type_for_title = 'card';
													WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ⚠️ Normalized payment_type from "Regular" to "card"' );
												}
											} else {
												$flow_payment_type_for_title = $payment_type_raw;
												WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ✅ Found payment_type in payment_details: ' . $flow_payment_type_for_title );
											}
										} elseif ( empty( $flow_payment_type_for_title ) && isset( $payment_details['source']['type'] ) ) {
											$flow_payment_type_for_title = $payment_details['source']['type'];
											WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ⚠️ Found source.type in payment_details (fallback): ' . $flow_payment_type_for_title );
										}
									}
									// Fallback to order meta if payment_details doesn't have it
									if ( empty( $flow_payment_type_for_title ) ) {
										$flow_payment_type_for_title = $order->get_meta( '_cko_flow_payment_type' );
										WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ⚠️ Using payment_type from order meta (fallback): ' . ( $flow_payment_type_for_title ?: 'NOT SET' ) );
									}
									// Save to order meta if we found it
									if ( ! empty( $flow_payment_type_for_title ) ) {
										$order->update_meta_data( '_cko_flow_payment_type', $flow_payment_type_for_title );
										WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ✅ Saving payment_type to order meta: ' . $flow_payment_type_for_title );
									} else {
										WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ❌ ERROR: No payment_type found anywhere!' );
									}
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] Final flow_payment_type_for_title: ' . ( $flow_payment_type_for_title ?: 'EMPTY' ) );
									WC_Checkoutcom_Utility::logger( '[HANDLE 3DS RETURN] ========== END PAYMENT TYPE DETECTION FOR TITLE ==========' );
									
									// Get payment method title based on actual payment type used
									$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
									if ( $gateway_debug ) {
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Setting payment method title - Location: handle_3ds_return() around line 3477' );
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order ID: ' . $order->get_id() );
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Payment type saved to meta: ' . ( $flow_payment_type_for_title ?: 'EMPTY' ) );
									}
									WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Calling get_payment_method_title_by_type() with order ID: ' . $order->get_id() );
									$payment_method_title = $this->get_payment_method_title_by_type( $order, $payment_details );
									WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Title returned from helper: ' . $payment_method_title );
									$order->set_payment_method_title( $payment_method_title );
									if ( $gateway_debug ) {
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ✅ Title set to: ' . $payment_method_title );
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order payment method title after setting: ' . $order->get_payment_method_title() );
									}
									// Verify after save
									$order->save();
									$reloaded_order = wc_get_order( $order->get_id() );
									WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] After save and reload - Title: ' . ( $reloaded_order ? $reloaded_order->get_payment_method_title() : 'ORDER NOT FOUND' ) );
									
									// Save payment session ID (only if not already set)
									if ( ! empty( $payment_session_id ) ) {
										$existing_order_session_id = $order->get_meta( '_cko_payment_session_id' );
										if ( empty( $existing_order_session_id ) ) {
											$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
											WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment session ID saved to order (from session) - Order ID: ' . $order_id . ', Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '...' );
										} else {
											WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment session ID already exists in order (from session) - Order ID: ' . $order_id . ', Existing Payment Session ID: ' . substr( $existing_order_session_id, 0, 20 ) . '..., New Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
										}
									}
									
									// Store save card preference from GET parameter (if available in URL)
									$save_card_from_get = isset( $_GET['cko-save-card'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-save-card'] ) ) : '';
									if ( 'yes' === $save_card_from_get ) {
										$order->update_meta_data( '_cko_save_card_preference', 'yes' );
									}
									
									// Set status to pending
									$order->set_status( 'pending' );
									$order->save();
									if ( $gateway_debug ) {
										WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order saved - Title after save: ' . $order->get_payment_method_title() );
										// Reload order to check if title persisted
										$reloaded_order = wc_get_order( $order->get_id() );
										if ( $reloaded_order ) {
											WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order reloaded - Title after reload: ' . $reloaded_order->get_payment_method_title() );
										}
									}
									
									$order_id = $order->get_id();
									
									// PERFORMANCE: Defer webhook processing - check if already processed first
									if ( class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
										$already_processed = $order->get_meta( 'cko_payment_authorized' ) || $order->get_meta( 'cko_payment_captured' );
										if ( ! $already_processed ) {
											WC_Checkout_Com_Webhook_Queue::process_pending_webhooks_for_order( $order );
										}
									}
								}
							}
						}
					}
				} catch ( Exception $e ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] EXCEPTION during order lookup: ' . $e->getMessage() );
				
				// Try to create minimal order from payment details as fallback
				if ( ! empty( $payment_details ) && ! empty( $payment_id ) ) {
					try {
						$order = $this->create_minimal_order_from_payment_details( $payment_id, $payment_details );
						
						if ( ! is_wp_error( $order ) && $order ) {
							// Continue with normal flow - order now exists
						} else {
							wp_die( esc_html__( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
						}
					} catch ( Exception $fallback_exception ) {
						wp_die( esc_html__( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
					}
				} else {
					wp_die( esc_html__( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
				}
			}
		}
		
		// PERFORMANCE: Check if payment is already processed BEFORE fetching payment details
		// CRITICAL: Refresh order from database first to get latest webhook updates
		if ( $order && $order_id ) {
			$order = wc_get_order( $order_id );
		}
		$existing_payment = $order->get_meta( '_cko_payment_id' );
		
		if ( $existing_payment === $payment_id ) {
			// CRITICAL FIX: Check order status before redirecting
			$current_order_status = $order->get_status();
			
			// CRITICAL: Only redirect to thank you page if order is ACTUALLY successful
			// Status must be processing, completed, or on-hold (NOT pending or failed)
			if ( in_array( $current_order_status, array( 'processing', 'completed', 'on-hold' ), true ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment already processed successfully - Order ID: ' . $order_id . ', Status: ' . $current_order_status . ' - Redirecting to thank you page' );
				$return_url = $this->get_return_url( $order );
				wp_safe_redirect( $return_url );
				exit;
			}
			
			// RETRY PAYMENT FIX: If order is failed or pending, DON'T assume it's a failure
			// This could be a retry payment where the order was previously failed but new payment succeeded
			// Continue processing to verify actual payment status from Checkout.com API
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order has payment ID but status is ' . $current_order_status . ' - continuing to verify payment status from API. Order ID: ' . $order_id );
			
			// Update payment session ID if provided in URL (ensures webhook matching works)
			$payment_session_id_from_url = isset( $_GET['cko-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-session-id'] ) ) : '';
			$order_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
			if ( ! empty( $payment_session_id_from_url ) && $payment_session_id_from_url !== $order_payment_session_id ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Updating payment session ID for webhook matching. Old: ' . $order_payment_session_id . ', New: ' . $payment_session_id_from_url );
				$order->update_meta_data( '_cko_payment_session_id', $payment_session_id_from_url );
				$order->save();
			}
		}
		
		// PERFORMANCE: Use cached payment details if available, otherwise fetch
		// For fast path (order_id provided), payment details may not be cached yet
		if ( empty( $payment_details ) ) {
			// Initialize SDK if not already cached
			if ( null === $sdk_builder_cache ) {
				$checkout = new Checkout_SDK();
				$sdk_builder_cache = $checkout->get_builder();
			}
			$builder = $sdk_builder_cache;
			
			if ( ! $builder ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] WARNING: SDK builder not initialized - vendor/autoload.php may be missing' );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] For Flow payments, payment details are handled via webhooks, so this may not be critical' );
				// For Flow payments, we can continue without fetching payment details here
				// Payment will be processed via webhook or payment ID from form
				// Set payment_details to null and continue
				$payment_details = null;
			} else {
				// Fetch and cache payment details
				if ( ! isset( $payment_details_cache[ $payment_id ] ) ) {
				try {
					$payment_details_cache[ $payment_id ] = $builder->getPaymentsClient()->getPaymentDetails( $payment_id );
				} catch ( Exception $e ) {
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Failed to fetch payment details: ' . $e->getMessage() );
					throw $e;
				}
				}
				$payment_details = $payment_details_cache[ $payment_id ];
			}
		}
		
		// Check if payment is approved
		try {
			// CRITICAL FIX: Refresh order from database to get latest status
			// The webhook may have updated the order status while we were processing
			// WooCommerce caches the order object, so we need to force a fresh read
			if ( $order && $order_id ) {
				// Clear any cached data and reload from database
				$order = wc_get_order( $order_id );
				if ( $is_debug ) {
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Refreshed order from database - Order ID: ' . $order_id . ', Status: ' . ( $order ? $order->get_status() : 'ORDER NOT FOUND' ) );
				}
			}
			
			// If payment_details is null (SDK not available), we can't verify - assume approved and let webhooks handle
			if ( empty( $payment_details ) && ! empty( $payment_id ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment details not available (SDK missing), but payment ID exists: ' . $payment_id );
				// Assume approved - webhooks will handle final status
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Assuming payment approved (webhooks will verify final status)' );
				$is_approved = true;
			} else {
				// TRUST THE API RESPONSE - payment_details['approved'] is the authoritative status for THIS payment
				// Don't override based on order status - order may be 'failed' from a PREVIOUS payment attempt (retry scenario)
				$is_approved = isset( $payment_details['approved'] ) ? $payment_details['approved'] : false;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment details available - API approved status: ' . ( $is_approved ? 'TRUE' : 'FALSE' ) . ', Payment ID: ' . $payment_id );
			}
			
			if ( ! $is_approved ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment not approved - Payment ID: ' . $payment_id );
				
				// Get error message from payment details if available
				$error_message = __( 'Payment was not approved. Please try again.', 'checkout-com-unified-payments-api' );
				if ( isset( $payment_details['response_summary'] ) ) {
					$error_message = sanitize_text_field( $payment_details['response_summary'] );
				} elseif ( isset( $payment_details['status'] ) ) {
					$error_message = sprintf( __( 'Payment failed with status: %s', 'checkout-com-unified-payments-api' ), esc_html( $payment_details['status'] ) );
				}
				
				// If we have an order, update it and redirect to checkout/order-pay with error
				if ( $order ) {
					// CRITICAL: Set addresses consistently for failed payments (same logic as successful payments)
					// This ensures addresses are always visible regardless of payment outcome
					// Priority: 1) payment_details (if available), 2) POST data, 3) WC()->customer, 4) Preserve existing
					if ( $is_debug ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [ADDRESS DEBUG] Payment failed - Setting addresses consistently' );
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [ADDRESS DEBUG] Payment details available: ' . ( $payment_details ? 'YES' : 'NO' ) . ', billing_address in payment_details: ' . ( isset( $payment_details['billing_address'] ) ? 'YES' : 'NO' ) );
					}
					$this->set_order_addresses_consistently( $order, $payment_details );
					
					// Save addresses BEFORE marking as failed
					$order->save();
					if ( $is_debug ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [ADDRESS DEBUG] Addresses saved BEFORE marking as failed - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
					}
					
					// Update order status to failed
					$order->update_status( 'failed', __( 'Payment was not approved by Checkout.com', 'checkout-com-unified-payments-api' ) );
					
					// Save payment ID to order for reference
					if ( ! empty( $payment_id ) ) {
						$order->update_meta_data( '_cko_payment_id', $payment_id );
						
						// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
						$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
						if ( empty( $existing_flow_payment_id ) ) {
							$order->update_meta_data( '_cko_flow_payment_id', $payment_id );
						} else {
							WC_Checkoutcom_Utility::logger( '[3DS RETURN] Payment ID already exists in order (failed payment) - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $payment_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
						}
					}
					
					// Save order again after marking as failed
					$order->save();
					if ( $is_debug ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [ADDRESS DEBUG] Addresses saved AFTER marking as failed - Billing: ' . $order->get_billing_address_1() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_country() . ' | Shipping: ' . $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_country() );
					}
					
					// Add error notice
					WC_Checkoutcom_Utility::wc_add_notice_self( $error_message, 'error' );
					
					// Determine redirect URL based on context
					if ( ! empty( $order_id ) && ! empty( $order_key ) ) {
						// Order-pay page: redirect back to order-pay page
						$redirect_url = wc_get_endpoint_url( 'order-pay', $order_id, wc_get_checkout_url() );
						$redirect_url = add_query_arg( array(
							'pay_for_order' => 'true',
							'key' => $order_key,
							'payment_failed' => '1',
						), $redirect_url );
					} else {
						// Regular checkout: redirect to checkout page
						$redirect_url = add_query_arg( 'payment_failed', '1', wc_get_checkout_url() );
					}
					
					wp_safe_redirect( $redirect_url );
					exit;
				} else {
					// No order found - try to create minimal order
					if ( ! empty( $payment_details ) && ! empty( $payment_id ) ) {
						$order = $this->create_minimal_order_from_payment_details( $payment_id, $payment_details );
						
						if ( ! is_wp_error( $order ) && $order ) {
							// Update order status to failed
							$order->update_status( 'failed', __( 'Payment was not approved by Checkout.com', 'checkout-com-unified-payments-api' ) );
							$order->save();
							
							// Add error notice
							WC_Checkoutcom_Utility::wc_add_notice_self( $error_message, 'error' );
							
							// Redirect to checkout page
							$redirect_url = add_query_arg( 'payment_failed', '1', wc_get_checkout_url() );
							wp_safe_redirect( $redirect_url );
							exit;
						}
					}
					
					// If minimal order creation also failed, show error
					wp_die( esc_html( $error_message ), esc_html__( 'Payment Failed', 'checkout-com-unified-payments-api' ), array( 'response' => 400 ) );
				}
			}
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] EXCEPTION: ' . $e->getMessage() );
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Exception trace: ' . $e->getTraceAsString() );
			}
			
			// PERFORMANCE OPTIMIZATION Phase 2: Only reload order if not already cached
			// Try to find order and redirect to checkout with error
			if ( ! empty( $order_id ) && ( ! $order || $order->get_id() !== $order_id ) ) {
				$order = wc_get_order( $order_id );
			}
			if ( $order ) {
				$order->update_status( 'failed', __( 'Payment processing failed due to an error.', 'checkout-com-unified-payments-api' ) );
				WC_Checkoutcom_Utility::wc_add_notice_self( __( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				wp_safe_redirect( wc_get_checkout_url() );
				exit;
			}
			wp_die( esc_html__( 'An error occurred while processing your payment. Please try again.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
		}
		
		// CRITICAL SECURITY CHECK: Validate payment amount matches order amount
		// This prevents cart manipulation attacks where user modifies cart during 3DS authentication
		// PERFORMANCE OPTIMIZATION: Check order status first (fastest check) - skip validation if already processed
		// Postage is added BEFORE payment session call, so payment amount already includes postage
		$order_status = $order->get_status();
		$payment_already_processed = in_array( $order_status, array( 'processing', 'completed', 'on-hold' ), true );
		
		// If status check is ambiguous (pending/failed), check payment IDs (only if needed)
		if ( ! $payment_already_processed ) {
			$existing_transaction_id = $order->get_transaction_id();
			$existing_payment_id = $order->get_meta( '_cko_payment_id' );
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			// Payment is already processed if it has any of these identifiers
			$payment_already_processed = ! empty( $existing_transaction_id ) || ! empty( $existing_payment_id ) || ! empty( $existing_flow_payment_id );
		}
		
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] Payment already processed check - status: ' . $order_status . ', result: ' . ( $payment_already_processed ? 'YES (skip validation)' : 'NO (run validation)' ) );
		}
		
		if ( ! $payment_already_processed && ! empty( $payment_details ) && isset( $payment_details['amount'] ) && $order ) {
			$payment_amount_subunits = (int) $payment_details['amount']; // Already in currency subunit format from API
			$order_currency = $order->get_currency();
			$order_total_decimal = (float) $order->get_total();
			// CRITICAL FIX: Use utility function to convert order total to currency subunit format
			// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
			$order_total_subunits = (int) WC_Checkoutcom_Utility::value_to_decimal( $order_total_decimal, $order_currency );
			$currency = isset( $payment_details['currency'] ) ? $payment_details['currency'] : '';
			
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] Validating payment amount - Payment: ' . $payment_amount_subunits . ' subunits (' . $order_currency . '), Order: ' . $order_total_subunits . ' subunits (decimal: ' . $order_total_decimal . ')' );
			}
			
			// Check currency match first
			if ( ! empty( $currency ) && ! empty( $order_currency ) && strtoupper( $currency ) !== strtoupper( $order_currency ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] ERROR: Payment currency (' . $currency . ') does not match order currency (' . $order_currency . ')' );
				
				// Mark order as failed due to security check - webhooks should NOT process this
				$order->update_meta_data( '_cko_security_check_failed', 'currency_mismatch' );
				$order->update_status( 'failed', __( 'Payment security check failed: Currency mismatch. Cart may have been modified during payment.', 'checkout-com-unified-payments-api' ) );
				$order->save();
				WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Security check failed: Payment currency does not match order. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				wp_safe_redirect( wc_get_checkout_url() );
				exit;
			}
			
			// Check amount match (allow 1 subunit difference for rounding)
			// For zero-decimal currencies, this allows 1 unit difference
			// For two-decimal currencies, this allows 1 cent difference
			// For three-decimal currencies, this allows 1 mill difference
			if ( abs( $payment_amount_subunits - $order_total_subunits ) > 1 ) {
				// Convert back to decimal for error message display
				$payment_amount_display = WC_Checkoutcom_Utility::decimal_to_value( $payment_amount_subunits, $order_currency );
				$order_total_display = WC_Checkoutcom_Utility::decimal_to_value( $order_total_subunits, $order_currency );
				
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] ERROR: Payment amount (' . $payment_amount_subunits . ' subunits = ' . $payment_amount_display . ' ' . $order_currency . ') does not match order total (' . $order_total_subunits . ' subunits = ' . $order_total_display . ' ' . $order_currency . '). Possible cart manipulation attack.' );
				
				// Mark order as failed due to security check - webhooks should NOT process this
				$order->update_meta_data( '_cko_security_check_failed', 'amount_mismatch' );
				$order->update_status( 'failed', sprintf( __( 'Payment security check failed: Amount mismatch. Payment amount (%s) does not match order total (%s). Cart may have been modified during payment.', 'checkout-com-unified-payments-api' ), wc_price( $payment_amount_display, array( 'currency' => $order_currency ) ), wc_price( $order_total_display, array( 'currency' => $order_currency ) ) ) );
				$order->save();
				WC_Checkoutcom_Utility::wc_add_notice_self( __( 'Security check failed: Payment amount does not match order total. Your cart may have been modified during payment. Please try again.', 'checkout-com-unified-payments-api' ), 'error' );
				wp_safe_redirect( wc_get_checkout_url() );
				exit;
			}
			
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] Payment amount validation passed' );
			}
		} elseif ( $payment_already_processed ) {
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SECURITY] Skipping amount validation - payment already processed (status: ' . $order_status . '). Shipping is now added during order creation, so totals should match.' );
			}
		}
		
		// Process the payment by storing payment data in order meta (WordPress-compliant approach)
		// CRITICAL: Prioritize payment_type over source.type for tokenized payments (Google Pay, Apple Pay, etc.)
		// For tokenized payments, source.type is 'card' but payment_type correctly identifies the payment method
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== PAYMENT TYPE DETECTION DEBUG ==========' );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment ID: ' . $payment_id );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment details available?: ' . ( ! empty( $payment_details ) ? 'YES' : 'NO' ) );
		if ( ! empty( $payment_details ) ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment details keys: ' . implode( ', ', array_keys( $payment_details ) ) );
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] payment_details[payment_type]: ' . ( isset( $payment_details['payment_type'] ) ? $payment_details['payment_type'] : 'NOT SET' ) );
			if ( isset( $payment_details['source'] ) && is_array( $payment_details['source'] ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] payment_details[source] keys: ' . implode( ', ', array_keys( $payment_details['source'] ) ) );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] payment_details[source][type]: ' . ( isset( $payment_details['source']['type'] ) ? $payment_details['source']['type'] : 'NOT SET' ) );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] payment_details[source][card_wallet_type]: ' . ( isset( $payment_details['source']['card_wallet_type'] ) ? $payment_details['source']['card_wallet_type'] : 'NOT SET' ) );
			} else {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] payment_details[source]: NOT SET or NOT ARRAY' );
			}
		}
		
		// CRITICAL FIX: Check card_wallet_type FIRST before normalizing "Regular" to "card"
		// Google Pay and Apple Pay payments have payment_type="Regular" but card_wallet_type="GooglePay"/"ApplePay"
		if ( ! empty( $payment_details ) && isset( $payment_details['source']['card_wallet_type'] ) ) {
			$card_wallet_type = strtolower( $payment_details['source']['card_wallet_type'] );
			if ( $card_wallet_type === 'googlepay' ) {
				$payment_type = 'googlepay';
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Detected Google Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
			} elseif ( $card_wallet_type === 'applepay' ) {
				$payment_type = 'applepay';
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Detected Apple Pay via card_wallet_type: ' . $payment_details['source']['card_wallet_type'] );
			} else {
				// Unknown wallet type, fall through to payment_type check
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Unknown card_wallet_type: ' . $payment_details['source']['card_wallet_type'] . ' - checking payment_type' );
			}
		}
		
		// If card_wallet_type didn't identify the payment method, check payment_type
		if ( empty( $payment_type ) && ! empty( $payment_details ) && isset( $payment_details['payment_type'] ) ) {
			$payment_type_raw = $payment_details['payment_type'];
			// CRITICAL FIX: When payment_type is "Regular", check source.type FIRST before normalizing to "card"
			// For APMs (Alma, PayPal, etc.), payment_type="Regular" but source.type="alma"/"paypal"/etc.
			if ( strtolower( $payment_type_raw ) === 'regular' ) {
				// Check if source.type exists and is NOT "card" (i.e., it's an APM)
				if ( isset( $payment_details['source']['type'] ) && strtolower( $payment_details['source']['type'] ) !== 'card' ) {
					$payment_type = strtolower( $payment_details['source']['type'] );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Found APM via source.type: ' . $payment_type . ' (payment_type was "Regular")' );
				} else {
					// No source.type or source.type is "card" - normalize to "card"
					$payment_type = 'card';
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Normalized payment_type from "Regular" to "card"' );
				}
			} else {
				$payment_type = $payment_type_raw;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Using payment_type: ' . $payment_type );
			}
		} elseif ( empty( $payment_type ) && isset( $payment_details['source']['type'] ) ) {
			$payment_type = $payment_details['source']['type'];
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Using source.type (fallback): ' . $payment_type );
		} elseif ( empty( $payment_type ) ) {
			$payment_type = 'card';
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Using default: card' );
		}
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Final payment_type to store: ' . $payment_type );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== END PAYMENT TYPE DETECTION DEBUG ==========' );
		
		// Store payment data in order meta instead of modifying $_POST (WordPress coding standards compliant)
		// process_payment() will check order meta as fallback if $_POST is not available
		if ( $order ) {
			// CRITICAL: Check if this is a multi-tab scenario - don't overwrite primary payment ID
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			$existing_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
			$current_payment_session_id = isset( $_GET['cko-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-payment-session-id'] ) ) : '';
			
			// Determine if this is a different payment attempt (multi-tab scenario)
			$is_different_payment = ! empty( $existing_flow_payment_id ) && $existing_flow_payment_id !== $payment_id;
			$is_different_session = ! empty( $existing_payment_session_id ) && ! empty( $current_payment_session_id ) && $existing_payment_session_id !== $current_payment_session_id;
			
			if ( $is_different_payment || $is_different_session ) {
				// MULTI-TAB: This is a secondary payment - DO NOT overwrite primary
				WC_Checkoutcom_Utility::logger( 
					sprintf(
						'[FLOW 3DS API] ⚠️ MULTI-TAB DETECTED - NOT overwriting primary payment. Primary: %s (Session: %s), This: %s (Session: %s)',
						$existing_flow_payment_id,
						$existing_payment_session_id,
						$payment_id,
						$current_payment_session_id
					)
				);
			} else {
				// Normal case: Store as primary payment ID
				$order->update_meta_data( '_cko_flow_payment_id', $payment_id );
				if ( empty( $order->get_meta( '_cko_payment_id' ) ) ) {
					$order->update_meta_data( '_cko_payment_id', $payment_id );
				}
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Stored primary payment_id in order meta: ' . $payment_id );
			}
			
			// Always store payment type (this doesn't affect multi-tab logic)
			$order->update_meta_data( '_cko_flow_payment_type', $payment_type );
			$order->save();
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Stored payment_type in order meta: ' . $payment_type );
			// Verify it was stored
			$stored_payment_type = $order->get_meta( '_cko_flow_payment_type' );
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Verification - Retrieved payment_type from order meta: ' . $stored_payment_type );
		} else {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ WARNING: Order object not available - cannot store payment_type' );
		}
		
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Calling process_payment for order: ' . $order_id );
		}
		
		// Process the payment
		$result = $this->process_payment( $order_id );
		
		// PERFORMANCE OPTIMIZATION Phase 2: Cache order object - avoid redundant loading
		// Run card saving logic here in handle_3ds_return() AFTER process_payment()
		// This ensures card saving runs even if duplicate prevention triggered in process_payment()
		// Only reload order if we don't already have it (process_payment may have returned it)
		if ( ! empty( $order_id ) && ( ! $order || $order->get_id() !== $order_id ) ) {
			$order = wc_get_order( $order_id );
		}
		
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Checking conditions - Result: ' . ( isset( $result['result'] ) ? $result['result'] : 'NOT SET' ) . ', Order ID: ' . $order_id );
		}
		
		if ( isset( $result['result'] ) && 'success' === $result['result'] && $order ) {
			
			// Get payment type and check if card saving is enabled
			$flow_payment_type_for_save = $payment_type;
			$save_card_enabled = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
			
			// Check save card preference (priority: order metadata > cookie > GET > hidden field > POST > session)
			$save_card_from_order = $order->get_meta( '_cko_save_card_preference' );
			$save_card_from_cookie = isset( $_COOKIE['cko_flow_save_card_preference'] ) ? sanitize_text_field( $_COOKIE['cko_flow_save_card_preference'] ) : '';
				$save_card_from_get = isset( $_GET['cko-save-card'] ) ? sanitize_text_field( wp_unslash( $_GET['cko-save-card'] ) ) : '';
				$save_card_hidden = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
				$save_card_post = isset( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-wc_checkout_com_flow-new-payment-method'] ) ) : '';
			$save_card_session = WC()->session ? WC()->session->get( 'wc-wc_checkout_com_flow-new-payment-method' ) : '';
			
			// Determine if checkbox was checked
			// Priority: Order metadata > Cookie (survives 3DS redirects) > Hidden field > POST checkbox > GET parameter (may be stale) > Session
			// Note: GET parameter may have 'no' from payment session creation before checkbox was checked
			$save_card_checkbox = false;
			if ( 'yes' === $save_card_from_order ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in order metadata: YES' );
			} elseif ( 'yes' === $save_card_from_cookie ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in cookie: YES (survives 3DS redirects)' );
				$order->update_meta_data( '_cko_save_card_preference', 'yes' );
				$order->save();
				// Clear cookie after use
				setcookie( 'cko_flow_save_card_preference', '', time() - 3600, '/' );
			} elseif ( 'yes' === $save_card_hidden ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in hidden field: YES' );
				$order->update_meta_data( '_cko_save_card_preference', 'yes' );
				$order->save();
			} elseif ( 'true' === $save_card_post || 'yes' === $save_card_post ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in POST checkbox: YES' );
				$order->update_meta_data( '_cko_save_card_preference', 'yes' );
				$order->save();
			} elseif ( 'yes' === $save_card_from_get ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in GET parameter: YES' );
				$order->update_meta_data( '_cko_save_card_preference', 'yes' );
				$order->save();
			} elseif ( 'yes' === $save_card_session ) {
				$save_card_checkbox = true;
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference found in session: YES' );
				$order->update_meta_data( '_cko_save_card_preference', 'yes' );
				$order->save();
			} else {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Save card preference NOT found - Order meta: ' . $save_card_from_order . ', Cookie: ' . $save_card_from_cookie . ', GET: ' . $save_card_from_get . ', Hidden: ' . $save_card_hidden . ', POST: ' . $save_card_post . ', Session: ' . $save_card_session );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] DEBUG - Full POST data keys: ' . implode( ', ', array_keys( $_POST ) ) );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] DEBUG - Full GET data keys: ' . implode( ', ', array_keys( $_GET ) ) );
			}
			
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] Final check - Payment type: ' . $flow_payment_type_for_save . ', Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
			
			// Save card if all conditions are met
			if ( 'card' === $flow_payment_type_for_save && $save_card_enabled && $save_card_checkbox ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] ✅ All conditions met - Saving card for order: ' . $order_id );
				$this->flow_save_cards( $order, $payment_id );
				if ( WC()->session ) {
					WC()->session->__unset( 'wc-wc_checkout_com_flow-new-payment-method' );
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [CARD SAVING] ❌ Conditions NOT met - Payment type: ' . $flow_payment_type_for_save . ' (expected: card), Save enabled: ' . ( $save_card_enabled ? 'YES' : 'NO' ) . ', Checkbox: ' . ( $save_card_checkbox ? 'YES' : 'NO' ) );
			}

			// Subscription source-id save for 3DS returns.
			// process_payment()'s duplicate-prevention branches early-return BEFORE reaching
			// the subscription source-id save at line ~3699 — meaning on every 3DS return for
			// a subscription order, _cko_source_id never gets persisted on the subscription,
			// and the first renewal fails because there's no source to charge against.
			// Saving it here in handle_3ds_return() — after process_payment, regardless of
			// which branch process_payment took — closes that gap. save_source_id() is
			// idempotent (just writes meta) so it's safe even when the normal path already
			// saved it.
			if ( ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order_id ) )
				|| ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order ) ) ) {
				$existing_source_id = $order->get_meta( '_cko_source_id' );
				if ( ! empty( $existing_source_id ) ) {
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SUBSCRIPTION SOURCE] Source ID already saved (' . $existing_source_id . ') - skipping' );
				} else {
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SUBSCRIPTION SOURCE] Fetching payment details to persist source_id for subscription' );
					$source_request = new \WP_REST_Request( 'GET', '/ckoplugin/v1/payment-status' );
					$source_request->set_query_params( [ 'paymentId' => $payment_id ] );
					$source_response = cko_get_payment_status( $source_request );
					$source_status   = $source_response instanceof \WP_REST_Response ? $source_response->get_status() : 500;
					$source_data     = $source_response instanceof \WP_REST_Response ? $source_response->get_data() : null;

					if ( $source_status < 400 && is_array( $source_data ) && ! isset( $source_data['error'] ) && ! empty( $source_data['source']['id'] ) ) {
						WC_Checkoutcom_Subscription::save_source_id( $order_id, $order, $source_data['source']['id'] );
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SUBSCRIPTION SOURCE] ✅ Saved source_id ' . $source_data['source']['id'] . ' on order ' . $order_id );

						// Also save the preferred card scheme (mirrors the normal-path save at line ~3702).
						if ( 'card' === $flow_payment_type_for_save && ! empty( $source_data['source']['scheme'] ) ) {
							$this->save_preferred_card_scheme( $order_id, $order, $source_data['source']['scheme'] );
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SUBSCRIPTION SOURCE] ✅ Saved preferred card scheme: ' . $source_data['source']['scheme'] );
						}
					} else {
						$err = is_array( $source_data ) && isset( $source_data['error'] ) ? $source_data['error'] : 'Unknown error (HTTP ' . $source_status . ')';
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] [SUBSCRIPTION SOURCE] ⚠️ Failed to fetch payment details - source_id NOT saved: ' . $err );
					}
				}
			}
		}

		// Redirect after card saving logic completes
			if ( isset( $result['result'] ) && 'success' === $result['result'] && isset( $result['redirect'] ) ) {
				$redirect_url = $result['redirect'];
				
				// CRITICAL FIX: Clear any error notices from previous failed payment attempts
				// This prevents stale error messages from showing on the success page after a retry payment succeeds
				if ( function_exists( 'wc_clear_notices' ) ) {
					wc_clear_notices();
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Cleared WooCommerce notices before success redirect (prevents stale error messages from failed retries)' );
				}
				
				// CRITICAL FIX: Ensure order key is always in redirect URL, even for logged-in users
				// WooCommerce may require the order key for validation even for logged-in users
				if ( $order ) {
					$order_key = $order->get_order_key();
					$order_id = $order->get_id();
					
					// Check if order key is already in URL
					$order_key_in_url = strpos( $redirect_url, 'key=' ) !== false;
					
					if ( ! $order_key_in_url && ! empty( $order_key ) ) {
						// Order key not in URL - add it explicitly
						$separator = strpos( $redirect_url, '?' ) !== false ? '&' : '?';
						$redirect_url = $redirect_url . $separator . 'key=' . urlencode( $order_key );
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Order key was missing from redirect URL - added explicitly' );
					}
					
					// Also ensure order_id is in URL if missing
					$order_id_in_url = strpos( $redirect_url, 'order-received/' . $order_id ) !== false || strpos( $redirect_url, 'order_id=' . $order_id ) !== false;
					if ( ! $order_id_in_url ) {
						$separator = strpos( $redirect_url, '?' ) !== false ? '&' : '?';
						$redirect_url = $redirect_url . $separator . 'order_id=' . $order_id;
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ Order ID was missing from redirect URL - added explicitly' );
					}
				}
				
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== FINAL REDIRECT DEBUG ==========' );
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment processed successfully, redirecting to: ' . $redirect_url );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Just logging, value is sanitized
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order ID from GET: ' . ( isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 'NOT SET' ) );
				// Do not log order key - it's sensitive data that allows order access
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order key from GET: ' . ( isset( $_GET['key'] ) ? '(present)' : 'NOT SET' ) );
				if ( $order ) {
					$order_customer_id = $order->get_customer_id();
					$current_user_id = get_current_user_id();
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order ID from order object: ' . $order->get_id() );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order key from order object: ' . $order->get_order_key() );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order customer ID: ' . $order_customer_id );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Current logged-in user ID: ' . $current_user_id );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Customer IDs match?: ' . ( $order_customer_id == $current_user_id ? 'YES' : 'NO' ) );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Is guest order?: ' . ( $order_customer_id == 0 ? 'YES' : 'NO' ) );
					$order_key_in_redirect = strpos( $redirect_url, 'key=' ) !== false;
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Order key in redirect URL?: ' . ( $order_key_in_redirect ? 'YES' : 'NO' ) );
					if ( $order_customer_id == 0 && ! $order_key_in_redirect ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ❌ ERROR: Guest order but order key NOT in redirect URL!' );
					}
					if ( $order_customer_id > 0 && $order_customer_id != $current_user_id ) {
						WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ⚠️ WARNING: Order customer ID (' . $order_customer_id . ') does NOT match current user ID (' . $current_user_id . ')' );
						
						// CRITICAL FIX: If user is not logged in but order has customer_id, set order to guest
						// This allows WooCommerce to validate by order key instead of customer_id
						// This happens when user session is lost during 3DS redirect
						if ( $current_user_id == 0 && $order_key_in_redirect ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] 🔧 FIXING: User session lost during 3DS - setting order customer_id to 0 (guest) to allow order key validation' );
							$order->set_customer_id( 0 );
							$order->save();
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ✅ Order customer_id set to 0 - WooCommerce will validate by order key' );
						} elseif ( $current_user_id == 0 && ! $order_key_in_redirect ) {
							WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ❌ ERROR: User session lost AND order key missing - user will NOT be able to view order!' );
						}
					}
				}
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== END FINAL REDIRECT DEBUG ==========' );
				
				// Ensure headers are sent and redirect happens
				if ( ! headers_sent() ) {
					wp_safe_redirect( $redirect_url );
					exit;
				} else {
					// Headers already sent, use JavaScript redirect as fallback
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] WARNING: Headers already sent, using JavaScript redirect' );
					echo '<script>window.location.href = "' . esc_js( $redirect_url ) . '";</script>';
					exit;
				}
			} else {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment processing failed: ' . wp_json_encode( $result ) );
				
				// Payment failed - don't redirect to order received page
				// Instead, redirect back to checkout with error message
				if ( $order && $order->get_id() ) {
					// Update order status to failed if not already
					if ( 'failed' !== $order->get_status() ) {
						$order->update_status( 'failed', __( 'Payment processing failed', 'checkout-com-unified-payments-api' ) );
					}
					
					// Get error message from result if available
					$error_message = __( 'Payment processing failed. Please try again.', 'checkout-com-unified-payments-api' );
					if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
						$error_message = $result['error'];
					}
					
					// Add error notice
					WC_Checkoutcom_Utility::wc_add_notice_self( $error_message, 'error' );
					
					// Redirect to checkout page with error
					$redirect_url = add_query_arg( 'payment_failed', '1', wc_get_checkout_url() );
					WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Payment failed, redirecting to checkout page: ' . $redirect_url );
					if ( ! headers_sent() ) {
						wp_safe_redirect( $redirect_url );
						exit;
					} else {
						echo '<script>window.location.href = "' . esc_js( $redirect_url ) . '";</script>';
						exit;
					}
				}
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR - Payment processing failed: ' . wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
				wp_die( esc_html__( 'Payment processing failed. Please contact support.', 'checkout-com-unified-payments-api' ), esc_html__( 'Payment Error', 'checkout-com-unified-payments-api' ), array( 'response' => 500 ) );
			}
		
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ========== EXIT POINT ==========' );
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Code Version: 2025-12-01-18:50-fixed-syntax' );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Set addresses on order with consistent priority for both successful and failed payments.
	 * Priority: 1) payment_details, 2) POST data, 3) WC()->customer, 4) Preserve existing order addresses
	 *
	 * @param WC_Order $order Order object
	 * @param array    $payment_details Payment details from Checkout.com API (optional)
	 * @return void
	 */
	private function set_order_addresses_consistently( $order, $payment_details = null ) {
		$is_debug = defined( 'WP_DEBUG' ) && WP_DEBUG;
		
		// Priority 1: Set from payment_details if available (most accurate source from Checkout.com)
		if ( $payment_details && isset( $payment_details['billing_address'] ) ) {
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[SET ADDRESSES] Setting addresses from payment_details (Priority 1)' );
			}
			$billing = $payment_details['billing_address'];
			if ( isset( $billing['address_line1'] ) ) $order->set_billing_address_1( $billing['address_line1'] );
			if ( isset( $billing['address_line2'] ) ) $order->set_billing_address_2( $billing['address_line2'] );
			if ( isset( $billing['city'] ) ) $order->set_billing_city( $billing['city'] );
			if ( isset( $billing['state'] ) ) $order->set_billing_state( $billing['state'] );
			if ( isset( $billing['zip'] ) ) $order->set_billing_postcode( $billing['zip'] );
			if ( isset( $billing['country'] ) ) $order->set_billing_country( $billing['country'] );
			if ( isset( $payment_details['customer']['name'] ) ) {
				$name_parts = explode( ' ', $payment_details['customer']['name'], 2 );
				$order->set_billing_first_name( $name_parts[0] ?? '' );
				$order->set_billing_last_name( $name_parts[1] ?? '' );
			}
			if ( isset( $payment_details['customer']['email'] ) ) {
				$order->set_billing_email( $payment_details['customer']['email'] );
			}
			
			// Set shipping address from payment_details or copy from billing
			if ( isset( $payment_details['shipping_address'] ) ) {
				$shipping = $payment_details['shipping_address'];
				if ( isset( $shipping['address_line1'] ) ) $order->set_shipping_address_1( $shipping['address_line1'] );
				if ( isset( $shipping['address_line2'] ) ) $order->set_shipping_address_2( $shipping['address_line2'] );
				if ( isset( $shipping['city'] ) ) $order->set_shipping_city( $shipping['city'] );
				if ( isset( $shipping['state'] ) ) $order->set_shipping_state( $shipping['state'] );
				if ( isset( $shipping['zip'] ) ) $order->set_shipping_postcode( $shipping['zip'] );
				if ( isset( $shipping['country'] ) ) $order->set_shipping_country( $shipping['country'] );
			} else {
				// Shipping same as billing
				$order->set_shipping_first_name( $order->get_billing_first_name() );
				$order->set_shipping_last_name( $order->get_billing_last_name() );
				$order->set_shipping_address_1( $order->get_billing_address_1() );
				$order->set_shipping_address_2( $order->get_billing_address_2() );
				$order->set_shipping_city( $order->get_billing_city() );
				$order->set_shipping_state( $order->get_billing_state() );
				$order->set_shipping_postcode( $order->get_billing_postcode() );
				$order->set_shipping_country( $order->get_billing_country() );
			}
			return; // Addresses set from payment_details, done
		}
		
		// Priority 2: Set from POST data if available (from form submission)
		$has_post_addresses = ! empty( $_POST['billing_first_name'] ) || ! empty( $_POST['billing_address_1'] );
		if ( $has_post_addresses ) {
			if ( $is_debug ) {
				WC_Checkoutcom_Utility::logger( '[SET ADDRESSES] Setting addresses from POST data (Priority 2)' );
			}
			if ( isset( $_POST['billing_first_name'] ) ) $order->set_billing_first_name( sanitize_text_field( wp_unslash( $_POST['billing_first_name'] ) ) );
			if ( isset( $_POST['billing_last_name'] ) ) $order->set_billing_last_name( sanitize_text_field( wp_unslash( $_POST['billing_last_name'] ) ) );
			if ( isset( $_POST['billing_company'] ) ) $order->set_billing_company( sanitize_text_field( wp_unslash( $_POST['billing_company'] ) ) );
			if ( isset( $_POST['billing_address_1'] ) ) $order->set_billing_address_1( sanitize_text_field( wp_unslash( $_POST['billing_address_1'] ) ) );
			if ( isset( $_POST['billing_address_2'] ) ) $order->set_billing_address_2( sanitize_text_field( wp_unslash( $_POST['billing_address_2'] ) ) );
			if ( isset( $_POST['billing_city'] ) ) $order->set_billing_city( sanitize_text_field( wp_unslash( $_POST['billing_city'] ) ) );
			if ( isset( $_POST['billing_state'] ) ) $order->set_billing_state( sanitize_text_field( wp_unslash( $_POST['billing_state'] ) ) );
			if ( isset( $_POST['billing_postcode'] ) ) $order->set_billing_postcode( sanitize_text_field( wp_unslash( $_POST['billing_postcode'] ) ) );
			if ( isset( $_POST['billing_country'] ) ) $order->set_billing_country( sanitize_text_field( wp_unslash( $_POST['billing_country'] ) ) );
			if ( isset( $_POST['billing_phone'] ) ) $order->set_billing_phone( sanitize_text_field( wp_unslash( $_POST['billing_phone'] ) ) );
			if ( isset( $_POST['billing_email'] ) ) $order->set_billing_email( sanitize_email( wp_unslash( $_POST['billing_email'] ) ) );
			
			// Set shipping address
			$ship_to_different_address = isset( $_POST['ship_to_different_address'] ) ? (bool) wp_unslash( $_POST['ship_to_different_address'] ) : false;
			if ( $ship_to_different_address ) {
				if ( isset( $_POST['shipping_first_name'] ) ) $order->set_shipping_first_name( sanitize_text_field( wp_unslash( $_POST['shipping_first_name'] ) ) );
				if ( isset( $_POST['shipping_last_name'] ) ) $order->set_shipping_last_name( sanitize_text_field( wp_unslash( $_POST['shipping_last_name'] ) ) );
				if ( isset( $_POST['shipping_company'] ) ) $order->set_shipping_company( sanitize_text_field( wp_unslash( $_POST['shipping_company'] ) ) );
				if ( isset( $_POST['shipping_address_1'] ) ) $order->set_shipping_address_1( sanitize_text_field( wp_unslash( $_POST['shipping_address_1'] ) ) );
				if ( isset( $_POST['shipping_address_2'] ) ) $order->set_shipping_address_2( sanitize_text_field( wp_unslash( $_POST['shipping_address_2'] ) ) );
				if ( isset( $_POST['shipping_city'] ) ) $order->set_shipping_city( sanitize_text_field( wp_unslash( $_POST['shipping_city'] ) ) );
				if ( isset( $_POST['shipping_state'] ) ) $order->set_shipping_state( sanitize_text_field( wp_unslash( $_POST['shipping_state'] ) ) );
				if ( isset( $_POST['shipping_postcode'] ) ) $order->set_shipping_postcode( sanitize_text_field( wp_unslash( $_POST['shipping_postcode'] ) ) );
				if ( isset( $_POST['shipping_country'] ) ) $order->set_shipping_country( sanitize_text_field( wp_unslash( $_POST['shipping_country'] ) ) );
			} else {
				// Shipping same as billing
				$order->set_shipping_first_name( $order->get_billing_first_name() );
				$order->set_shipping_last_name( $order->get_billing_last_name() );
				$order->set_shipping_company( $order->get_billing_company() );
				$order->set_shipping_address_1( $order->get_billing_address_1() );
				$order->set_shipping_address_2( $order->get_billing_address_2() );
				$order->set_shipping_city( $order->get_billing_city() );
				$order->set_shipping_state( $order->get_billing_state() );
				$order->set_shipping_postcode( $order->get_billing_postcode() );
				$order->set_shipping_country( $order->get_billing_country() );
			}
			return; // Addresses set from POST data, done
		}
		
		// Priority 3: Set from WC()->customer if available (from WooCommerce customer session)
		if ( WC()->customer ) {
			$billing_address_1 = $order->get_billing_address_1();
			$billing_city = $order->get_billing_city();
			$billing_country = $order->get_billing_country();
			$order_addresses_empty = empty( $billing_address_1 ) || empty( $billing_city ) || empty( $billing_country );
			
			if ( $order_addresses_empty ) {
				if ( $is_debug ) {
					WC_Checkoutcom_Utility::logger( '[SET ADDRESSES] Setting addresses from WC()->customer (Priority 3)' );
				}
				$order->set_billing_first_name( WC()->customer->get_billing_first_name() );
				$order->set_billing_last_name( WC()->customer->get_billing_last_name() );
				$order->set_billing_company( WC()->customer->get_billing_company() );
				$order->set_billing_address_1( WC()->customer->get_billing_address_1() );
				$order->set_billing_address_2( WC()->customer->get_billing_address_2() );
				$order->set_billing_city( WC()->customer->get_billing_city() );
				$order->set_billing_state( WC()->customer->get_billing_state() );
				$order->set_billing_postcode( WC()->customer->get_billing_postcode() );
				$order->set_billing_country( WC()->customer->get_billing_country() );
				$order->set_billing_phone( WC()->customer->get_billing_phone() );
				$order->set_billing_email( WC()->customer->get_billing_email() );
				
				$order->set_shipping_first_name( WC()->customer->get_shipping_first_name() );
				$order->set_shipping_last_name( WC()->customer->get_shipping_last_name() );
				$order->set_shipping_company( WC()->customer->get_shipping_company() );
				$order->set_shipping_address_1( WC()->customer->get_shipping_address_1() );
				$order->set_shipping_address_2( WC()->customer->get_shipping_address_2() );
				$order->set_shipping_city( WC()->customer->get_shipping_city() );
				$order->set_shipping_state( WC()->customer->get_shipping_state() );
				$order->set_shipping_postcode( WC()->customer->get_shipping_postcode() );
				$order->set_shipping_country( WC()->customer->get_shipping_country() );
				
				// If shipping address is still empty, copy from billing
				if ( empty( $order->get_shipping_address_1() ) ) {
					$order->set_shipping_first_name( $order->get_billing_first_name() );
					$order->set_shipping_last_name( $order->get_billing_last_name() );
					$order->set_shipping_address_1( $order->get_billing_address_1() );
					$order->set_shipping_address_2( $order->get_billing_address_2() );
					$order->set_shipping_city( $order->get_billing_city() );
					$order->set_shipping_state( $order->get_billing_state() );
					$order->set_shipping_postcode( $order->get_billing_postcode() );
					$order->set_shipping_country( $order->get_billing_country() );
				}
				return; // Addresses set from WC()->customer, done
			}
		}
		
		// Priority 4: Preserve existing order addresses (already set, don't overwrite)
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[SET ADDRESSES] Preserving existing order addresses (Priority 4)' );
		}
	}
	
	/**
	 * Create a minimal order from payment details when normal order creation fails.
	 * This ensures every payment attempt has an order record.
	 *
	 * @param string $payment_id Payment ID from Checkout.com
	 * @param array  $payment_details Payment details from Checkout.com API
	 * @return WC_Order|WP_Error Order object or error
	 */
	/**
	 * Add shipping items to order from payment_details items array.
	 * Extracts shipping items (type: 'shipping_fee') from payment_details and adds them to the order.
	 *
	 * @param WC_Order $order          The WooCommerce order object.
	 * @param array    $payment_details Payment details from Checkout.com API.
	 * @return void
	 */
	private function add_shipping_from_payment_details( $order, $payment_details ) {
		if ( ! $order ) {
			return;
		}
		
		if ( ! isset( $payment_details['items'] ) || ! is_array( $payment_details['items'] ) ) {
			return;
		}
		
		// Check if order already has shipping items
		$existing_shipping_items = $order->get_items( 'shipping' );
		if ( ! empty( $existing_shipping_items ) ) {
			return;
		}
		
		$shipping_added = false;
		$shipping_items_found = 0;
		
		// Extract shipping items from payment_details
		// NOTE: For Flow payments, shipping items may not have 'type' field set (see class-wc-checkoutcom-api-request.php line 1506-1515)
		// So we need to detect shipping by multiple methods: type field, reference pattern, or name pattern
		foreach ( $payment_details['items'] as $index => $item_data ) {
			$item_type = isset( $item_data['type'] ) ? $item_data['type'] : '';
			$item_name = isset( $item_data['name'] ) ? $item_data['name'] : 'Unknown';
			$item_reference = isset( $item_data['reference'] ) ? $item_data['reference'] : '';
			$item_quantity = isset( $item_data['quantity'] ) ? intval( $item_data['quantity'] ) : 1;
			
			// Check if this is a shipping item using multiple detection methods
			$is_shipping = false;
			
			// Method 1: Check type field (for non-Flow payments)
			if ( 'shipping_fee' === $item_type ) {
				$is_shipping = true;
			}
			// Method 2: Check reference field (common shipping method IDs)
			elseif ( ! empty( $item_reference ) && in_array( $item_reference, array( 'flat_rate', 'free_shipping', 'local_pickup', 'shipping' ), true ) ) {
				$is_shipping = true;
			}
			// Method 3: Check name patterns (common shipping names)
			elseif ( ! empty( $item_name ) && (
				stripos( $item_name, 'shipping' ) !== false ||
				stripos( $item_name, 'flat rate' ) !== false ||
				stripos( $item_name, 'delivery' ) !== false ||
				stripos( $item_name, 'postage' ) !== false
			) ) {
				// Additional check: shipping items typically have quantity = 1 and are not products
				if ( $item_quantity === 1 ) {
					$is_shipping = true;
				}
			}
			
			if ( $is_shipping ) {
				$shipping_items_found++;
				$shipping_name = ! empty( $item_name ) ? $item_name : __( 'Shipping', 'checkout-com-unified-payments-api' );
				// CRITICAL FIX: Use utility function to convert from currency subunit to decimal
				// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
				$order_currency = $order->get_currency();
				$shipping_amount_subunits = isset( $item_data['total_amount'] ) ? (int) $item_data['total_amount'] : 0;
				$shipping_total = $shipping_amount_subunits > 0 ? WC_Checkoutcom_Utility::decimal_to_value( $shipping_amount_subunits, $order_currency ) : 0;
				$shipping_reference = ! empty( $item_reference ) ? $item_reference : 'flat_rate';
				
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					WC_Checkoutcom_Utility::logger( '[FLOW] [SHIPPING DEBUG] Found shipping item - Name: ' . $shipping_name . ', Amount: ' . $shipping_total );
				}
				
				// Create shipping item
				$shipping_item = new WC_Order_Item_Shipping();
				$shipping_item->set_props( array(
					'method_title' => $shipping_name,
					'method_id'    => $shipping_reference,
					'total'        => wc_format_decimal( $shipping_total ),
					'taxes'        => array(), // Tax is typically included in total_amount
				) );
				$order->add_item( $shipping_item );
				$shipping_added = true;
			}
		}
		
		// Recalculate totals after adding shipping
		if ( $shipping_added ) {
			$order->calculate_totals();
		}
	}

	private function create_minimal_order_from_payment_details( $payment_id, $payment_details ) {
		WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Creating minimal order from payment details - Payment ID: ' . $payment_id );
		
		try {
			// Extract customer info from payment details
			$customer_email = '';
			$customer_id = 0;
			$customer_name = '';
			
			if ( isset( $payment_details['customer']['email'] ) ) {
				$customer_email = $payment_details['customer']['email'];
				// Try to find customer by email
				$user = get_user_by( 'email', $customer_email );
				if ( $user ) {
					$customer_id = $user->ID;
				}
			}
			
			if ( isset( $payment_details['customer']['name'] ) ) {
				$customer_name = $payment_details['customer']['name'];
			}
			
			// Extract currency first (needed for amount conversion)
			$currency = isset( $payment_details['currency'] ) ? $payment_details['currency'] : get_woocommerce_currency();
			
			// CRITICAL FIX: Use utility function to convert from currency subunit to decimal
			// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
			$amount = 0;
			if ( isset( $payment_details['amount'] ) ) {
				$amount_subunits = (int) $payment_details['amount'];
				$amount = WC_Checkoutcom_Utility::decimal_to_value( $amount_subunits, $currency );
			}
			
			// Create order
			$order = wc_create_order( array( 'customer_id' => $customer_id ) );
			
			if ( ! $order || is_wp_error( $order ) ) {
				WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR: Failed to create minimal order' );
				return is_wp_error( $order ) ? $order : new WP_Error( 'order_creation_failed', 'Failed to create order' );
			}
			
			// Set customer email
			if ( ! empty( $customer_email ) ) {
				$order->set_billing_email( $customer_email );
			}
			
			// Set customer name
			if ( ! empty( $customer_name ) ) {
				$name_parts = explode( ' ', $customer_name, 2 );
				$order->set_billing_first_name( $name_parts[0] ?? '' );
				$order->set_billing_last_name( $name_parts[1] ?? '' );
			}
			
			// Set billing address from payment details if available
			if ( isset( $payment_details['billing_address'] ) ) {
				$billing = $payment_details['billing_address'];
				if ( isset( $billing['address_line1'] ) ) {
					$order->set_billing_address_1( $billing['address_line1'] );
				}
				if ( isset( $billing['address_line2'] ) ) {
					$order->set_billing_address_2( $billing['address_line2'] );
				}
				if ( isset( $billing['city'] ) ) {
					$order->set_billing_city( $billing['city'] );
				}
				if ( isset( $billing['state'] ) ) {
					$order->set_billing_state( $billing['state'] );
				}
				if ( isset( $billing['zip'] ) ) {
					$order->set_billing_postcode( $billing['zip'] );
				}
				if ( isset( $billing['country'] ) ) {
					$order->set_billing_country( $billing['country'] );
				}
			}
			
			// Set shipping address from payment details if available, otherwise copy from billing
			if ( isset( $payment_details['shipping_address'] ) ) {
				$shipping = $payment_details['shipping_address'];
				if ( isset( $shipping['address_line1'] ) ) {
					$order->set_shipping_address_1( $shipping['address_line1'] );
				}
				if ( isset( $shipping['address_line2'] ) ) {
					$order->set_shipping_address_2( $shipping['address_line2'] );
				}
				if ( isset( $shipping['city'] ) ) {
					$order->set_shipping_city( $shipping['city'] );
				}
				if ( isset( $shipping['state'] ) ) {
					$order->set_shipping_state( $shipping['state'] );
				}
				if ( isset( $shipping['zip'] ) ) {
					$order->set_shipping_postcode( $shipping['zip'] );
				}
				if ( isset( $shipping['country'] ) ) {
					$order->set_shipping_country( $shipping['country'] );
				}
			} else {
				// Shipping same as billing
				$order->set_shipping_first_name( $order->get_billing_first_name() );
				$order->set_shipping_last_name( $order->get_billing_last_name() );
				$order->set_shipping_address_1( $order->get_billing_address_1() );
				$order->set_shipping_address_2( $order->get_billing_address_2() );
				$order->set_shipping_city( $order->get_billing_city() );
				$order->set_shipping_state( $order->get_billing_state() );
				$order->set_shipping_postcode( $order->get_billing_postcode() );
				$order->set_shipping_country( $order->get_billing_country() );
			}
			
			// Add products and shipping from payment_details items if available
			if ( isset( $payment_details['items'] ) && is_array( $payment_details['items'] ) ) {
				foreach ( $payment_details['items'] as $idx => $item_data ) {
					$item_type = isset( $item_data['type'] ) ? $item_data['type'] : '';
					$item_name = isset( $item_data['name'] ) ? $item_data['name'] : 'Unknown';
					$item_reference = isset( $item_data['reference'] ) ? $item_data['reference'] : '';
					$item_quantity = isset( $item_data['quantity'] ) ? intval( $item_data['quantity'] ) : 1;
					
					// Check if this is a shipping item using multiple detection methods
					// NOTE: For Flow payments, shipping items may not have 'type' field set
					$is_shipping = false;
					
					// Method 1: Check type field (for non-Flow payments)
					if ( 'shipping_fee' === $item_type ) {
						$is_shipping = true;
					}
					// Method 2: Check reference field (common shipping method IDs)
					elseif ( ! empty( $item_reference ) && in_array( $item_reference, array( 'flat_rate', 'free_shipping', 'local_pickup', 'shipping' ), true ) ) {
						$is_shipping = true;
					}
					// Method 3: Check name patterns (common shipping names)
					elseif ( ! empty( $item_name ) && (
						stripos( $item_name, 'shipping' ) !== false ||
						stripos( $item_name, 'flat rate' ) !== false ||
						stripos( $item_name, 'delivery' ) !== false ||
						stripos( $item_name, 'postage' ) !== false
					) ) {
						// Additional check: shipping items typically have quantity = 1 and are not products
						if ( $item_quantity === 1 ) {
							$is_shipping = true;
						}
					}
					
					if ( $is_shipping ) {
						// Add shipping item
						$shipping_item = new WC_Order_Item_Shipping();
						$shipping_name = ! empty( $item_name ) ? $item_name : __( 'Shipping', 'checkout-com-unified-payments-api' );
						// CRITICAL FIX: Use utility function to convert from currency subunit to decimal
						// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
						$order_currency = $order->get_currency();
						$shipping_amount_subunits = isset( $item_data['total_amount'] ) ? (int) $item_data['total_amount'] : 0;
						$shipping_total = $shipping_amount_subunits > 0 ? WC_Checkoutcom_Utility::decimal_to_value( $shipping_amount_subunits, $order_currency ) : 0;
						
						$shipping_item->set_props( array(
							'method_title' => $shipping_name,
							'method_id'    => ! empty( $item_reference ) ? $item_reference : 'flat_rate',
							'total'        => wc_format_decimal( $shipping_total ),
							'taxes'        => array(), // Tax is typically included in total_amount
						) );
						$order->add_item( $shipping_item );
					} else {
						// Add product item
						$product_name = isset( $item_data['name'] ) ? $item_data['name'] : __( 'Product', 'checkout-com-unified-payments-api' );
						// CRITICAL FIX: Use utility function to convert from currency subunit to decimal
						// This handles zero-decimal (JPY, ISK, UGX), three-decimal (BHD, KWD), and two-decimal (USD, EUR) currencies correctly
						$order_currency = $order->get_currency();
						$product_amount_subunits = isset( $item_data['total_amount'] ) ? (int) $item_data['total_amount'] : 0;
						$product_total = $product_amount_subunits > 0 ? WC_Checkoutcom_Utility::decimal_to_value( $product_amount_subunits, $order_currency ) : 0;
						$product_quantity = isset( $item_data['quantity'] ) ? $item_data['quantity'] : 1;
						
						$product_item = new WC_Order_Item_Fee();
						$product_item->set_name( $product_name );
						$product_item->set_amount( $product_total / $product_quantity );
						$product_item->set_total( $product_total );
						$order->add_item( $product_item );
					}
				}
			} else {
				// Fallback: Add a line item with the payment amount
				// This is a minimal order, so we add a single line item
				$item = new WC_Order_Item_Fee();
				$item->set_name( __( 'Payment Amount', 'checkout-com-unified-payments-api' ) );
				$item->set_amount( $amount );
				$item->set_total( $amount );
				$order->add_item( $item );
			}
			
			// Set currency
			$order->set_currency( $currency );
			
			// Calculate totals
			$order->calculate_totals();
			
			// Set payment method
			$order->set_payment_method( $this->id );
			// Get payment method title based on actual payment type used
			$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Setting payment method title - Location: create_minimal_order_from_payment_details() around line 4381' );
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order ID: ' . $order->get_id() );
			}
			$payment_method_title = $this->get_payment_method_title_by_type( $order, $payment_details );
			$order->set_payment_method_title( $payment_method_title );
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] ✅ Title set to: ' . $payment_method_title );
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order payment method title after setting: ' . $order->get_payment_method_title() );
			}
			
			// Save payment IDs
			$order->update_meta_data( '_cko_payment_id', $payment_id );
			
			// CRITICAL: Only set _cko_flow_payment_id if not already set (prevent overwriting)
			$existing_flow_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			if ( empty( $existing_flow_payment_id ) ) {
				$order->update_meta_data( '_cko_flow_payment_id', $payment_id );
			} else {
				WC_Checkoutcom_Utility::logger( '[CREATE MINIMAL ORDER] Payment ID already exists in order - Order ID: ' . $order_id . ', Existing Payment ID: ' . substr( $existing_flow_payment_id, 0, 20 ) . '..., New Payment ID: ' . substr( $payment_id, 0, 20 ) . '... (skipping save to prevent overwrite)' );
			}
			
			// Save payment session ID if available in payment details metadata.
			// This allows webhooks to find this order by payment_session_id.
			if ( isset( $payment_details['metadata']['cko_payment_session_id'] ) ) {
				$payment_session_id = $payment_details['metadata']['cko_payment_session_id'];
				$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
				WC_Checkoutcom_Utility::logger( '[CREATE MINIMAL ORDER] Saved payment session ID: ' . substr( $payment_session_id, 0, 25 ) . '...' );
			}
			
			// Mark as minimal order (created from payment details)
			$order->update_meta_data( '_cko_minimal_order', 'yes' );
			$order->update_meta_data( '_cko_minimal_order_reason', 'Order lookup failed during 3DS callback' );
			
			// Set status to failed (since we're creating this due to a failure)
			$order->set_status( 'failed' );
			$order->save();
			if ( $gateway_debug ) {
				WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order saved - Title after save: ' . $order->get_payment_method_title() );
				// Reload order to check if title persisted
				$reloaded_order = wc_get_order( $order->get_id() );
				if ( $reloaded_order ) {
					WC_Checkoutcom_Utility::logger( '[PAYMENT METHOD TITLE] Order reloaded - Title after reload: ' . $reloaded_order->get_payment_method_title() );
				}
			}
			
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] Minimal order created successfully - Order ID: ' . $order->get_id() );
			
			return $order;
			
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[FLOW 3DS API] ERROR creating minimal order: ' . $e->getMessage() );
			return new WP_Error( 'order_creation_exception', $e->getMessage() );
		}
	}

	/**
	 * Save customer's card information after a successful payment.
	 *
	 * @param WC_Order $order   The WooCommerce order object.
	 * @param string   $pay_id  The payment ID used to query payment status.
	 */
	public function flow_save_cards( $order, $pay_id ) {

		WC_Checkoutcom_Utility::logger( '=== FLOW_SAVE_CARDS METHOD START ===' );
		WC_Checkoutcom_Utility::logger( 'Order ID: ' . $order->get_id() );
		WC_Checkoutcom_Utility::logger( 'Payment ID: ' . $pay_id );
		WC_Checkoutcom_Utility::logger( 'User ID: ' . $order->get_user_id() );

		$save_card = WC_Admin_Settings::get_option( 'ckocom_card_saved' );
		WC_Checkoutcom_Utility::logger( 'Admin Save Card Setting: ' . ( $save_card ? 'ENABLED' : 'DISABLED' ) );

		// Check if save card is enable and customer select to save card.
		if ( ! $save_card ) {
			WC_Checkoutcom_Utility::logger( 'Save card disabled in admin - exiting' );
			WC_Checkoutcom_Utility::logger( '=== FLOW_SAVE_CARDS METHOD END ===' );
			return;
		}

		WC_Checkoutcom_Utility::logger( 'Fetching payment details from Checkout.com API...' );

		// Call cko_get_payment_status() directly instead of going through rest_do_request().
		// The REST endpoint's permission_callback requires a `nonce` param (cko_flow_payment_session)
		// which we can't easily produce server-side here, and going through rest_do_request would
		// hit the permission failure → WP_REST_Response with status 403 → $result->get_data()
		// returns the error payload, which save_token would then try to read as payment data,
		// producing an invalid token row (empty token / null fields) and potentially a fatal
		// inside WC_Payment_Token_CC->save() depending on WooCommerce version.
		$request = new \WP_REST_Request( 'GET', '/ckoplugin/v1/payment-status' );
		$request->set_query_params( [ 'paymentId' => $pay_id ] );

		$response = cko_get_payment_status( $request );
		$status   = $response instanceof \WP_REST_Response ? $response->get_status() : 500;
		$data     = $response instanceof \WP_REST_Response ? $response->get_data() : null;

		if ( $status >= 400 || ! is_array( $data ) || isset( $data['error'] ) ) {
			$error_message = is_array( $data ) && isset( $data['error'] ) ? $data['error'] : 'Unknown error fetching payment status (HTTP ' . $status . ')';
			WC_Checkoutcom_Utility::logger( "ERROR in saving cards: $error_message" );
			WC_Checkoutcom_Utility::logger( '=== FLOW_SAVE_CARDS METHOD END (ERROR) ===' );
			return;
		}

		WC_Checkoutcom_Utility::logger( 'Payment data retrieved successfully' );
		WC_Checkoutcom_Utility::logger( 'Payment data: ' . wp_json_encode( $data ) );

		WC_Checkoutcom_Utility::logger( 'Calling save_token method...' );
		$this->save_token( $order->get_user_id(), $data );
		WC_Checkoutcom_Utility::logger( '=== FLOW_SAVE_CARDS METHOD END ===' );
	}

	/**
	 * Renders the save card markup.
	 *
	 * @param string $save_card Save card enable.
	 *
	 * @return void
	 */
	public function element_form_save_card( $save_card ) {
		// Only render the save card checkbox div if save card feature is enabled AND user is logged in
		// Guest users cannot save cards, so don't show the checkbox
		if ( ! $save_card || ! is_user_logged_in() ) {
			return;
		}
		?>
		<!-- Show save card checkbox if this is selected on admin-->
		<div class="cko-save-card-checkbox" style="display: none">
			<?php
			$this->save_payment_method_checkbox();
			?>
		</div>
		<?php
	}

	/**
	 * DEPRECATED: Migrate old saved cards to be compatible with Flow integration.
	 * 
	 * This function is no longer needed as of version 5.0.0.
	 * The saved_payment_methods() function now automatically displays tokens from BOTH
	 * Flow and Classic Cards gateways, and the backend payment processing already
	 * handles both token types seamlessly. No migration is required.
	 *
	 * @deprecated 5.0.0 No longer needed - tokens from both gateways are shown automatically
	 * @param int $user_id User ID.
	 * @return void
	 */
	public function migrate_old_saved_cards( $user_id ) {
		// This function is deprecated and no longer performs any action.
		// Kept for backward compatibility in case it's called by other code.
		WC_Checkoutcom_Utility::logger( 'migrate_old_saved_cards() called but is deprecated - no action taken. Tokens from both gateways are now shown automatically.' );
		return;
	}

	/**
	 * Save card.
	 *
	 * @param int   $user_id User id.
	 * @param array $payment_response Payment response.
	 *
	 * @return void
	 */
	public function save_token( $user_id, $payment_response ) {
		WC_Checkoutcom_Utility::logger( '=== SAVE_TOKEN METHOD START ===' );
		WC_Checkoutcom_Utility::logger( 'User ID: ' . $user_id );
		WC_Checkoutcom_Utility::logger( 'Payment Response is null: ' . ( is_null( $payment_response ) ? 'YES' : 'NO' ) );
		
		// Check if payment response is not null.
		if ( ! is_null( $payment_response ) ) {
			WC_Checkoutcom_Utility::logger( 'Payment response received, checking for duplicates...' );
			WC_Checkoutcom_Utility::logger( 'Source ID: ' . ( isset( $payment_response['source']['id'] ) ? $payment_response['source']['id'] : 'NOT SET' ) );
			WC_Checkoutcom_Utility::logger( 'Fingerprint: ' . ( isset( $payment_response['source']['fingerprint'] ) ? $payment_response['source']['fingerprint'] : 'NOT SET' ) );
			
			// argument to check token.
			$arg = array(
				'user_id'    => $user_id,
				'gateway_id' => $this->id,
				'limit'		 => 100,
			);

			// Query token by userid and gateway id.
			$token = WC_Payment_Tokens::get_tokens( $arg );
			WC_Checkoutcom_Utility::logger( 'Found ' . count( $token ) . ' existing Flow tokens for this user' );

			foreach ( $token as $tok ) {
				$fingerprint = $tok->get_meta( 'fingerprint', true );
				// do not save source if it already exists in db.
				if ( $fingerprint === $payment_response['source']['fingerprint'] ) {
					WC_Checkoutcom_Utility::logger( 'Card already exists in Flow tokens (fingerprint match) - NOT saving' );
					WC_Checkoutcom_Utility::logger( '=== SAVE_TOKEN METHOD END (DUPLICATE FLOW) ===' );
					return;
				}
			}

			// Check Classic Card saved or not.
			$classic_saved = new WC_Gateway_Checkout_Com_Cards();

			// argument to check token for card.
			$arg_classic = array(
				'user_id'    => $user_id,
				'gateway_id' => $classic_saved->id,
				'limit'		 => 100,
			);

			// Query token by userid and gateway id.
			$token_classic = WC_Payment_Tokens::get_tokens( $arg_classic );
			WC_Checkoutcom_Utility::logger( 'Found ' . count( $token_classic ) . ' existing Classic Cards tokens for this user' );

			foreach ( $token_classic as $tokc ) {
				$token_data = $tokc->get_data();
				// do not save source if it already exists in db.
				if ( $token_data['token'] === $payment_response['source']['id'] ) {
					WC_Checkoutcom_Utility::logger( 'Card already exists in Classic Cards tokens (source ID match) - NOT saving' );
					WC_Checkoutcom_Utility::logger( '=== SAVE_TOKEN METHOD END (DUPLICATE CLASSIC) ===' );
					return;
				}
			}

			WC_Checkoutcom_Utility::logger( 'No duplicates found - saving new token...' );
			
			// Save source_id in db.
			$token = new WC_Payment_Token_CC();
			$token->set_token( (string) $payment_response['source']['id'] );
			$token->set_gateway_id( $this->id );
			$token->set_card_type( (string) $payment_response['source']['scheme'] );
			$token->set_last4( $payment_response['source']['last4'] );
			$token->set_expiry_month( $payment_response['source']['expiry_month'] );
			$token->set_expiry_year( $payment_response['source']['expiry_year'] );
			$token->set_user_id( $user_id );

			// Add the `fingerprint` metadata.
			$token->add_meta_data( 'fingerprint', $payment_response['source']['fingerprint'], true );

			$save_result = $token->save();
			WC_Checkoutcom_Utility::logger( 'Token save result: ' . ( $save_result ? 'SUCCESS' : 'FAILED' ) );
			WC_Checkoutcom_Utility::logger( 'Token ID: ' . $token->get_id() );
			
			// CRITICAL: Clear token cache after saving so token is immediately available
			// This fixes issue where newly saved cards aren't found when used immediately
			wp_cache_delete( 'customer_tokens_' . $user_id . '_' . $this->id, 'woocommerce' );
			$classic_gateway = new WC_Gateway_Checkout_Com_Cards();
			wp_cache_delete( 'customer_tokens_' . $user_id . '_' . $classic_gateway->id, 'woocommerce' );
			// Also clear the specific token cache
			wp_cache_delete( 'payment_token_' . $token->get_id(), 'woocommerce' );
			WC_Checkoutcom_Utility::logger( 'Token cache cleared - Token ID: ' . $token->get_id() . ' is now immediately available' );
			
			WC_Checkoutcom_Utility::logger( '=== SAVE_TOKEN METHOD END (SAVED) ===' );
		} else {
			WC_Checkoutcom_Utility::logger( 'Payment response is NULL - cannot save token' );
			WC_Checkoutcom_Utility::logger( '=== SAVE_TOKEN METHOD END (NULL RESPONSE) ===' );
		}
	}

	/**
	 * This function save card scheme for recurring payment like subscription renewal.
	 *
	 * @param int      $order_id Order ID.
	 * @param WC_Order $order Order object.
	 * @param string   $card_scheme Card Scheme.
	 *
	 * @return void
	 */
	public function save_preferred_card_scheme( $order_id, $order, $card_scheme ) {

		if ( empty( $card_scheme ) ) {
			return;
		}

		if ( $order instanceof WC_Subscription ) {
			$order->update_meta_data( '_cko_preferred_scheme', $card_scheme );
			$order->save();
		}

		// Check for subscription and save source id.
		if ( function_exists( 'wcs_order_contains_subscription' ) ) {
			if ( wcs_order_contains_subscription( $order_id ) ) {
				$subscriptions = wcs_get_subscriptions_for_order( $order );

				foreach ( $subscriptions as $subscription_obj ) {
					$subscription_obj->update_meta_data( '_cko_preferred_scheme', $card_scheme );
					$subscription_obj->save();
				}
			}
		}
	}

	/**
	 * Handle Flow refund.
	 *
	 * @param int    $order_id Order ID.
	 * @param null   $amount  Amount to refund.
	 * @param string $reason Reason for refund.
	 *
	 * @return bool
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order  = wc_get_order( $order_id );
		
		$result = (array) WC_Checkoutcom_Api_Request::refund_payment( $order_id, $order );

		// check if result has error and return error message.
		if ( isset( $result['error'] ) && ! empty( $result['error'] ) ) {
			WC_Checkoutcom_Utility::logger( '[FLOW ERROR] Refund failed for order ' . $order_id . ': ' . $result['error'] );
			WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
			return false;
		}

		// Set action id as woo transaction id.
		$order->set_transaction_id( $result['action_id'] );
		$order->update_meta_data( 'cko_payment_refunded', true );
		$order->save();

		// Get payment ID and format amount for the note.
		$payment_id = $order->get_meta( '_cko_payment_id' );
		$refund_amount = isset( $amount ) ? $amount : $order->get_total();
		$formatted_amount = wc_price( $refund_amount, array( 'currency' => $order->get_currency() ) );

		if ( isset( $_SESSION['cko-refund-is-less'] ) ) {
			if ( $_SESSION['cko-refund-is-less'] ) {
				/* translators: %1$s: Payment ID, %2$s: Action ID, %3$s: Amount. */
				$order->add_order_note( sprintf( esc_html__( 'Checkout.com Payment Partially refunded from Admin – Payment ID: %1$s, Action ID: %2$s, Amount: %3$s', 'checkout-com-unified-payments-api' ), $payment_id, $result['action_id'], $formatted_amount ) );

				unset( $_SESSION['cko-refund-is-less'] );

				return true;
			}
		}

		/* translators: %1$s: Payment ID, %2$s: Action ID, %3$s: Amount. */
		$message = sprintf( esc_html__( 'Checkout.com Payment refunded from Admin – Payment ID: %1$s, Action ID: %2$s, Amount: %3$s', 'checkout-com-unified-payments-api' ), $payment_id, $result['action_id'], $formatted_amount );

		// add note for order.
		$order->add_order_note( $message );

		// when true is returned, status is changed to refunded automatically.
		return true;
	}

	/**
	 * Deactivate Classic methods when FLOW is active.
	 */
	public static function flow_enabled() {

		$flow_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_flow_settings' )
			: get_option( 'woocommerce_wc_checkout_com_flow_settings', array() );

		$checkout_setting = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$checkout_mode    = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';
	
		$apm_settings      = get_option( 'woocommerce_wc_checkout_com_alternative_payments_settings', array() );
		$gpay_settings     = get_option( 'woocommerce_wc_checkout_com_google_pay_settings', array() );
		$applepay_settings = get_option( 'woocommerce_wc_checkout_com_apple_pay_settings', array() );
		$paypal_settings   = get_option( 'woocommerce_wc_checkout_com_paypal_settings', array() );
	
		if ( 'flow' === $checkout_mode ) {
			$flow_settings['enabled']     = 'yes';
			$checkout_setting['enabled']  = 'no';
			$apm_settings['enabled']      = 'no';
			$gpay_settings['enabled']     = 'no';
			$applepay_settings['enabled'] = 'no';
			$paypal_settings['enabled']   = 'no';
		} else {
			$flow_settings['enabled']    = 'no';
			$checkout_setting['enabled'] = 'yes';
		}
	
		update_option( 'woocommerce_wc_checkout_com_flow_settings', $flow_settings );
		update_option( 'woocommerce_wc_checkout_com_cards_settings', $checkout_setting );
		update_option( 'woocommerce_wc_checkout_com_alternative_payments_settings', $apm_settings );
		update_option( 'woocommerce_wc_checkout_com_google_pay_settings', $gpay_settings );
		update_option( 'woocommerce_wc_checkout_com_apple_pay_settings', $applepay_settings );
		update_option( 'woocommerce_wc_checkout_com_paypal_settings', $paypal_settings );
		if ( function_exists( 'cko_update_raw_option' ) ) {
			cko_update_raw_option( 'woocommerce_wc_checkout_com_flow_settings', $flow_settings );
			cko_update_raw_option( 'woocommerce_wc_checkout_com_cards_settings', $checkout_setting );
		}
		
		// Log for debugging (only in debug mode to reduce log spam)
		$is_debug = defined( 'WP_DEBUG' ) && WP_DEBUG;
		if ( $is_debug ) {
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] ========== FLOW ENABLED CHECK ==========' );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] Checkout mode: ' . $checkout_mode );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] Flow gateway enabled: ' . ( isset( $flow_settings['enabled'] ) ? $flow_settings['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] Cards gateway enabled: ' . ( isset( $checkout_setting['enabled'] ) ? $checkout_setting['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] APM gateway enabled: ' . ( isset( $apm_settings['enabled'] ) ? $apm_settings['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] Google Pay enabled: ' . ( isset( $gpay_settings['enabled'] ) ? $gpay_settings['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] Apple Pay enabled: ' . ( isset( $applepay_settings['enabled'] ) ? $applepay_settings['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] PayPal enabled: ' . ( isset( $paypal_settings['enabled'] ) ? $paypal_settings['enabled'] : 'not set' ) );
			WC_Checkoutcom_Utility::logger( '[FLOW ENABLED] ========================================' );
		}
	}

	/**
	 * Webhook handler.
	 * Handle Webhook.
	 *
	 * @return bool|int|void
	 */
	public function webhook_handler() {
		// webhook_url_format = http://example.com/?wc-api=wc_checkoutcom_webhook .

		// Check if detailed webhook logging is enabled (use existing gateway responses setting)
		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$webhook_debug_enabled = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( '=== WEBHOOK DEBUG: Flow webhook handler started ===' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Request method: ' . $_SERVER['REQUEST_METHOD'] );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Request URI: ' . $_SERVER['REQUEST_URI'] );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: User agent: ' . ($_SERVER['HTTP_USER_AGENT'] ?? 'Not set') );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Content type: ' . ($_SERVER['CONTENT_TYPE'] ?? 'Not set') );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Content length: ' . ($_SERVER['CONTENT_LENGTH'] ?? 'Not set') );
		}

		// Check if Flow mode is enabled - if not, let Cards handler process the webhook
		$checkout_mode = $core_settings['ckocom_checkout_mode'] ?? 'cards';
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Core settings retrieved: ' . wp_json_encode( $core_settings ) );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Checkout mode: ' . $checkout_mode );
		}
		
		if ( 'flow' !== $checkout_mode ) {
			// Flow mode is not enabled, don't process webhook in Flow handler
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Flow mode not enabled, exiting webhook handler' );
			}
			return;
		}
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Flow mode confirmed, continuing webhook processing' );
		}

		try {
			// Get webhook data.
			$raw_input = file_get_contents( 'php://input' );
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Raw input received: ' . $raw_input );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Raw input length: ' . strlen($raw_input) );
			}
			
			$data = json_decode( $raw_input );
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: JSON decode result: ' . wp_json_encode( $data ) );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: JSON last error: ' . json_last_error_msg() );
			}

		// Return to home page if empty data.
		if ( empty( $data ) ) {
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Empty data received, redirecting to home' );
			}
			wp_redirect( get_home_url() );
			exit;
		}
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Data validation passed, continuing processing' );
		}

		// Create apache function if not exist to get header authorization.
		if ( ! function_exists( 'apache_request_headers' ) ) {
			/**
			 * Get request headers.
			 *
			 * @return array
			 */
			function apache_request_headers() {
				$arh     = [];
				$rx_http = '/\AHTTP_/';
				foreach ( $_SERVER as $key => $val ) {
					if ( preg_match( $rx_http, $key ) ) {
						$arh_key    = preg_replace( $rx_http, '', $key );
						$rx_matches = [];
						$rx_matches = explode( '_', $arh_key );
						if ( count( $rx_matches ) > 0 and strlen( $arh_key ) > 2 ) {
							foreach ( $rx_matches as $ak_key => $ak_val ) {
								$rx_matches[ $ak_key ] = ucfirst( $ak_val );
							}
							$arh_key = implode( '-', $rx_matches );
						}
						$arh[ $arh_key ] = $val;
					}
				}
				return( $arh );
			}
		}

		$header           = array_change_key_case( apache_request_headers(), CASE_LOWER );
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: All headers: ' . wp_json_encode( $header ) );
		}
		
		$header_signature = $header['cko-signature'] ?? null;
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: CKO signature from header: ' . ($header_signature ?? 'NOT FOUND') );
		}

		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$raw_event     = file_get_contents( 'php://input' );
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Raw event for signature verification: ' . $raw_event );
		}

		$secret_key_raw = $core_settings['ckocom_sk'] ?? '';
		$secret_key     = cko_is_nas_account() ? 'Bearer ' . $secret_key_raw : $secret_key_raw;
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Secret key (masked): ' . substr($secret_key, 0, 14) . '...' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Is NAS account: ' . (cko_is_nas_account() ? 'YES' : 'NO') );
		}

		$computed_hmac = hash_hmac( 'sha256', $raw_event, $secret_key );
		$signature     = ( $computed_hmac === $header_signature );
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Computed HMAC: ' . $computed_hmac );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Expected HMAC: ' . ( $header_signature ?? 'NULL' ) );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Signature verification result: ' . ( $signature ? 'VALID' : 'INVALID' ) );
		}

		// check if cko signature matches.
		if ( false === $signature ) {
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger('WEBHOOK DEBUG: Invalid signature - returning 401');
				WC_Checkoutcom_Utility::logger('WEBHOOK DEBUG: Signature verification failed with:');
				WC_Checkoutcom_Utility::logger('WEBHOOK DEBUG: - Raw event: ' . $raw_event);
				WC_Checkoutcom_Utility::logger('WEBHOOK DEBUG: - Header signature: ' . ($header_signature ?? 'NULL'));
				WC_Checkoutcom_Utility::logger('WEBHOOK DEBUG: - Secret key: ' . substr($secret_key, 0, 10) . '...');
			}
        	$this->send_response(401, 'Unauthorized: Invalid signature');
		}
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Signature verification passed, continuing with order processing' );
		}

		$order      = false;
		$payment_id = null;

		// ALWAYS log webhook matching details (even if debug disabled) for critical payment events
		$webhook_event_type = isset( $data->type ) ? $data->type : 'unknown';
		$webhook_payment_id = isset( $data->data->id ) ? $data->data->id : 'NULL';
		$webhook_session_id = isset( $data->data->metadata->cko_payment_session_id ) ? $data->data->metadata->cko_payment_session_id : 'NOT SET';
		$webhook_order_id = isset( $data->data->metadata->order_id ) ? $data->data->metadata->order_id : 'NOT SET';
		$webhook_reference = isset( $data->data->reference ) ? $data->data->reference : 'NOT SET';
		
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ========== STARTING ORDER LOOKUP ==========' );
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Event Type: ' . $webhook_event_type );
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Payment ID: ' . $webhook_payment_id );
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Session ID in metadata: ' . $webhook_session_id );
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order ID in metadata: ' . $webhook_order_id );
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Reference (Order ID): ' . $webhook_reference );

		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Starting order lookup process' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Webhook data structure: ' . wp_json_encode( $data ) );
		}

		// Method 1: Try reference field first (contains Order ID - MOST DIRECT)
		// We send order_id as reference when submitting payment, so this is the most reliable
		if ( ! empty( $data->data->reference ) && is_numeric( $data->data->reference ) ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Trying METHOD 1 (Reference/Order ID): ' . $data->data->reference );
			$order = wc_get_order( $data->data->reference );
			if ( $order ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 1 (Reference/Order ID) - Order ID: ' . $order->get_id() );
			} else {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 1 FAILED - Order ID ' . $data->data->reference . ' not found' );
			}
		}
		
		// Method 1B: Try order_id from metadata (fallback if reference not available)
		if ( ! $order && ! empty( $data->data->metadata->order_id ) ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Trying METHOD 1B (Order ID from metadata): ' . $data->data->metadata->order_id );
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Looking for order by metadata order_id: ' . $data->data->metadata->order_id );
			}
			$order = wc_get_order( $data->data->metadata->order_id );
			if ( $order ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 1B (Order ID from metadata) - Order ID: ' . $order->get_id() );
			} else {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 1B FAILED - Order ID ' . $data->data->metadata->order_id . ' not found' );
			}
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order found by metadata order_id: ' . ($order ? 'YES (ID: ' . $order->get_id() . ')' : 'NO') );
			}
		}
		
		// Method 2: Try COMBINED (payment session ID + payment ID) - MOST RELIABLE
		// CRITICAL: Only match orders that need updating (pending, failed, on-hold, processing)
		// This ensures webhook updates correct order and prevents matching completed orders
		// Both identifiers must match - eliminates false positives and provides highest confidence match
		if ( ! $order && ! empty( $data->data->metadata->cko_payment_session_id ) && ! empty( $data->data->id ) ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Trying METHOD 2 (COMBINED: Session ID + Payment ID)' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Session ID: ' . $data->data->metadata->cko_payment_session_id );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Payment ID: ' . $data->data->id );
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Looking for order by COMBINED (session ID + payment ID)' );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Session ID: ' . $data->data->metadata->cko_payment_session_id );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Payment ID: ' . $data->data->id );
			}
			
			// First try to match orders that need updating (pending, failed, on-hold, processing)
			// CRITICAL: Use 'compare' => '=' explicitly and ensure both meta keys exist
			$orders = wc_get_orders( array(
				'meta_query' => array(
					'relation' => 'AND',
					array(
						'key'     => '_cko_payment_session_id',
						'value'   => $data->data->metadata->cko_payment_session_id,
						'compare' => '=',
					),
					array(
						'key'     => '_cko_flow_payment_id',
						'value'   => $data->data->id,
						'compare' => '=',
					),
				),
				'status'     => array( 'pending', 'failed', 'on-hold', 'processing' ), // ✅ Only match orders that need updating
				'limit'      => 1,
				'return'     => 'objects',
			) );
			
			// If not found in active orders, try all orders (fallback for edge cases)
			if ( empty( $orders ) ) {
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order not found in active statuses, trying all orders...' );
				}
				$orders = wc_get_orders( array(
					'meta_query' => array(
						'relation' => 'AND',
						array(
							'key'     => '_cko_payment_session_id',
							'value'   => $data->data->metadata->cko_payment_session_id,
							'compare' => '=',
						),
						array(
							'key'     => '_cko_flow_payment_id',
							'value'   => $data->data->id,
							'compare' => '=',
						),
					),
					'limit'      => 1,
					'return'     => 'objects',
				) );
			}
			
			if ( ! empty( $orders ) ) {
				$matched_order = $orders[0];
				
				// CRITICAL: Validate that BOTH meta values actually match (WooCommerce meta_query can match even if one meta key doesn't exist)
				$order_session_id = $matched_order->get_meta( '_cko_payment_session_id' );
				$order_payment_id = $matched_order->get_meta( '_cko_flow_payment_id' );
				$webhook_session_id = $data->data->metadata->cko_payment_session_id;
				$webhook_payment_id = $data->data->id;
				
				// Both must exist AND match
				$session_id_matches = ! empty( $order_session_id ) && $order_session_id === $webhook_session_id;
				$payment_id_matches = ! empty( $order_payment_id ) && $order_payment_id === $webhook_payment_id;
				
				if ( $session_id_matches && $payment_id_matches ) {
					// Both match - valid match
					$order = $matched_order;
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 2 (COMBINED: Session ID + Payment ID) - Order ID: ' . $order->get_id() );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ VALIDATION PASSED - Session ID matches: ' . $order_session_id . ', Payment ID matches: ' . $order_payment_id );
					if ( $webhook_debug_enabled ) {
						WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: ✅ Order found by COMBINED match (ID: ' . $order->get_id() . ')' );
					}
					
					// Add order_id to metadata so processing functions can find it
					if ( isset( $data->data->metadata ) && is_object( $data->data->metadata ) ) {
						$data->data->metadata->order_id = $order->get_id();
						if ( $webhook_debug_enabled ) {
							WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Set metadata order_id to: ' . $order->get_id() . ' (from COMBINED match)' );
						}
					} else {
						// If metadata is missing or not an object, create it.
						$data->data->metadata = (object) array( 'order_id' => $order->get_id() );
						if ( $webhook_debug_enabled ) {
							WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Created metadata object with order_id: ' . $order->get_id() . ' (from COMBINED match)' );
						}
					}
				} else {
					// Query matched but validation failed - reject this match
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 2 VALIDATION FAILED - Query matched Order ID: ' . $matched_order->get_id() . ' but values don\'t match!' );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Session ID: ' . ( $order_session_id ?: 'NOT SET' ) . ', Webhook Session ID: ' . $webhook_session_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Payment ID: ' . ( $order_payment_id ?: 'NOT SET' ) . ', Webhook Payment ID: ' . $webhook_payment_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Session ID matches: ' . ( $session_id_matches ? 'YES' : 'NO' ) . ', Payment ID matches: ' . ( $payment_id_matches ? 'YES' : 'NO' ) );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ REJECTING INVALID MATCH - Continuing to Method 3' );
					// Don't set $order - continue to Method 3
				}
			} else {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 2 FAILED - No order found by COMBINED match (Session ID: ' . $webhook_session_id . ', Payment ID: ' . $webhook_payment_id . ')' );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: ❌ No order found by COMBINED match' );
				}
			}
		}
		
		// ALWAYS log matching result (even if debug disabled)
		if ( $order ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ ORDER FOUND - Order ID: ' . $order->get_id() );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Status: ' . $order->get_status() );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Payment Session ID: ' . $order->get_meta( '_cko_payment_session_id' ) );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Payment ID (_cko_flow_payment_id): ' . $order->get_meta( '_cko_flow_payment_id' ) );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order Payment ID (_cko_payment_id): ' . $order->get_meta( '_cko_payment_id' ) );
		} else {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ ORDER NOT FOUND - No matching order found' );
		}
		
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order lookup result: ' . ($order ? 'FOUND (ID: ' . $order->get_id() . ')' : 'NOT FOUND') );
		}

		// Method 2.5: MULTI-TAB SUPPORT - Search for payment ID in _cko_payment_attempts array
		// This handles the case where a secondary tab's payment succeeded but the order's primary
		// _cko_payment_session_id doesn't match the webhook's session ID
		if ( ! $order && ! empty( $data->data->id ) ) {
			$webhook_payment_id = $data->data->id;
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Trying METHOD 2.5 (MULTI-TAB: Payment ID in _cko_payment_attempts)' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Looking for payment ID: ' . $webhook_payment_id . ' in payment attempts array' );
			
			// Search for orders with this payment ID tracked in the payment_attempts array
			// We need to search serialized data, so we use LIKE with the payment ID
			global $wpdb;
			$meta_key = '_cko_payment_attempts';
			$search_pattern = '%' . $wpdb->esc_like( $webhook_payment_id ) . '%';
			
			$order_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm 
					INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID 
					WHERE pm.meta_key = %s 
					AND pm.meta_value LIKE %s 
					AND p.post_type IN ('shop_order', 'shop_order_placehold')
					AND p.post_status IN ('wc-pending', 'wc-failed', 'wc-on-hold', 'wc-processing', 'wc-completed')
					LIMIT 5",
					$meta_key,
					$search_pattern
				)
			);
			
			if ( ! empty( $order_ids ) ) {
				foreach ( $order_ids as $order_id ) {
					$potential_order = wc_get_order( $order_id );
					if ( ! $potential_order ) {
						continue;
					}
					
					// Verify the payment ID is actually in the attempts array
					$payment_attempts = $potential_order->get_meta( '_cko_payment_attempts' );
					if ( empty( $payment_attempts ) || ! is_array( $payment_attempts ) ) {
						continue;
					}
					
					$found_in_attempts = false;
					foreach ( $payment_attempts as $attempt ) {
						if ( isset( $attempt['payment_id'] ) && $attempt['payment_id'] === $webhook_payment_id ) {
							$found_in_attempts = true;
							break;
						}
					}
					
					if ( $found_in_attempts ) {
						$order = $potential_order;
						WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 2.5 (MULTI-TAB) - Order ID: ' . $order->get_id() );
						WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Payment ID found in _cko_payment_attempts array' );
						
						// Add order_id to metadata
						if ( isset( $data->data->metadata ) && is_object( $data->data->metadata ) ) {
							$data->data->metadata->order_id = $order->get_id();
						} else {
							$data->data->metadata = (object) array( 'order_id' => $order->get_id() );
						}
						break;
					}
				}
			}
			
			if ( ! $order ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 2.5 FAILED - Payment ID not found in any _cko_payment_attempts' );
			}
		}
		
		// Method 3: Try payment ID alone (fallback if combined match failed)
		// CRITICAL: Only match orders that need updating (pending, failed, on-hold, processing)
		// This ensures webhook updates correct order and prevents matching completed orders
		// IMPORTANT: Check BOTH _cko_flow_payment_id (Flow payments) AND _cko_payment_id (PayPal Express/other payments)
		if ( ! $order && ! empty( $data->data->id ) ) {
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Looking for order by payment ID: ' . $data->data->id );
			}
			
			// First try _cko_flow_payment_id (Flow payments) in active statuses
			$orders = wc_get_orders( array(
				'limit'        => 1,
				'meta_key'     => '_cko_flow_payment_id',
				'meta_value'   => $data->data->id,
				'status'       => array( 'pending', 'failed', 'on-hold', 'processing' ), // ✅ Only match orders that need updating
				'return'       => 'objects',
			) );
			
			// If not found, try _cko_payment_id (PayPal Express and other non-Flow payments) in active statuses
			if ( empty( $orders ) ) {
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Not found in _cko_flow_payment_id, trying _cko_payment_id...' );
				}
				$orders = wc_get_orders( array(
					'limit'        => 1,
					'meta_key'     => '_cko_payment_id',
					'meta_value'   => $data->data->id,
					'status'       => array( 'pending', 'failed', 'on-hold', 'processing' ), // ✅ Only match orders that need updating
					'return'       => 'objects',
				) );
			}
			
			// If not found in active orders, try all orders (fallback for edge cases)
			if ( empty( $orders ) ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order not found in active statuses, trying all orders (fallback)...' );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order not found in active statuses, trying all orders...' );
				}
				// Try Flow payment ID first
				$orders = wc_get_orders( array(
					'limit'        => 1,
					'meta_key'     => '_cko_flow_payment_id',
					'meta_value'   => $data->data->id,
					'return'       => 'objects',
				) );
				
				// If still not found, try regular payment ID
				if ( empty( $orders ) ) {
					$orders = wc_get_orders( array(
						'limit'        => 1,
						'meta_key'     => '_cko_payment_id',
						'meta_value'   => $data->data->id,
						'return'       => 'objects',
					) );
				}
				
				if ( ! empty( $orders ) ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ⚠️ Found order in fallback search (all statuses) - Order ID: ' . $orders[0]->get_id() );
				}
			}

			if ( ! empty( $orders ) ) {
				$order = $orders[0];
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 3 (PAYMENT ID ALONE) - Order ID: ' . $order->get_id() );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ⚠️ WARNING: Matched by payment ID alone (less reliable than combined match)' );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order found by payment ID: YES (ID: ' . $order->get_id() . ')' );
				}

				// Add order_id to $data->data->metadata.
				if ( isset( $data->data->metadata ) && is_object( $data->data->metadata ) ) {
					$data->data->metadata->order_id = $order->get_id();
				} else {
					// If metadata is missing or not an object, create it.
					$data->data->metadata = (object) array( 'order_id' => $order->get_id() );
				}
			} else {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 3 FAILED - No order found by payment ID: ' . $data->data->id );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order found by payment ID: NO' );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: This is normal for webhooks that arrive before process_payment() completes' );
				}
			}
		}
		
		// Method 4: Fuzzy match by Session ID + Amount (fallback for browser-close scenario)
		// SAFETY: Match if order has no payment ID, pending status, and amount/currency match
		// This catches cases where customer closed browser immediately after clicking "Place Order"
		// before the payment response could save the payment_id to the order.
		// Note: "has_notes" check was removed in v5.0.3 - see inline comment for rationale.
		if ( ! $order && ! empty( $data->data->metadata->cko_payment_session_id ) && ! empty( $data->data->id ) ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Trying METHOD 4 (FUZZY: Session ID + Amount for pristine orders)' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Session ID: ' . $data->data->metadata->cko_payment_session_id );
			
			// Find orders by session ID only (pending status)
			$candidate_orders = wc_get_orders( array(
				'meta_key'   => '_cko_payment_session_id',
				'meta_value' => $data->data->metadata->cko_payment_session_id,
				'status'     => 'pending',
				'limit'      => 2, // Get 2 to detect duplicates - we only proceed if exactly 1 match
				'return'     => 'objects',
			) );
			
			if ( count( $candidate_orders ) === 1 ) {
				$candidate = $candidate_orders[0];
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: METHOD 4 - Found exactly 1 candidate order: ' . $candidate->get_id() );
				
				// Safety check 1: Order must NOT have a payment ID already
				$existing_payment_id = $candidate->get_meta( '_cko_flow_payment_id' );
				$existing_payment_id_alt = $candidate->get_meta( '_cko_payment_id' );
				$has_payment_id = ! empty( $existing_payment_id ) || ! empty( $existing_payment_id_alt );
				
				// NOTE: "has_notes" check was removed in v5.0.3 because:
				// 1. Flow plugin adds notes during order creation, making this check self-defeating
				// 2. Session ID uniqueness + Amount + Currency + No Payment ID + Pending status = sufficient safety
				// 3. Payment sessions are cryptographically unique from Checkout.com API
				// 4. Failed payments change status to 'failed' (excluded by pending filter)
				
				// Safety check 2: Amount must match (compare in minor units)
				$webhook_amount = isset( $data->data->amount ) ? (int) $data->data->amount : 0;
				$order_total = $candidate->get_total();
				// Convert order total to minor units (cents) - WooCommerce stores as decimal
				$order_amount_minor = (int) round( $order_total * 100 );
				$amount_matches = ( $webhook_amount === $order_amount_minor );
				
				// Safety check 3: Currency must match
				$webhook_currency = isset( $data->data->currency ) ? strtoupper( $data->data->currency ) : '';
				$order_currency = strtoupper( $candidate->get_currency() );
				$currency_matches = ( $webhook_currency === $order_currency );
				
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: METHOD 4 - Safety checks:' );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING:   - Has payment ID: ' . ( $has_payment_id ? 'YES (FAIL)' : 'NO (PASS)' ) );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING:   - Amount matches: ' . ( $amount_matches ? 'YES (PASS)' : 'NO (FAIL)' ) . ' (Webhook: ' . $webhook_amount . ', Order: ' . $order_amount_minor . ')' );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING:   - Currency matches: ' . ( $currency_matches ? 'YES (PASS)' : 'NO (FAIL)' ) . ' (Webhook: ' . $webhook_currency . ', Order: ' . $order_currency . ')' );
				
				// All safety checks must pass (no payment ID, amount match, currency match)
				if ( ! $has_payment_id && $amount_matches && $currency_matches ) {
					$order = $candidate;
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ MATCHED BY METHOD 4 (FUZZY: Session ID + Amount) - Order ID: ' . $order->get_id() );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ All safety checks passed - Order has no payment ID, amount and currency match, pending status' );
					
					// CRITICAL: Save payment ID to order so future webhooks can find it via Method 2/3
					$order->update_meta_data( '_cko_flow_payment_id', $data->data->id );
					$order->save();
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ Saved payment ID to order - Payment ID: ' . $data->data->id );
					
					// Add order_id to metadata so processing functions can find it
					if ( isset( $data->data->metadata ) && is_object( $data->data->metadata ) ) {
						$data->data->metadata->order_id = $order->get_id();
					} else {
						$data->data->metadata = (object) array( 'order_id' => $order->get_id() );
					}
					
					// Add order note explaining the fuzzy match
					$order->add_order_note(
						sprintf(
							/* translators: %s: payment ID */
							__( 'Order matched via webhook (Method 4 - fuzzy match). Customer likely closed browser before payment confirmation. Payment ID: %s', 'checkout-com-unified-payments-api' ),
							esc_html( $data->data->id )
						)
					);
				} else {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 4 FAILED - Safety checks did not pass for Order ID: ' . $candidate->get_id() );
					if ( $has_payment_id ) {
						WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ Reason: Order already has payment ID: ' . ( $existing_payment_id ?: $existing_payment_id_alt ) );
					}
					if ( ! $amount_matches ) {
						WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ Reason: Amount mismatch' );
					}
					if ( ! $currency_matches ) {
						WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ Reason: Currency mismatch' );
					}
				}
			} elseif ( count( $candidate_orders ) > 1 ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 4 FAILED - Multiple orders found with same session ID (ambiguous): ' . count( $candidate_orders ) );
				foreach ( $candidate_orders as $idx => $candidate_order ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING:   - Candidate ' . ( $idx + 1 ) . ': Order ID ' . $candidate_order->get_id() );
				}
			} else {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ METHOD 4 FAILED - No pending order found with session ID: ' . $data->data->metadata->cko_payment_session_id );
			}
		}
		
		WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ========== ORDER LOOKUP COMPLETE ==========' );

		if ( $order ) {
			// CRITICAL: Check if this webhook already processed this order (prevent duplicate processing)
			$processed_webhooks = $order->get_meta( '_cko_processed_webhook_ids' );
			if ( ! is_array( $processed_webhooks ) ) {
				$processed_webhooks = array();
			}
			
			// Create unique webhook identifier
			// For events with action_id (refund, void, capture), use action_id to allow multiple actions on same payment
			// For other events (approved, declined), use payment_id + event_type
			$action_id = isset( $data->data->action_id ) ? $data->data->action_id : null;
			$event_type = $data->type;
			
			// Events that can have multiple actions per payment (each with unique action_id)
			$action_based_events = array( 'payment_refunded', 'payment_voided', 'payment_captured', 'payment_capture_declined' );
			
			if ( ! empty( $action_id ) && in_array( $event_type, $action_based_events, true ) ) {
				// Use action_id for events that can occur multiple times (e.g., multiple partial refunds)
				$webhook_id = $action_id . '_' . $event_type;
			} else {
				// Use payment_id for single-occurrence events (approved, declined, etc.)
				$webhook_id = $data->data->id . '_' . $event_type;
			}
			
			if ( in_array( $webhook_id, $processed_webhooks, true ) ) {
				// Webhook already processed - skip to prevent duplicate order updates
				WC_Checkoutcom_Utility::logger( 'WEBHOOK: ✅ Already processed - Payment ID: ' . $data->data->id . ', Action ID: ' . ( $action_id ?? 'N/A' ) . ', Type: ' . $event_type . ', Order: ' . $order->get_id() );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK: ✅ Skipping duplicate webhook processing to prevent multiple order updates' );
				$this->send_response( 200, 'Webhook already processed' );
				return;
			}
			
			$payment_id = $order->get_meta( '_cko_payment_id' ) ?? null;
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order found, getting payment ID from meta' );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order ID: ' . $order->get_id() );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order status: ' . $order->get_status() );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Order transaction ID: ' . $order->get_transaction_id() );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Payment Session ID in order: ' . $order->get_meta( '_cko_payment_session_id' ) );
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Payment Session ID in webhook: ' . ( isset( $data->data->metadata->cko_payment_session_id ) ? $data->data->metadata->cko_payment_session_id : 'NOT SET' ) );
			}
		} else {
			if ( $webhook_debug_enabled ) {
				WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: No order found, cannot get payment ID' );
			}
		}

		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Payment ID from order: ' . ($payment_id ?? 'NULL') );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Payment ID from webhook: ' . ($data->data->id ?? 'NULL') );
		}

		// CRITICAL: Validate payment ID matches order (prevent wrong webhooks from matching orders)
		// This validation happens BEFORE processing webhook events
		if ( $order ) {
			$order_payment_id = $order->get_meta( '_cko_flow_payment_id' );
			$order_payment_id_alt = $order->get_meta( '_cko_payment_id' );
			$webhook_payment_id = $data->data->id;
			
			// Use Flow payment ID if available, otherwise fall back to regular payment ID
			$expected_payment_id = ! empty( $order_payment_id ) ? $order_payment_id : $order_payment_id_alt;
			
			// CRITICAL: If order has a payment ID, it MUST match the webhook payment ID
			// Check both meta keys to ensure we match correctly (Flow uses _cko_flow_payment_id, PayPal Express uses _cko_payment_id)
			$payment_id_matches = false;
			if ( ! empty( $order_payment_id ) && $order_payment_id === $webhook_payment_id ) {
				$payment_id_matches = true;
			} elseif ( ! empty( $order_payment_id_alt ) && $order_payment_id_alt === $webhook_payment_id ) {
				$payment_id_matches = true;
			}
			
			if ( ! empty( $expected_payment_id ) && ! $payment_id_matches ) {
				// Payment ID mismatch - check if this is a valid multi-tab retry before rejecting
				$event_type = $data->type ?? '';
				$payment_attempts = $order->get_meta( '_cko_payment_attempts' );
				$is_tracked_payment = false;
				
				// Check if this payment ID is tracked in the payment attempts array (multi-tab scenario)
				if ( ! empty( $payment_attempts ) && is_array( $payment_attempts ) ) {
					foreach ( $payment_attempts as $attempt ) {
						if ( isset( $attempt['payment_id'] ) && $attempt['payment_id'] === $webhook_payment_id ) {
							$is_tracked_payment = true;
							break;
						}
					}
				}
				
				// MULTI-TAB EXCEPTION: Allow payment_captured and payment_approved webhooks through
				// if the payment ID is tracked in _cko_payment_attempts. The webhook handler has
				// "first capture wins" logic that will correctly handle the multi-tab scenario.
				$allow_multi_tab_events = array( 'payment_captured', 'payment_approved' );
				$order_status = $order->get_status();
				$allow_for_order_status = in_array( $order_status, array( 'failed', 'pending', 'on-hold' ), true );
				
				if ( $is_tracked_payment && in_array( $event_type, $allow_multi_tab_events, true ) && $allow_for_order_status ) {
					// This is a valid multi-tab retry - let the webhook handler process it
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ⚠️ MULTI-TAB DETECTED - Payment ID mismatch but allowing through' );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order ID: ' . $order->get_id() );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order primary payment: ' . $expected_payment_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Webhook payment ID: ' . $webhook_payment_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Event type: ' . $event_type );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order status: ' . $order_status );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ✅ Payment ID found in _cko_payment_attempts - passing to webhook handler for "first capture wins" processing' );
					// Continue processing - don't return, let webhook handler decide
				} else {
					// Not a valid multi-tab scenario - reject the webhook
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ CRITICAL ERROR - Payment ID mismatch in Flow webhook handler!' );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order ID: ' . $order->get_id() );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order _cko_flow_payment_id: ' . ( $order_payment_id ?: 'NOT SET' ) );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order _cko_payment_id: ' . ( $order_payment_id_alt ?: 'NOT SET' ) );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Expected payment ID: ' . $expected_payment_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Webhook payment ID: ' . $webhook_payment_id );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Is tracked in payment_attempts: ' . ( $is_tracked_payment ? 'YES' : 'NO' ) );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Event type: ' . $event_type );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: Order status: ' . $order_status );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: ❌ REJECTING WEBHOOK - Payment ID does not match order!' );
					WC_Checkoutcom_Utility::logger( 'WEBHOOK MATCHING: This webhook is for a different payment - ignoring to prevent incorrect order updates' );
					
					// Reject webhook - return HTTP 200 but don't process
					$this->send_response( 200, 'Webhook payment ID does not match order payment ID' );
					return;
				}
			}
			
			// If order doesn't have payment ID yet, set it from webhook (for first payment attempt)
			if ( empty( $expected_payment_id ) && ! empty( $webhook_payment_id ) ) {
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'Flow webhook: No payment ID found in order, setting from webhook: ' . $webhook_payment_id );
				}
				$order->set_transaction_id( $webhook_payment_id );
				// Set both meta keys for compatibility
				$order->update_meta_data( '_cko_payment_id', $webhook_payment_id );
				$order->update_meta_data( '_cko_flow_payment_id', $webhook_payment_id );
				$order->save();
				$payment_id = $webhook_payment_id;
			} elseif ( ! empty( $expected_payment_id ) ) {
				// Payment IDs match - continue processing
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'Flow webhook: ✅ Payment ID validation passed - Order payment ID: ' . $expected_payment_id . ', Webhook payment ID: ' . $webhook_payment_id );
				}
			}
		} elseif ( ! $order ) {
			// No order found - log but continue processing to allow queue system to handle it
			// The queue system will catch webhooks for payment_approved and payment_captured events
			// Other webhook types will return false and Checkout.com will retry
			WC_Checkoutcom_Utility::logger( 'Flow webhook: No order found for webhook processing. Payment ID: ' . ($data->data->id ?? 'NULL') . ' - Will attempt to queue or process via webhook handlers' );
		}

		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Event Type Data' );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Event Type Data: ' . wp_json_encode( $data ) );
		}

		// Get webhook event type from data.
		$event_type = $data->type;
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing event type: ' . $event_type );
		}

		switch ( $event_type ) {
			case 'card_verified':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing card_verified event' );
				}
				$response = WC_Checkout_Com_Webhook::card_verified( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: card_verified response: ' . wp_json_encode( $response ) );
				}
				break;
			case 'payment_approved':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_approved event' );
				}
				
				// Check if merchant wants to skip authorization status update when using "Authorize and Capture"
				// This prevents webhook race conditions when capture delay is short
				$auto_capture_enabled = '1' === WC_Admin_Settings::get_option( 'ckocom_card_autocap', '1' );
				$skip_auth_status_update = '1' === WC_Admin_Settings::get_option( 'ckocom_skip_auth_status_update', '0' );
				
				if ( $auto_capture_enabled && $skip_auth_status_update ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: "Authorize and Capture" + "Skip Authorization Status Update" enabled - skipping payment_approved status update. Will wait for payment_captured webhook to update order status directly.' );
					
					// Still add order note for audit trail
					$webhook_data = $data->data;
					$payment_id = $webhook_data->id ?? 'N/A';
					$action_id = $webhook_data->action_id ?? 'N/A';
					$order_id = isset($webhook_data->metadata->order_id) ? $webhook_data->metadata->order_id : null;
					
					// Fallback: use reference as order ID if metadata->order_id is not set
					if ( empty( $order_id ) && isset( $webhook_data->reference ) && is_numeric( $webhook_data->reference ) ) {
						$order_id = $webhook_data->reference;
					}
					
					if ( $order_id ) {
						$order = wc_get_order( $order_id );
						if ( $order ) {
							$order->add_order_note( 
								sprintf( 
									__( 'Payment approved webhook received (Payment ID: %s). "Skip Authorization Status Update" enabled - waiting for payment_captured webhook to complete order.', 'checkout-com-unified-payments-api' ), 
									$payment_id 
								) 
							);
							// Set authorized meta for tracking
							$order->update_meta_data( 'cko_payment_authorized', true );
							$order->update_meta_data( '_cko_payment_id', $payment_id );
							$order->set_transaction_id( $action_id );
							$order->save();
						}
					}
					
					$response = true; // Acknowledge webhook successfully
					break;
				}
				
				$response = WC_Checkout_Com_Webhook::authorize_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_approved response: ' . wp_json_encode( $response ) );
				}
				
				// If processing failed, queue the webhook for later processing
				if ( false === $response ) {
					$webhook_data = $data->data;
					$payment_id = $webhook_data->id ?? null;
					$order_id = isset($webhook_data->metadata->order_id) 
						? $webhook_data->metadata->order_id 
						: null;
					$payment_session_id = isset($webhook_data->metadata->cko_payment_session_id)
						? $webhook_data->metadata->cko_payment_session_id
						: null;
					
					// Only queue if we have payment_id (required for matching)
					if ( $payment_id && class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
						$queued = WC_Checkout_Com_Webhook_Queue::save_pending_webhook(
							$payment_id,
							$order_id,
							$payment_session_id,
							'payment_approved',
							$data
						);
						
						if ( $queued ) {
							WC_Checkoutcom_Utility::logger(
								'WEBHOOK QUEUE: payment_approved webhook queued - ' .
								'Payment ID: ' . $payment_id . ', ' .
								'Order ID: ' . ($order_id ?? 'NULL') . ', ' .
								'Session ID: ' . ($payment_session_id ?? 'NULL')
							);
							
							// CRITICAL: Set response to true so HTTP 200 is sent
							// This tells Checkout.com webhook was processed successfully
							// Checkout.com will NOT retry
							$response = true;
						} else {
							if ( $webhook_debug_enabled ) {
								WC_Checkoutcom_Utility::logger( 'WEBHOOK QUEUE: Failed to queue payment_approved webhook' );
							}
						}
					} else {
						if ( $webhook_debug_enabled ) {
							WC_Checkoutcom_Utility::logger( 'WEBHOOK QUEUE: Cannot queue payment_approved webhook - Payment ID missing or queue class not available' );
						}
					}
				}
				break;
			case 'payment_captured':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_captured event' );
				}
				$response = WC_Checkout_Com_Webhook::capture_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_captured response: ' . wp_json_encode( $response ) );
				}
				
				// If processing failed, queue the webhook for later processing
				if ( false === $response ) {
					$webhook_data = $data->data;
					$payment_id = $webhook_data->id ?? null;
					$order_id = isset($webhook_data->metadata->order_id) 
						? $webhook_data->metadata->order_id 
						: null;
					$payment_session_id = isset($webhook_data->metadata->cko_payment_session_id)
						? $webhook_data->metadata->cko_payment_session_id
						: null;
					
					// Only queue if we have payment_id (required for matching)
					if ( $payment_id && class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
						$queued = WC_Checkout_Com_Webhook_Queue::save_pending_webhook(
							$payment_id,
							$order_id,
							$payment_session_id,
							'payment_captured',
							$data
						);
						
						if ( $queued ) {
							WC_Checkoutcom_Utility::logger(
								'WEBHOOK QUEUE: payment_captured webhook queued - ' .
								'Payment ID: ' . $payment_id . ', ' .
								'Order ID: ' . ($order_id ?? 'NULL') . ', ' .
								'Session ID: ' . ($payment_session_id ?? 'NULL')
							);
							
							// CRITICAL: Set response to true so HTTP 200 is sent
							// This tells Checkout.com webhook was processed successfully
							// Checkout.com will NOT retry
							$response = true;
						} else {
							if ( $webhook_debug_enabled ) {
								WC_Checkoutcom_Utility::logger( 'WEBHOOK QUEUE: Failed to queue payment_captured webhook' );
							}
						}
					} else {
						if ( $webhook_debug_enabled ) {
							WC_Checkoutcom_Utility::logger( 'WEBHOOK QUEUE: Cannot queue payment_captured webhook - Payment ID missing or queue class not available' );
						}
					}
				}
				break;
			case 'payment_voided':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_voided event' );
				}
				$response = WC_Checkout_Com_Webhook::void_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_voided response: ' . wp_json_encode( $response ) );
				}
				break;
			case 'payment_capture_declined':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_capture_declined event' );
				}
				$response = WC_Checkout_Com_Webhook::capture_declined( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_capture_declined response: ' . wp_json_encode( $response ) );
				}
				break;
			case 'payment_refunded':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_refunded event' );
				}
				$response = WC_Checkout_Com_Webhook::refund_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_refunded response: ' . wp_json_encode( $response ) );
				}
				break;
			case 'payment_canceled':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing payment_canceled event' );
				}
				$response = WC_Checkout_Com_Webhook::cancel_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: payment_canceled response: ' . wp_json_encode( $response ) );
				}
				break;
			case 'payment_declined':
			case 'payment_authentication_failed':
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Processing ' . $event_type . ' event' );
				}
				$response = WC_Checkout_Com_Webhook::decline_payment( $data );
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: ' . $event_type . ' response: ' . wp_json_encode( $response ) );
				}
				break;

			default:
				if ( $webhook_debug_enabled ) {
					WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Unknown event type: ' . $event_type . ', using default response' );
				}
				$response = true;
				break;
		}
		
		// CRITICAL: Mark webhook as processed after successful processing (prevent duplicate processing)
		// This ensures one webhook = one order update
		if ( $order && true === $response ) {
			// Webhook processed successfully - mark as processed
			$processed_webhooks = $order->get_meta( '_cko_processed_webhook_ids' );
			if ( ! is_array( $processed_webhooks ) ) {
				$processed_webhooks = array();
			}
			
			// Create unique webhook identifier (must match the logic used for deduplication check above)
			$action_id = isset( $data->data->action_id ) ? $data->data->action_id : null;
			$event_type = $data->type;
			$action_based_events = array( 'payment_refunded', 'payment_voided', 'payment_captured', 'payment_capture_declined' );
			
			if ( ! empty( $action_id ) && in_array( $event_type, $action_based_events, true ) ) {
				$webhook_id = $action_id . '_' . $event_type;
			} else {
				$webhook_id = $data->data->id . '_' . $event_type;
			}
			
			// Add to processed list if not already there
			if ( ! in_array( $webhook_id, $processed_webhooks, true ) ) {
				$processed_webhooks[] = $webhook_id;
				$order->update_meta_data( '_cko_processed_webhook_ids', array_unique( $processed_webhooks ) );
				$order->save();
				WC_Checkoutcom_Utility::logger( 'WEBHOOK: ✅ Marked as processed - Payment ID: ' . $data->data->id . ', Action ID: ' . ( $action_id ?? 'N/A' ) . ', Type: ' . $event_type . ', Order: ' . $order->get_id() );
			}
		}

		$http_code = $response ? 200 : 400;
		if ( $webhook_debug_enabled ) {
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Final response code: ' . $http_code );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Final response value: ' . wp_json_encode( $response ) );
			WC_Checkoutcom_Utility::logger( 'WEBHOOK DEBUG: Sending response - Code: ' . $http_code . ', Message: ' . ($response ? 'OK' : 'Failed') );
		}
		$this->send_response($http_code, $response ? 'OK' : 'Failed');
		
		} catch ( Exception $e ) {
			// Log the exception and return 500 error
			WC_Checkoutcom_Utility::logger( 'Webhook handler exception: ' . $e->getMessage(), $e );
			$this->send_response(500, 'Internal Server Error');
		}
	}

	/**
	 * Mask email for logging (privacy protection).
	 * Example: john.doe@example.com => j***e@example.com
	 *
	 * @param string $email The email to mask.
	 * @return string Masked email.
	 */
	private function mask_email( $email ) {
		if ( empty( $email ) || ! is_string( $email ) ) {
			return '(invalid)';
		}
		
		$parts = explode( '@', $email );
		if ( count( $parts ) !== 2 ) {
			return '(invalid)';
		}
		
		$local  = $parts[0];
		$domain = $parts[1];
		
		// Mask local part: show first and last char, mask the rest
		$local_len = strlen( $local );
		if ( $local_len <= 2 ) {
			$masked_local = $local[0] . '***';
		} else {
			$masked_local = $local[0] . '***' . $local[ $local_len - 1 ];
		}
		
		return $masked_local . '@' . $domain;
	}

	/**
	 * Helper to send response with proper HTTP status and exit.
	 */
	private function send_response($status_code, $message) {
		status_header($status_code);
		if ( ! headers_sent() ) {
			header('Content-Type: application/json; charset=utf-8');
		}
		
		$response_data = [
			'status'  => $status_code,
			'message' => $message,
		];
		
		echo wp_json_encode($response_data);
		exit;
	}

	/**
	 * Secure AJAX handler for creating payment sessions.
	 * This prevents the secret key from being exposed to the frontend.
	 *
	 * @return void
	 */
	public function ajax_create_payment_session() {
		// Verify nonce for security
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'cko_flow_payment_session' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Security check failed. Please refresh the page and try again.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}

		// Get core settings bypassing Polylang filters to ensure current saved values are used.
		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );

		// Verify secret key is configured
		$secret_key = isset( $core_settings['ckocom_sk'] ) ? $core_settings['ckocom_sk'] : '';
		if ( empty( $secret_key ) ) {
			WC_Checkoutcom_Utility::logger( 'Error: Secret key not configured for payment session creation' );
			wp_send_json_error( array(
				'message' => __( 'Payment gateway not properly configured. Please contact support.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}

		// Get payment session request data from POST
		if ( ! isset( $_POST['payment_session_request'] ) ) {
			wp_send_json_error( array(
				'message' => __( 'Invalid request data.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}

		// Decode and sanitize the payment session request
		$payment_session_request = json_decode( wp_unslash( $_POST['payment_session_request'] ), true );
		
		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $payment_session_request ) ) {
			WC_Checkoutcom_Utility::logger( 'Error: Invalid JSON in payment session request: ' . json_last_error_msg() );
			wp_send_json_error( array(
				'message' => __( 'Invalid request format.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// Log the email being sent to Checkout.com for debugging email mismatches
		// Sanitize email before logging to prevent log injection
		$customer_email_for_payment = isset( $payment_session_request['customer']['email'] ) ? sanitize_email( $payment_session_request['customer']['email'] ) : '(not set)';
		WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] Creating payment session with Email: ' . $customer_email_for_payment );

		// CRITICAL: Recalculate amount and items from fresh WooCommerce cart
		// Client-side #cart-info may have stale data after coupon changes
		// The server always has the most up-to-date cart state
		if ( WC()->cart && ! WC()->cart->is_empty() ) {
			$fresh_cart_info = WC_Checkoutcom_Api_Request::get_cart_info( true );
			
			if ( ! empty( $fresh_cart_info['order_amount'] ) ) {
				$client_amount = isset( $payment_session_request['amount'] ) ? $payment_session_request['amount'] : 0;
				$server_amount = $fresh_cart_info['order_amount'];
				
				// Only override if amounts differ (coupon was applied after page load)
				if ( $client_amount !== $server_amount ) {
					WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] Amount mismatch detected - using fresh server value. Client: ' . $client_amount . ', Server: ' . $server_amount );
					$payment_session_request['amount'] = $server_amount;
				}
			}
			
			// Always use fresh items from server to ensure PayPal validation passes
			// PayPal requires amount = sum(items.unit_price × quantity)
			if ( ! empty( $fresh_cart_info['order_lines'] ) ) {
				$payment_session_request['items'] = $fresh_cart_info['order_lines'];
				WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] Using fresh items from server cart: ' . count( $fresh_cart_info['order_lines'] ) . ' items' );
			}
		}

		// Strip 'stored_card' from enabled_payment_methods if save card is not enabled.
		// Polylang may return a stale language-specific copy of flow settings that still has
		// stored_card checked. stored_card requires a channel-scoped vault lookup and triggers
		// processing_channel_id_required on accounts without a channel-scoped API key.
		if ( function_exists( 'cko_get_raw_option' ) ) {
			$raw_flow_settings  = cko_get_raw_option( 'woocommerce_wc_checkout_com_flow_settings' );
			$raw_cards_settings = cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' );
		} else {
			$raw_flow_settings  = get_option( 'woocommerce_wc_checkout_com_flow_settings', array() );
			$raw_cards_settings = $core_settings;
		}
		$save_card_enabled = '1' === ( isset( $raw_cards_settings['ckocom_card_saved'] ) ? $raw_cards_settings['ckocom_card_saved'] : '0' );

		if ( ! $save_card_enabled && isset( $payment_session_request['enabled_payment_methods'] ) && is_array( $payment_session_request['enabled_payment_methods'] ) ) {
			$payment_session_request['enabled_payment_methods'] = array_values(
				array_filter(
					$payment_session_request['enabled_payment_methods'],
					function( $method ) {
						return 'stored_card' !== $method;
					}
				)
			);
		}

		// Enforce enabled_payment_methods from raw settings to prevent Polylang stale values.
		$raw_enabled_methods = isset( $raw_flow_settings['flow_enabled_payment_methods'] ) ? $raw_flow_settings['flow_enabled_payment_methods'] : array();
		if ( is_array( $raw_enabled_methods ) && ! empty( $raw_enabled_methods ) ) {
			if ( ! $save_card_enabled ) {
				$raw_enabled_methods = array_values( array_filter( $raw_enabled_methods, function( $m ) { return 'stored_card' !== $m; } ) );
			}
			$payment_session_request['enabled_payment_methods'] = $raw_enabled_methods;
		} elseif ( isset( $payment_session_request['enabled_payment_methods'] ) ) {
			unset( $payment_session_request['enabled_payment_methods'] );
		}

		// Customer-Initiated Transaction (CIT) flag for subscriptions.
		// When the cart (or the order being paid on an order-pay page) contains a subscription,
		// this first payment is a customer-initiated recurring setup, so it must be sent with
		// payment_type = Recurring (sets up the stored-credential / recurring agreement).
		// We deliberately do NOT send merchant_initiated here — the customer is present and
		// Checkout.com treats its absence as a customer-initiated payment; sending it on the
		// initial Flow session is unnecessary/incorrect. Renewals (MIT) are handled server-side
		// in WC_Checkoutcom_Api_Request with merchant_initiated=true + previous_payment_id.
		// We enforce this here, server-side, so the client cannot tamper with it.
		$is_subscription_cit = false;
		if ( class_exists( 'WC_Subscriptions_Cart' ) && WC()->cart && ! WC()->cart->is_empty()
			&& WC_Subscriptions_Cart::cart_contains_subscription() ) {
			$is_subscription_cit = true;
		} else {
			// Order-pay fallback: paying for an existing subscription parent order (cart may be empty).
			$cko_cit_order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
			if ( $cko_cit_order_id && function_exists( 'wcs_order_contains_subscription' ) ) {
				$cko_cit_order = wc_get_order( $cko_cit_order_id );
				if ( $cko_cit_order && wcs_order_contains_subscription( $cko_cit_order, 'parent' ) ) {
					$is_subscription_cit = true;
				}
			}
		}

		if ( $is_subscription_cit ) {
			$payment_session_request['payment_type'] = class_exists( 'Checkout\\Payments\\PaymentType' ) ? \Checkout\Payments\PaymentType::$recurring : 'Recurring';
			// Ensure no merchant_initiated flag leaks in from the client for a CIT.
			unset( $payment_session_request['merchant_initiated'] );
			WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] CIT subscription detected — payment_type=Recurring (merchant_initiated not sent)' );
		}

		// Subscription "Change payment method" flow (customer/admin updating the card on an
		// existing subscription). The client flags this via is_subscription_payment_change when the
		// order-pay URL carries ?change_payment_method=<id>. We build a ZERO-AMOUNT, capture:false
		// account-verification session so swapping a card never charges the customer, and mark it
		// Recurring. The verification still returns a usable source.id, which process_payment ->
		// handle_subscription_payment_method_change() then stores on the subscription for future
		// MIT renewals. We re-verify server-side that the referenced id is really a subscription
		// before trusting the client flag.
		$is_sub_pay_change = ! empty( $_POST['is_subscription_payment_change'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['is_subscription_payment_change'] ) );
		if ( $is_sub_pay_change && is_user_logged_in() ) {
			$change_sub_id = isset( $_POST['change_payment_method'] ) ? absint( wp_unslash( $_POST['change_payment_method'] ) ) : 0;
			$change_sub    = $change_sub_id ? wc_get_order( $change_sub_id ) : false;
			if ( $change_sub && function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $change_sub ) ) {
				$payment_session_request['amount']       = 0;     // account verification — no charge for changing a card
				$payment_session_request['capture']      = false;
				$payment_session_request['payment_type'] = class_exists( 'Checkout\\Payments\\PaymentType' ) ? \Checkout\Payments\PaymentType::$recurring : 'Recurring';
				unset( $payment_session_request['items'] );
				unset( $payment_session_request['merchant_initiated'] );

				// Detach this verification from the subscription so the payment webhooks
				// (authorize_payment / void_payment) cannot resolve the subscription as an "order"
				// and flip its status to on-hold. The webhook resolves the order from
				// metadata.order_id, falling back to a NUMERIC reference — so we clear order_id and
				// set a non-numeric reference. Our handle_subscription_payment_method_change() uses
				// the payment_id from the return URL (not the reference), so detaching is safe.
				if ( isset( $payment_session_request['metadata'] ) && is_array( $payment_session_request['metadata'] ) ) {
					unset( $payment_session_request['metadata']['order_id'] );
				}
				$payment_session_request['reference'] = 'cko-card-change-' . $change_sub_id;

				WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] Subscription change-payment-method mode — amount=0, capture=false, payment_type=Recurring, detached from subscription webhooks. Subscription ID: ' . $change_sub_id );
			} else {
				WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] is_subscription_payment_change flag set but id ' . $change_sub_id . ' is not a subscription — ignoring.' );
			}
		}

		// Add Payment Method (My Account → Payment methods → Add payment method). No cart/order here,
		// so force a $0 card verification: amount=0, capture=false, cards only, no items (sending the
		// inherited cart items with a $0 amount is what triggers Checkout.com's items_invalid error),
		// and a non-numeric reference so payment webhooks never resolve an order from it. On success
		// the wc_checkoutcom_flow_add_payment_method endpoint tokenises the card as a WC_Payment_Token_CC.
		$is_add_payment_method = ! empty( $_POST['is_add_payment_method'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['is_add_payment_method'] ) );
		if ( $is_add_payment_method && is_user_logged_in() ) {
			$payment_session_request['amount']                  = 0;
			$payment_session_request['capture']                 = false;
			$payment_session_request['enabled_payment_methods'] = array( 'card' );
			$payment_session_request['reference']               = 'cko-add-payment-method-' . get_current_user_id();
			unset( $payment_session_request['items'] );
			unset( $payment_session_request['merchant_initiated'] );
			if ( isset( $payment_session_request['metadata'] ) && is_array( $payment_session_request['metadata'] ) ) {
				unset( $payment_session_request['metadata']['order_id'] );
			}
			if ( empty( $payment_session_request['currency'] ) ) {
				$payment_session_request['currency'] = get_woocommerce_currency();
			}
			// Drop billing/shipping address when the country is missing or not a valid 2-letter ISO
			// code. A $0 card verification doesn't need an address, and an empty/invalid country
			// triggers Checkout.com's billing_address_country_invalid / shipping_address_country_invalid.
			$bill_country = isset( $payment_session_request['billing']['address']['country'] ) ? (string) $payment_session_request['billing']['address']['country'] : '';
			if ( ! preg_match( '/^[A-Za-z]{2}$/', $bill_country ) ) {
				unset( $payment_session_request['billing'] );
			}
			$ship_country = isset( $payment_session_request['shipping']['address']['country'] ) ? (string) $payment_session_request['shipping']['address']['country'] : '';
			if ( ! preg_match( '/^[A-Za-z]{2}$/', $ship_country ) ) {
				unset( $payment_session_request['shipping'] );
			}
			WC_Checkoutcom_Utility::logger( '[PAYMENT SESSION] Add-payment-method mode — amount=0, capture=false, cards-only, items dropped, reference detached, address ' . ( isset( $payment_session_request['billing'] ) ? 'kept' : 'dropped' ) . '. User ID: ' . get_current_user_id() );
		}

		// Determine API URL based on environment
		$api_url = 'https://api.checkout.com/payment-sessions';
		if ( isset( $core_settings['ckocom_environment'] ) && 'sandbox' === $core_settings['ckocom_environment'] ) {
			$api_url = 'https://api.sandbox.checkout.com/payment-sessions';
		}

		// Prepare the API request
		$request_args = array(
			'method'  => 'POST',
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Bearer ' . $secret_key,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( $payment_session_request ),
		);

		// Make the API request
		$response = wp_remote_request( $api_url, $request_args );

		// Check for request errors
		if ( is_wp_error( $response ) ) {
			WC_Checkoutcom_Utility::logger( 'Error creating payment session: ' . $response->get_error_message() );
			wp_send_json_error( array(
				'message' => __( 'Failed to create payment session. Please try again.', 'checkout-com-unified-payments-api' ),
				'error'   => $response->get_error_message(),
			) );
			return;
		}

		// Get response body
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$payment_session = json_decode( $response_body, true );

		// Check for API errors
		if ( $response_code >= 400 || ( isset( $payment_session['error_type'] ) || isset( $payment_session['error_codes'] ) ) ) {
			WC_Checkoutcom_Utility::logger( 'Payment Session API Error: ' . $response_body );
			wp_send_json_error( array(
				'message'     => isset( $payment_session['error_codes'] ) && is_array( $payment_session['error_codes'] ) 
					? __( 'Payment session error: ', 'checkout-com-unified-payments-api' ) . implode( ', ', $payment_session['error_codes'] )
					: __( 'Error creating payment session. Please try again.', 'checkout-com-unified-payments-api' ),
				'error_type'  => isset( $payment_session['error_type'] ) ? $payment_session['error_type'] : null,
				'error_codes' => isset( $payment_session['error_codes'] ) ? $payment_session['error_codes'] : null,
				'request_id'  => isset( $payment_session['request_id'] ) ? $payment_session['request_id'] : null,
			) );
			return;
		}

		// Success - return payment session
		wp_send_json_success( $payment_session );
	}
	
	/**
	 * AJAX handler to create order before payment processing.
	 * This ensures order exists before webhook arrives, preventing race conditions and duplicate orders.
	 *
	 * @return void
	 */
	public function ajax_create_order() {
		// Set proper headers for JSON response (only if not already sent).
		if ( ! headers_sent() ) {
			header( 'Content-Type: application/json' );
		}
		
		// Log entry point.
		if ( function_exists( 'WC_Checkoutcom_Utility' ) && method_exists( 'WC_Checkoutcom_Utility', 'logger' ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ========== ENTRY POINT ==========' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just logging keys, nonce verified below
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] POST data keys: ' . implode( ', ', array_map( 'sanitize_key', array_keys( $_POST ) ) ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just logging, nonce verified below
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Action: ' . ( isset( $_POST['action'] ) ? sanitize_text_field( wp_unslash( $_POST['action'] ) ) : 'NOT SET' ) );
		}
		
		// Verify nonce for security - check multiple possible locations.
		$nonce_value = '';
		if ( isset( $_POST['woocommerce-process-checkout-nonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_POST['woocommerce-process-checkout-nonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce from POST: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		} elseif ( isset( $_REQUEST['woocommerce-process-checkout-nonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_REQUEST['woocommerce-process-checkout-nonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce from REQUEST: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		} elseif ( isset( $_REQUEST['_wpnonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce from _wpnonce: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		}
		
		if ( empty( $nonce_value ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Nonce is empty' );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Available POST keys: ' . implode( ', ', array_keys( $_POST ) ) );
			wp_send_json_error( array(
				'message' => __( 'Session expired. Please refresh.', 'woocommerce' ),
			) );
			return;
		}
		
		$nonce_valid = wp_verify_nonce( $nonce_value, 'woocommerce-process_checkout' );
		if ( ! $nonce_valid ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Invalid nonce' );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce value: ' . substr( $nonce_value, 0, 10 ) . '...' );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce verification result: ' . ( $nonce_valid ? 'VALID' : 'INVALID' ) );
			wp_send_json_error( array(
				'message' => __( 'Session expired. Please refresh.', 'woocommerce' ),
			) );
			return;
		}
		
		WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Nonce validated successfully' );
		
		// Get payment session ID - CRITICAL for order lookup after 3DS return.
		// This links the order to the payment session so we can find it when user returns from 3DS.
		$payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) : '';
		
		if ( empty( $payment_session_id ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ⚠️ WARNING: payment_session_id is EMPTY - order lookup after 3DS return will rely on fallback methods (email+amount)' );
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ⚠️ This can cause "payment succeeded but no order" issues if fallbacks fail' );
		} else {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Payment session ID received: ' . substr( $payment_session_id, 0, 25 ) . '...' );
		}
		
		// Ensure WooCommerce is available.
		if ( ! function_exists( 'WC' ) || ! WC() ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: WooCommerce not available' );
			wp_send_json_error( array( 'message' => __( 'WooCommerce not available.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}
		
		// Check for existing order that can be reused.
		// This follows WooCommerce standard pattern: order_awaiting_payment session key.
		$existing_order_id = $this->get_reusable_order_id( $payment_session_id );
		
		if ( $existing_order_id ) {
			$existing_order = wc_get_order( $existing_order_id );
			
			if ( $existing_order ) {
				// Validate if this order can be reused for the current checkout.
				$reuse_validation = $this->validate_order_reuse( $existing_order );
				
				if ( $reuse_validation['can_reuse'] ) {
					WC_Checkoutcom_Utility::logger(
						sprintf(
							'[CREATE ORDER] ✅ REUSING existing order - Order ID: %d, Reason: %s',
							$existing_order_id,
							$reuse_validation['reason']
						)
					);
					
					// Update payment session ID if it changed (new payment attempt on same order).
					if ( ! empty( $payment_session_id ) ) {
						$old_session_id = $existing_order->get_meta( '_cko_payment_session_id' );
						if ( $old_session_id !== $payment_session_id ) {
							WC_Checkoutcom_Utility::logger(
								sprintf(
									'[CREATE ORDER] Updating payment session ID on reused order - Old: %s, New: %s',
									$old_session_id ?: '(none)',
									$payment_session_id
								)
							);
							$existing_order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
						}
					}
					
					// Store save card preference if available (update existing order).
					$save_card_preference = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
					if ( 'true' === $save_card_preference || 'yes' === $save_card_preference ) {
						$existing_order->update_meta_data( '_cko_save_card_preference', 'yes' );
						WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Save card preference updated on reused order: YES' );
					}
					
					$existing_order->save();
					
					wp_send_json_success(
						array(
							'order_id'       => $existing_order_id,
							'order_key'      => $existing_order->get_order_key(),
							'message'        => __( 'Using existing order.', 'checkout-com-unified-payments-api' ),
							'existing_order' => true,
							'reuse_reason'   => $reuse_validation['reason'],
						)
					);
					return;
				} else {
					// Cannot reuse - log reason and create new order.
					WC_Checkoutcom_Utility::logger(
						sprintf(
							'[CREATE ORDER] ⚠️ CANNOT reuse existing order %d - Reason: %s - Will create NEW order',
							$existing_order_id,
							$reuse_validation['reason']
						)
					);
					
					// Add note to old order explaining why it was not reused.
					$existing_order->add_order_note(
						sprintf(
							/* translators: %s: reason for not reusing */
							__( 'Order not reused for new payment attempt. Reason: %s. A new order was created.', 'checkout-com-unified-payments-api' ),
							esc_html( $reuse_validation['reason'] )
						)
					);
					$existing_order->save();
					
					// CRITICAL: Clear WooCommerce session to prevent create_order() from resuming the old order.
					// WooCommerce's create_order() internally checks 'order_awaiting_payment' and will resume
					// that order (changing it back to pending) unless we clear it.
					if ( WC()->session ) {
						WC()->session->set( 'order_awaiting_payment', null );
						WC_Checkoutcom_Utility::logger(
							sprintf(
								'[CREATE ORDER] Cleared order_awaiting_payment session to prevent WooCommerce from resuming order %d',
								$existing_order_id
							)
						);
					}
				}
			}
		} else {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] No existing reusable order found - creating new order' );
		}
		
		// Use WooCommerce public checkout flow (no Reflection).
		// Run validation hooks first.
		try {
			do_action( 'woocommerce_before_checkout_process' );
			do_action( 'woocommerce_checkout_process' );
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR in validation hooks: ' . $e->getMessage() );
			wp_send_json_error( array( 'message' => __( 'Error during checkout validation: ', 'checkout-com-unified-payments-api' ) . $e->getMessage() ) );
			return;
		}

		// Get posted data and create order using public API.
		$checkout = WC()->checkout();
		if ( ! $checkout ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Checkout class not available' );
			wp_send_json_error( array( 'message' => __( 'Checkout class not available.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}

		$posted_data = $checkout->get_posted_data();

		// Log posted data for debugging (sanitized - no sensitive card details)
		$debug_logging = 'yes' === WC_Admin_Settings::get_option( 'cko_flow_debug_logging', 'no' );
		if ( $debug_logging ) {
			$safe_posted_data = array(
				'billing_first_name'  => isset( $posted_data['billing_first_name'] ) ? $posted_data['billing_first_name'] : '(not set)',
				'billing_last_name'   => isset( $posted_data['billing_last_name'] ) ? $posted_data['billing_last_name'] : '(not set)',
				'billing_email'       => isset( $posted_data['billing_email'] ) && ! empty( $posted_data['billing_email'] ) ? $this->mask_email( $posted_data['billing_email'] ) : '(not set)',
				'billing_phone'       => isset( $posted_data['billing_phone'] ) ? ( ! empty( $posted_data['billing_phone'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'billing_address_1'   => isset( $posted_data['billing_address_1'] ) ? ( ! empty( $posted_data['billing_address_1'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'billing_city'        => isset( $posted_data['billing_city'] ) ? $posted_data['billing_city'] : '(not set)',
				'billing_state'       => isset( $posted_data['billing_state'] ) ? $posted_data['billing_state'] : '(not set)',
				'billing_postcode'    => isset( $posted_data['billing_postcode'] ) ? $posted_data['billing_postcode'] : '(not set)',
				'billing_country'     => isset( $posted_data['billing_country'] ) ? $posted_data['billing_country'] : '(not set)',
				'shipping_first_name' => isset( $posted_data['shipping_first_name'] ) ? ( ! empty( $posted_data['shipping_first_name'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'shipping_address_1'  => isset( $posted_data['shipping_address_1'] ) ? ( ! empty( $posted_data['shipping_address_1'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'shipping_city'       => isset( $posted_data['shipping_city'] ) ? ( ! empty( $posted_data['shipping_city'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'shipping_country'    => isset( $posted_data['shipping_country'] ) ? ( ! empty( $posted_data['shipping_country'] ) ? $posted_data['shipping_country'] : 'EMPTY' ) : '(not set)',
				'payment_method'      => isset( $posted_data['payment_method'] ) ? $posted_data['payment_method'] : '(not set)',
				'ship_to_different'   => isset( $posted_data['ship_to_different_address'] ) ? ( $posted_data['ship_to_different_address'] ? 'YES' : 'NO' ) : '(not set)',
				'order_comments'      => isset( $posted_data['order_comments'] ) ? ( ! empty( $posted_data['order_comments'] ) ? 'SET' : 'EMPTY' ) : '(not set)',
				'terms'               => isset( $posted_data['terms'] ) ? ( $posted_data['terms'] ? 'ACCEPTED' : 'NOT ACCEPTED' ) : '(not set)',
			);
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] Posted data for order creation: ' . wp_json_encode( $safe_posted_data ) );
		}

		// Create order using WooCommerce checkout processing to preserve full hook behavior
		// (subscriptions, fees, coupons, taxes, shipping, and extension integrations).
		if ( ! is_callable( array( $checkout, 'create_order' ) ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: WC_Checkout::create_order() not available' );
			wp_send_json_error( array( 'message' => __( 'Checkout API not available.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}

		$order_id = $checkout->create_order( $posted_data );

		if ( is_wp_error( $order_id ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Failed to create order: ' . $order_id->get_error_message() );
			wp_send_json_error( array(
				'message' => __( 'Failed to create order. Please try again.', 'checkout-com-unified-payments-api' ),
				'error'   => $order_id->get_error_message(),
			) );
			return;
		}

		if ( empty( $order_id ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Invalid order ID returned' );
			wp_send_json_error( array( 'message' => __( 'Failed to create order. Invalid order ID returned.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			WC_Checkoutcom_Utility::logger( '[CREATE ORDER] ERROR: Order not found after creation - Order ID: ' . $order_id );
			wp_send_json_error( array( 'message' => __( 'Order not found after creation.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}

		// Ensure payment method is set (in case it was not saved by checkout processing).
		if ( $order->get_payment_method() !== $this->id ) {
			$order->set_payment_method( $this->id );
			$order->set_payment_method_title( $this->get_title() );
		}

		// Store payment session ID if available.
		if ( ! empty( $payment_session_id ) ) {
			$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
		}

		// Store save card preference if available.
		$save_card_preference = isset( $_POST['cko-flow-save-card-persist'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-save-card-persist'] ) ) : '';
		if ( 'true' === $save_card_preference || 'yes' === $save_card_preference ) {
			$order->update_meta_data( '_cko_save_card_preference', 'yes' );
		}

		// Trigger standard checkout hooks for compatibility (subscriptions/plugins rely on these).
		// WC_Checkout::create_order() already fires these in newer versions.
		if ( 0 === did_action( 'woocommerce_checkout_update_order_meta' ) ) {
			do_action( 'woocommerce_checkout_update_order_meta', $order_id, $posted_data );
		}
		if ( 0 === did_action( 'woocommerce_checkout_order_processed' ) ) {
			do_action( 'woocommerce_checkout_order_processed', $order_id, $posted_data, $order );
		}

		// Ensure order status is pending (use update_status to fire hooks properly).
		if ( 'pending' !== $order->get_status() ) {
			$order->update_status( 'pending', __( 'Order created for Flow payment.', 'checkout-com-unified-payments-api' ) );
		}

		// Store cart hash for future reuse validation.
		if ( WC()->cart ) {
			$cart_hash = WC()->cart->get_cart_hash();
			if ( ! empty( $cart_hash ) && $order->get_cart_hash() !== $cart_hash ) {
				$order->set_cart_hash( $cart_hash );
			}
		}

		$order->save();

		// Comprehensive logging for new order creation.
		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[CREATE ORDER] ✅ NEW order created - ID: %d, Total: %s %s, Status: %s, Payment Session: %s, Customer: %s',
				$order_id,
				$order->get_total(),
				$order->get_currency(),
				$order->get_status(),
				$payment_session_id ?: '(not set)',
				$order->get_billing_email() ?: '(guest)'
			)
		);

		// Add order note documenting order creation for audit trail.
		$order->add_order_note(
			sprintf(
				/* translators: %s: payment session ID */
				__( 'Order created for Flow 3DS payment. Payment Session: %s', 'checkout-com-unified-payments-api' ),
				$payment_session_id ?: __( '(pending)', 'checkout-com-unified-payments-api' )
			)
		);
		$order->save();

		wp_send_json_success(
			array(
				'order_id'        => $order_id,
				'order_key'       => $order->get_order_key(),
				'message'         => __( 'Order created successfully.', 'checkout-com-unified-payments-api' ),
				'existing_order'  => false,
				// BUG FIX: Return a fresh nonce after order creation.
				// During checkout, WooCommerce may create a customer account and log them in,
				// which changes the user context. The original nonce (generated for guest user ID 0)
				// becomes invalid for the now-logged-in user. This refreshed nonce ensures
				// subsequent AJAX calls (like submit_payment_session) can verify successfully.
				'refreshed_nonce' => wp_create_nonce( 'cko_flow_payment_session' ),
			)
		);
	}

	/**
	 * Exclude payment methods section from checkout fragment updates.
	 *
	 * This filter prevents WooCommerce from replacing the payment methods HTML
	 * during checkout updates (e.g., when a coupon is applied or cart total changes).
	 * This preserves the Flow component and any entered card details.
	 *
	 * The payment amount is handled via the handleSubmit callback which sends
	 * the correct amount to the server when payment is submitted.
	 *
	 * @since 5.0.3
	 *
	 * @param array $fragments Array of HTML fragments to update.
	 *
	 * @return array Modified fragments array.
	 */
	public function exclude_payment_method_from_fragments( $fragments ) {
		// Only exclude when Flow payment method is active/selected.
		// Check if this is a checkout page with Flow payment method.
		if ( ! is_checkout() ) {
			return $fragments;
		}

		// Check if Flow payment method is available.
		$available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
		if ( ! isset( $available_gateways['wc_checkout_com_flow'] ) ) {
			return $fragments;
		}

		// CRITICAL FIX: Only exclude fragments when we have EXPLICIT signals.
		// Some themes/environments use AJAX fragments to render payment methods on initial page load.
		// If we exclude the fragment on initial load, payment methods never appear ("no payment methods available").
		// 
		// We ONLY exclude when:
		// 1. JavaScript explicitly tells us Flow is initialized (cko_flow_initialized flag)
		// 2. User performed an explicit action (coupon add/remove, shipping method change)
		//
		// This ensures the initial AJAX load always includes the payment fragment.
		
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- This is a fragment filter, nonce verified by WooCommerce
		$has_coupon_action = ! empty( $_POST['coupon_code'] ) || isset( $_POST['remove_coupon'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$has_shipping_change = ! empty( $_POST['shipping_method'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$flow_initialized = ! empty( $_POST['cko_flow_initialized'] ) || ! empty( $_REQUEST['cko_flow_initialized'] );
		
		// Only exclude if we have explicit signals - no heuristics
		$should_exclude = $flow_initialized || $has_coupon_action || $has_shipping_change;
		
		if ( ! $should_exclude ) {
			WC_Checkoutcom_Utility::logger( '[FLOW FRAGMENTS] Allowing payment fragment - no explicit exclude signal. flow_initialized=' . ( $flow_initialized ? 'yes' : 'no' ) . ', coupon=' . ( $has_coupon_action ? 'yes' : 'no' ) . ', shipping=' . ( $has_shipping_change ? 'yes' : 'no' ) );
			return $fragments;
		}

		// Remove the payment methods fragment to prevent it from being replaced.
		// This preserves the Flow component and entered card details.
		if ( isset( $fragments['.woocommerce-checkout-payment'] ) ) {
			unset( $fragments['.woocommerce-checkout-payment'] );
			WC_Checkoutcom_Utility::logger( '[FLOW FRAGMENTS] Excluded .woocommerce-checkout-payment from fragment update to preserve Flow component. Reason: ' . 
				( $flow_initialized ? 'flow_initialized' : ( $has_coupon_action ? 'coupon_action' : ( $has_shipping_change ? 'shipping_change' : 'user_interaction' ) ) ) );
		}

		return $fragments;
	}

	/**
	 * Prevent WooCommerce from resuming failed orders during checkout.
	 *
	 * This method runs early in the checkout process (woocommerce_before_checkout_process)
	 * to check if the order_awaiting_payment session contains a failed order.
	 * If so, it clears the session to force WooCommerce to create a new order.
	 *
	 * This is critical because WooCommerce's create_order() method automatically resumes
	 * any order found in the order_awaiting_payment session, which would change a failed
	 * order back to pending status.
	 *
	 * @since 5.0.3
	 *
	 * @return void
	 */
	public function prevent_failed_order_reuse() {
		WC_Checkoutcom_Utility::logger( '[PREVENT ORDER REUSE] ========== HOOK FIRED ==========' );
		
		// Only apply to Flow payment method.
		// Check both POST (classic) and REST request body (blocks)
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified by WooCommerce checkout process.
		$payment_method = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';
		
		// For Blocks checkout, check REST API request body
		if ( empty( $payment_method ) && defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$json_params = file_get_contents( 'php://input' );
			if ( $json_params ) {
				$request_data = json_decode( $json_params, true );
				if ( isset( $request_data['payment_method'] ) ) {
					$payment_method = sanitize_text_field( $request_data['payment_method'] );
				}
			}
		}
		
		WC_Checkoutcom_Utility::logger( sprintf( '[PREVENT ORDER REUSE] Payment method: %s', $payment_method ?: '(none)' ) );
		
		if ( 'wc_checkout_com_flow' !== $payment_method ) {
			return;
		}
		
		// Verify nonce for additional security (WooCommerce also verifies, but we verify explicitly for WordPress standards).
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified below.
		$nonce_value = isset( $_POST['woocommerce-process-checkout-nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['woocommerce-process-checkout-nonce'] ) ) : '';
		if ( empty( $nonce_value ) || ! wp_verify_nonce( $nonce_value, 'woocommerce-process_checkout' ) ) {
			// Nonce invalid - this shouldn't happen if WooCommerce checkout process is working correctly,
			// but we return early to prevent any issues.
			WC_Checkoutcom_Utility::logger( '[PREVENT ORDER REUSE] ⚠️ Nonce verification failed - skipping order reuse prevention' );
			return;
		}
		
		if ( ! WC()->session ) {
			return;
		}
		
		$session_order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
		if ( ! $session_order_id ) {
			return;
		}
		
		$existing_order = wc_get_order( $session_order_id );
		if ( ! $existing_order ) {
			return;
		}
		
		$order_status = $existing_order->get_status();
		
		// Check if order has failed or has security check failure flag.
		$security_check_failed = $existing_order->get_meta( '_cko_security_check_failed' );
		$should_prevent_reuse = false;
		$reason = '';
		
		if ( 'failed' === $order_status ) {
			$should_prevent_reuse = true;
			$reason = sprintf( 'Order %d has failed status', $session_order_id );
		} elseif ( ! empty( $security_check_failed ) ) {
			$should_prevent_reuse = true;
			$reason = sprintf( 'Order %d has security check failed flag', $session_order_id );
		}
		
		// Also check cart hash mismatch (cart contents changed).
		if ( ! $should_prevent_reuse && WC()->cart ) {
			$current_cart_hash = WC()->cart->get_cart_hash();
			$order_cart_hash = $existing_order->get_cart_hash();
			
			if ( ! empty( $current_cart_hash ) && ! empty( $order_cart_hash ) && $current_cart_hash !== $order_cart_hash ) {
				$should_prevent_reuse = true;
				$reason = sprintf( 'Order %d has cart hash mismatch (cart changed)', $session_order_id );
			}
		}
		
		// Check payment session ID mismatch (new payment session = new order).
		// This ensures each payment attempt gets its own order for clean tracking.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Already verified above.
		if ( ! $should_prevent_reuse ) {
			// Try POST first (Classic checkout)
			$current_payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) 
				? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) 
				: '';
			
			// If not in POST, check REST API request body (Blocks checkout)
			if ( empty( $current_payment_session_id ) && defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				$json_params = file_get_contents( 'php://input' );
				if ( $json_params ) {
					$request_data = json_decode( $json_params, true );
					// Check payment_data array for Blocks checkout
					if ( isset( $request_data['payment_data'] ) && is_array( $request_data['payment_data'] ) ) {
						foreach ( $request_data['payment_data'] as $data ) {
							if ( isset( $data['key'] ) && 'cko-flow-payment-session-id' === $data['key'] ) {
								$current_payment_session_id = sanitize_text_field( $data['value'] );
								break;
							}
						}
					}
				}
			}
			
			$order_payment_session_id = $existing_order->get_meta( '_cko_payment_session_id' );
			
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[PREVENT ORDER REUSE] Checking PS ID - Current: %s, Order: %s',
					$current_payment_session_id ? substr( $current_payment_session_id, 0, 25 ) . '...' : '(none)',
					$order_payment_session_id ? substr( $order_payment_session_id, 0, 25 ) . '...' : '(none)'
				)
			);
			
			// If both exist and don't match, this is a new payment attempt - create new order
			if ( ! empty( $current_payment_session_id ) 
				 && ! empty( $order_payment_session_id ) 
				 && $current_payment_session_id !== $order_payment_session_id ) {
				$should_prevent_reuse = true;
				$reason = sprintf( 
					'Order %d has different payment session ID (new payment attempt)', 
					$session_order_id
				);
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[PREVENT ORDER REUSE] Payment session ID mismatch - Order: %s, Current: %s',
						substr( $order_payment_session_id, 0, 25 ) . '...',
						substr( $current_payment_session_id, 0, 25 ) . '...'
					)
				);
			}
		}
		
		if ( $should_prevent_reuse ) {
			// Clear the session to prevent WooCommerce from resuming this order.
			WC()->session->set( 'order_awaiting_payment', null );
			
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[PREVENT ORDER REUSE] ⚠️ Cleared order_awaiting_payment session - %s. WooCommerce will now create a NEW order instead of resuming the old one.',
					$reason
				)
			);
			
			// Add note to the old order explaining what happened.
			$existing_order->add_order_note(
				sprintf(
					/* translators: %s: reason for not reusing */
					__( 'This order was not resumed for a new payment attempt. Reason: %s. A new order was created for the retry.', 'checkout-com-unified-payments-api' ),
					esc_html( $reason )
				)
			);
			$existing_order->save();
		} else {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[PREVENT ORDER REUSE] ✅ Order %d in session can be reused (status: %s, no security check failure, cart unchanged)',
					$session_order_id,
					$order_status
				)
			);
		}
	}

	/**
	 * Check payment session ID when WooCommerce is about to resume an order.
	 * 
	 * This hook fires via woocommerce_resume_order action WHEN WooCommerce decides to resume
	 * an existing order from the order_awaiting_payment session. At this point, we can check
	 * if the current payment session ID matches the order's payment session ID.
	 * 
	 * If they don't match, we clear the session so WooCommerce will create a new order instead.
	 * 
	 * @since 5.0.4
	 *
	 * @param int $order_id The order ID being resumed.
	 * @return void
	 */
	public function check_payment_session_on_resume( $order_id ) {
		WC_Checkoutcom_Utility::logger( sprintf( '[RESUME ORDER] ========== HOOK FIRED for Order %d ==========', $order_id ) );
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			WC_Checkoutcom_Utility::logger( '[RESUME ORDER] Order not found' );
			return;
		}
		
		// Only check for Flow payment method
		$payment_method = $order->get_payment_method();
		if ( ! empty( $payment_method ) && 'wc_checkout_com_flow' !== $payment_method ) {
			WC_Checkoutcom_Utility::logger( sprintf( '[RESUME ORDER] Not Flow payment method: %s', $payment_method ) );
			return;
		}
		
		// Get current payment session ID from multiple sources
		$current_payment_session_id = '';
		
		// Try POST (classic checkout)
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just reading value
		if ( isset( $_POST['cko-flow-payment-session-id'] ) ) {
			$current_payment_session_id = sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) );
		}
		
		// Try REST API body (blocks checkout)
		if ( empty( $current_payment_session_id ) && defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$json_body = file_get_contents( 'php://input' );
			if ( $json_body ) {
				$request_data = json_decode( $json_body, true );
				if ( isset( $request_data['payment_data'] ) && is_array( $request_data['payment_data'] ) ) {
					foreach ( $request_data['payment_data'] as $data ) {
						if ( isset( $data['key'] ) && 'cko-flow-payment-session-id' === $data['key'] ) {
							$current_payment_session_id = sanitize_text_field( $data['value'] );
							break;
						}
					}
				}
			}
		}
		
		$order_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
		
		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[RESUME ORDER] Order %d - Order PS: %s, Current PS: %s',
				$order_id,
				$order_payment_session_id ? substr( $order_payment_session_id, 0, 25 ) . '...' : '(none)',
				$current_payment_session_id ? substr( $current_payment_session_id, 0, 25 ) . '...' : '(none)'
			)
		);
		
		// If order already has a payment session ID and current request has a DIFFERENT one
		// MULTI-TAB HANDLING: This is expected behavior in multi-tab scenarios
		// We track all payment attempts - first successful one wins
		if ( ! empty( $order_payment_session_id ) && ! empty( $current_payment_session_id ) 
			 && $order_payment_session_id !== $current_payment_session_id ) {
			
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[RESUME ORDER] ⚠️ MULTI-TAB DETECTED - Order %d already has PS %s but current request has PS %s. Tracking this as additional payment attempt.',
					$order_id,
					substr( $order_payment_session_id, 0, 25 ),
					substr( $current_payment_session_id, 0, 25 )
				)
			);
			
			// Note: We now track all payment attempts in store_payment_session_id_in_order()
			// and ajax_submit_payment_session(). The first successful payment will update
			// the order status. Subsequent payments will be noted as duplicates from different tabs.
		}
		
		// If order has a payment session ID but current request has NONE
		if ( ! empty( $order_payment_session_id ) && empty( $current_payment_session_id ) ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[RESUME ORDER] Order %d has PS but current request has none - allowing resume (might be retry)',
					$order_id
				)
			);
		}
	}

	/**
	 * Prevent order reuse for WooCommerce Blocks checkout.
	 * 
	 * WooCommerce Blocks uses the Store API which bypasses woocommerce_before_checkout_process.
	 * This hook runs when the Store API processes an order.
	 *
	 * @since 5.0.4
	 *
	 * @param WC_Order $order The order being processed.
	 * @return void
	 */
	public function prevent_order_reuse_blocks_checkout( $order ) {
		// Only process Flow payments
		if ( $order->get_payment_method() !== $this->id ) {
			return;
		}
		
		// Get current payment session ID from POST or request data
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified by WooCommerce
		$current_payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) 
			? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) 
			: '';
		
		$order_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
		
		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[BLOCKS CHECKOUT] Order %d - Current PS: %s, Order PS: %s',
				$order->get_id(),
				$current_payment_session_id ? substr( $current_payment_session_id, 0, 20 ) . '...' : '(none)',
				$order_payment_session_id ? substr( $order_payment_session_id, 0, 20 ) . '...' : '(none)'
			)
		);
		
		// If order already has a different payment session ID, this is a problem
		// The order was reused when it shouldn't have been
		if ( ! empty( $order_payment_session_id ) 
			 && ! empty( $current_payment_session_id ) 
			 && $order_payment_session_id !== $current_payment_session_id ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[BLOCKS CHECKOUT] ⚠️ Order %d was INCORRECTLY reused - has different payment session ID. Will be handled by duplicate prevention.',
					$order->get_id()
				)
			);
		}
	}

	/**
	 * Clear order_awaiting_payment session if order has different payment session ID.
	 * 
	 * This hooks into checkout value retrieval (runs early) to clear the session
	 * before WooCommerce decides to reuse an order.
	 *
	 * @since 5.0.4
	 *
	 * @param mixed  $value The checkout field value.
	 * @param string $input The input name.
	 * @return mixed
	 */
	public function maybe_clear_order_awaiting_payment( $value, $input ) {
		static $checked = false;
		
		// Only run once per request
		if ( $checked ) {
			return $value;
		}
		$checked = true;
		
		// Only apply to Flow payment method
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just checking context
		$payment_method = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';
		if ( 'wc_checkout_com_flow' !== $payment_method ) {
			return $value;
		}
		
		if ( ! WC()->session ) {
			return $value;
		}
		
		$session_order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
		if ( ! $session_order_id ) {
			return $value;
		}
		
		$existing_order = wc_get_order( $session_order_id );
		if ( ! $existing_order ) {
			return $value;
		}
		
		// Get current payment session ID from POST
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just reading value
		$current_payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) 
			? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) 
			: '';
		
		$order_payment_session_id = $existing_order->get_meta( '_cko_payment_session_id' );
		
		// If order has a DIFFERENT payment session ID, clear the session to force new order
		if ( ! empty( $current_payment_session_id ) 
			 && ! empty( $order_payment_session_id ) 
			 && $current_payment_session_id !== $order_payment_session_id ) {
			
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[EARLY INTERCEPT] Clearing order_awaiting_payment - Order %d has different PS. Order: %s, Current: %s',
					$session_order_id,
					substr( $order_payment_session_id, 0, 20 ) . '...',
					substr( $current_payment_session_id, 0, 20 ) . '...'
				)
			);
			
			WC()->session->set( 'order_awaiting_payment', null );
			
			// Add note to old order
			$existing_order->add_order_note(
				__( 'Order not reused: A new payment session was started. New order created.', 'checkout-com-unified-payments-api' )
			);
			$existing_order->save();
		}
		
		return $value;
	}

	/**
	 * Clear order_awaiting_payment session BEFORE Store API processes checkout.
	 * 
	 * This hooks into rest_pre_dispatch which fires BEFORE the Store API endpoint
	 * processes the request. This is the earliest point we can intercept to clear
	 * the session before WooCommerce decides to reuse an order.
	 *
	 * @since 5.0.4
	 *
	 * @param mixed           $result  Response to replace the requested version with. Can be anything.
	 * @param \WP_REST_Server $server  Server instance.
	 * @param \WP_REST_Request $request Request used to generate the response.
	 * @return mixed Unchanged $result.
	 */
	public function clear_session_before_store_api_checkout( $result, $server, $request ) {
		// Only intercept Store API checkout endpoint
		$route = $request->get_route();
		
		// Debug: Log all Store API requests to see what's coming through
		if ( strpos( $route, '/wc/store' ) !== false ) {
			WC_Checkoutcom_Utility::logger( sprintf( '[REST PRE-DISPATCH] Route: %s, Method: %s', $route, $request->get_method() ) );
		}
		
		if ( strpos( $route, '/wc/store/v1/checkout' ) === false && strpos( $route, '/wc/store/checkout' ) === false ) {
			return $result;
		}
		
		// Only process POST requests (actual checkout submission)
		if ( $request->get_method() !== 'POST' ) {
			return $result;
		}
		
		// Check if using Flow payment method
		$request_data = $request->get_json_params();
		$payment_method = isset( $request_data['payment_method'] ) ? $request_data['payment_method'] : '';
		
		if ( 'wc_checkout_com_flow' !== $payment_method ) {
			return $result;
		}
		
		WC_Checkoutcom_Utility::logger( '[BLOCKS PRE-DISPATCH] Intercepting Store API checkout request for Flow payment' );
		
		// Get payment session ID from request
		$current_payment_session_id = '';
		
		// Check in payment_data array (how Blocks sends custom payment data)
		if ( isset( $request_data['payment_data'] ) && is_array( $request_data['payment_data'] ) ) {
			foreach ( $request_data['payment_data'] as $data ) {
				if ( isset( $data['key'] ) && $data['key'] === 'cko-flow-payment-session-id' ) {
					$current_payment_session_id = sanitize_text_field( $data['value'] );
					break;
				}
			}
		}
		
		// Also check extensions (alternative location)
		if ( empty( $current_payment_session_id ) && isset( $request_data['extensions']['checkout-com-flow']['payment_session_id'] ) ) {
			$current_payment_session_id = sanitize_text_field( $request_data['extensions']['checkout-com-flow']['payment_session_id'] );
		}
		
		WC_Checkoutcom_Utility::logger(
			sprintf( '[BLOCKS PRE-DISPATCH] Current payment session ID from request: %s',
				$current_payment_session_id ? substr( $current_payment_session_id, 0, 30 ) . '...' : '(none)'
			)
		);
		
		// Initialize WC session if needed (REST API may not have it initialized yet)
		if ( ! WC()->session ) {
			WC()->initialize_session();
		}
		
		if ( ! WC()->session ) {
			return $result;
		}
		
		$session_order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
		if ( ! $session_order_id ) {
			WC_Checkoutcom_Utility::logger( '[BLOCKS PRE-DISPATCH] No order_awaiting_payment in session - will create new order' );
			return $result;
		}
		
		$existing_order = wc_get_order( $session_order_id );
		if ( ! $existing_order ) {
			WC_Checkoutcom_Utility::logger( '[BLOCKS PRE-DISPATCH] Session order not found - will create new order' );
			return $result;
		}
		
		$order_payment_session_id = $existing_order->get_meta( '_cko_payment_session_id' );
		
		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[BLOCKS PRE-DISPATCH] Session Order %d - Order PS: %s, Current PS: %s',
				$session_order_id,
				$order_payment_session_id ? substr( $order_payment_session_id, 0, 30 ) . '...' : '(none)',
				$current_payment_session_id ? substr( $current_payment_session_id, 0, 30 ) . '...' : '(none)'
			)
		);
		
		// MULTI-TAB HANDLING: Log if order is being reused with different payment session
		// We don't try to prevent reuse here (doesn't work reliably in Blocks)
		// Instead, we track all payment attempts and let the first successful one win
		if ( ! empty( $order_payment_session_id ) ) {
			if ( empty( $current_payment_session_id ) || $current_payment_session_id !== $order_payment_session_id ) {
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[BLOCKS PRE-DISPATCH] ⚠️ MULTI-TAB DETECTED - Order %d already has payment session %s. Current request has different/no PS.',
						$session_order_id,
						substr( $order_payment_session_id, 0, 25 )
					)
				);
				// Note: We don't clear the session - WooCommerce may reuse the order regardless
				// The multi-tab handling in store_payment_session_id_in_order() and ajax_submit_payment_session()
				// will track all payment attempts, and the first successful one will update the order status
			} else {
				WC_Checkoutcom_Utility::logger( '[BLOCKS PRE-DISPATCH] Payment session matches - same tab continuing payment' );
			}
		} else {
			WC_Checkoutcom_Utility::logger( '[BLOCKS PRE-DISPATCH] Order has no payment session ID yet - first payment attempt' );
		}
		
		return $result;
	}

	/**
	 * Early session clearing on wp_loaded.
	 * 
	 * This runs very early on AJAX requests to check if a new payment session
	 * is being used with an existing order. If so, clear the session.
	 *
	 * @since 5.0.4
	 *
	 * @return void
	 */
	public function early_clear_order_session_for_new_payment() {
		// Only run on AJAX/REST requests related to checkout
		if ( ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		
		// Check if this is a Flow-related request
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just checking context
		$payment_method = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just checking context
		$action = isset( $_POST['action'] ) ? sanitize_text_field( wp_unslash( $_POST['action'] ) ) : '';
		
		// Only process Flow payment requests
		if ( 'wc_checkout_com_flow' !== $payment_method && strpos( $action, 'cko_flow' ) === false ) {
			return;
		}
		
		if ( ! WC()->session ) {
			return;
		}
		
		$session_order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
		if ( ! $session_order_id ) {
			return;
		}
		
		$existing_order = wc_get_order( $session_order_id );
		if ( ! $existing_order ) {
			return;
		}
		
		// Get current payment session ID from POST
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just reading value
		$current_payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) 
			? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) 
			: '';
		
		$order_payment_session_id = $existing_order->get_meta( '_cko_payment_session_id' );
		
		// If order has a DIFFERENT payment session ID, clear the session
		if ( ! empty( $current_payment_session_id ) 
			 && ! empty( $order_payment_session_id ) 
			 && $current_payment_session_id !== $order_payment_session_id ) {
			
			// MULTI-TAB HANDLING: Log the detection but don't try to prevent reuse
			// Session clearing doesn't work reliably, especially in Blocks checkout
			// The tracking in store_payment_session_id_in_order() will handle this
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[EARLY SESSION CHECK] ⚠️ MULTI-TAB DETECTED - Order %d has different PS. Order PS: %s, Current PS: %s. Tracking both attempts.',
					$session_order_id,
					substr( $order_payment_session_id, 0, 25 ),
					substr( $current_payment_session_id, 0, 25 )
				)
			);
		}
	}

	/**
	 * Get an existing order ID that may be reused for the current checkout.
	 *
	 * Follows WooCommerce pattern: checks order_awaiting_payment session key
	 * and payment_session_id meta as fallback.
	 *
	 * @since 5.0.3
	 *
	 * @param string $payment_session_id Optional payment session ID to search for.
	 * @return int|null Order ID if found, null otherwise.
	 */
	private function get_reusable_order_id( $payment_session_id = '' ) {
		$order_id = null;

		// Method 1: Check WooCommerce session (standard WooCommerce pattern).
		if ( WC()->session ) {
			$session_order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
			if ( $session_order_id > 0 ) {
				WC_Checkoutcom_Utility::logger(
					sprintf( '[ORDER REUSE CHECK] Found order_awaiting_payment in session: %d', $session_order_id )
				);
				
				// CRITICAL: If order already has a payment ID, it means a payment was attempted.
				// Don't return this order - let validate_order_reuse handle it properly.
				// NOTE: We do NOT clear session here to avoid "session expired" errors in WC Blocks.
				$order = wc_get_order( $session_order_id );
				if ( $order ) {
					$existing_payment_id = $order->get_meta( '_cko_payment_id' );
					if ( ! empty( $existing_payment_id ) ) {
						WC_Checkoutcom_Utility::logger(
							sprintf(
								'[ORDER REUSE CHECK] Order %d already has Payment ID (%s) - skipping, will be handled by validate_order_reuse',
								$session_order_id,
								substr( $existing_payment_id, 0, 25 )
							)
						);
						// Return the order ID - validate_order_reuse will reject it and create new order
						// This avoids the "session expired" error caused by clearing session here
						$order_id = $session_order_id;
					} else {
						$order_id = $session_order_id;
					}
				} else {
					$order_id = $session_order_id;
				}
			}
		}

		// Method 2: If payment session ID provided, search by meta.
		if ( ! $order_id && ! empty( $payment_session_id ) ) {
			$existing_orders = wc_get_orders(
				array(
					'meta_key'   => '_cko_payment_session_id',
					'meta_value' => $payment_session_id,
					'status'     => array( 'pending', 'failed', 'on-hold' ),
					'limit'      => 1,
					'return'     => 'ids',
					'orderby'    => 'date',
					'order'      => 'DESC',
				)
			);

			if ( ! empty( $existing_orders ) ) {
				$order_id = $existing_orders[0];
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[ORDER REUSE CHECK] Found order by payment_session_id (%s): %d',
						$payment_session_id,
						$order_id
					)
				);
			}
		}

		return $order_id;
	}

	/**
	 * Validate if an existing order can be reused for a new payment attempt.
	 *
	 * Order reuse rules:
	 * 1. Order-pay page: ALWAYS reuse (user is paying for specific order)
	 * 2. Failed orders: REUSE (allow retry on same order)
	 * 3. Regular checkout with pending order: CREATE NEW ORDER (each Pay click = new order)
	 *
	 * An order CANNOT be reused if:
	 * - It has _cko_security_check_failed flag (amount mismatch detected)
	 * - Its status is completed, cancelled, refunded, processing, or on-hold
	 * - The cart contents have changed (different cart hash) - for failed order retries
	 *
	 * @since 5.0.3
	 *
	 * @param WC_Order $order The order to validate.
	 * @return array {
	 *     @type bool   $can_reuse Whether the order can be reused.
	 *     @type string $reason    Explanation for the decision.
	 * }
	 */
	private function validate_order_reuse( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return array(
				'can_reuse' => false,
				'reason'    => 'Invalid order object',
			);
		}

		$order_id = $order->get_id();
		$status   = $order->get_status();

		// Detect if this is an order-pay page request.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just checking context, not processing data
		$is_order_pay_page = isset( $_POST['is_order_pay'] ) && 'yes' === sanitize_text_field( wp_unslash( $_POST['is_order_pay'] ) );
		
		// Also check URL pattern for order-pay pages
		if ( ! $is_order_pay_page ) {
			$referer = wp_get_referer();
			if ( $referer && strpos( $referer, '/order-pay/' ) !== false ) {
				$is_order_pay_page = true;
			}
		}

		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[ORDER REUSE CHECK] Evaluating Order %d - Status: %s, Is Order-Pay Page: %s',
				$order_id,
				$status,
				$is_order_pay_page ? 'YES' : 'NO'
			)
		);

		// Check 1: Security check failed flag.
		// If order failed security check (amount mismatch), it should NOT be reused.
		$security_check_failed = $order->get_meta( '_cko_security_check_failed' );
		if ( ! empty( $security_check_failed ) ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d has security check failed flag - Reason: %s',
					$order_id,
					$security_check_failed
				)
			);
			return array(
				'can_reuse' => false,
				'reason'    => 'Previous payment failed security check (amount mismatch)',
			);
		}

		// Check 1.5: CRITICAL - Order already has a Payment Session ID (payment flow started).
		// This is the key fix for multi-tab/rapid-click issues: 1 Order = 1 Payment Session.
		// Payment Session ID is saved IMMEDIATELY when order is created (before 3DS),
		// so this catches the case where Tab 1 is in 3DS and Tab 2 tries to pay.
		// Exception: Order-pay pages can reuse (user explicitly paying for that specific order).
		$existing_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just reading value for comparison
		$current_payment_session_id = isset( $_POST['cko-flow-payment-session-id'] ) ? sanitize_text_field( wp_unslash( $_POST['cko-flow-payment-session-id'] ) ) : '';
		
		if ( ! empty( $existing_payment_session_id ) && ! $is_order_pay_page ) {
			// If current request has a DIFFERENT payment session ID, reject reuse
			if ( ! empty( $current_payment_session_id ) && $existing_payment_session_id !== $current_payment_session_id ) {
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[ORDER REUSE CHECK] Order %d already has DIFFERENT Payment Session ID - cannot reuse. Existing: %s, Current: %s',
						$order_id,
						substr( $existing_payment_session_id, 0, 20 ),
						substr( $current_payment_session_id, 0, 20 )
					)
				);
				return array(
					'can_reuse' => false,
					'reason'    => 'Order already has a different payment session (another tab/attempt in progress)',
				);
			}
			// If current request has NO payment session ID but order has one, also reject
			// (this means a new payment flow is starting)
			if ( empty( $current_payment_session_id ) ) {
				WC_Checkoutcom_Utility::logger(
					sprintf(
						'[ORDER REUSE CHECK] Order %d already has Payment Session ID (%s) but current request has none - cannot reuse',
						$order_id,
						substr( $existing_payment_session_id, 0, 20 )
					)
				);
				return array(
					'can_reuse' => false,
					'reason'    => 'Order already has a payment session started',
				);
			}
		}
		
		// Also check Payment ID (for cases where 3DS already completed)
		$existing_payment_id = $order->get_meta( '_cko_payment_id' );
		if ( ! empty( $existing_payment_id ) && ! $is_order_pay_page ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d already has Payment ID (%s) - cannot reuse (1 order = 1 payment rule)',
					$order_id,
					substr( $existing_payment_id, 0, 25 )
				)
			);
			return array(
				'can_reuse' => false,
				'reason'    => 'Order already has a payment attempt (Payment ID exists)',
			);
		}

		// Check 2: Order status validation.
		// Orders that are already paid/processing/completed cannot be reused.
		$non_reusable_statuses = array( 'processing', 'completed', 'on-hold', 'cancelled', 'refunded' );
		if ( in_array( $status, $non_reusable_statuses, true ) ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d status "%s" cannot be reused (already paid or cancelled)',
					$order_id,
					$status
				)
			);
			return array(
				'can_reuse' => false,
				'reason'    => sprintf( 'Order status is "%s" - cannot accept new payment', $status ),
			);
		}

		// RULE: Order-pay page - ALWAYS reuse the specific order
		if ( $is_order_pay_page ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d - ORDER-PAY PAGE detected, will reuse order (status: %s)',
					$order_id,
					$status
				)
			);
			return array(
				'can_reuse' => true,
				'reason'    => 'Order-pay page - reusing specific order',
			);
		}

		// RULE: Failed orders - REUSE (allow retry on same order)
		if ( 'failed' === $status ) {
			// For failed orders, verify cart still matches before allowing reuse
			if ( WC()->cart ) {
				$current_cart_total = (float) WC()->cart->get_total( 'edit' );
				$order_total        = (float) $order->get_total();

				// Allow small floating point variance (1 cent).
				if ( abs( $current_cart_total - $order_total ) > 0.01 ) {
					WC_Checkoutcom_Utility::logger(
						sprintf(
							'[ORDER REUSE CHECK] Failed Order %d - cart total changed (Order: %s, Cart: %s) - creating new order',
							$order_id,
							$order_total,
							$current_cart_total
						)
					);
					return array(
						'can_reuse' => false,
						'reason'    => 'Cart total changed since failed order was created',
					);
				}
			}

			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d - FAILED status, allowing retry on same order',
					$order_id
				)
			);
			return array(
				'can_reuse' => true,
				'reason'    => 'Failed order - allowing retry',
			);
		}

		// RULE: Regular checkout with pending order - CREATE NEW ORDER
		// Each Pay click should create a new order for clean 1:1 payment session ↔ order mapping
		if ( 'pending' === $status ) {
			WC_Checkoutcom_Utility::logger(
				sprintf(
					'[ORDER REUSE CHECK] Order %d - PENDING status on regular checkout - creating NEW order (1:1 PS↔Order rule)',
					$order_id
				)
			);
			return array(
				'can_reuse' => false,
				'reason'    => 'Regular checkout - creating new order for each payment attempt',
			);
		}

		// Default: don't reuse
		WC_Checkoutcom_Utility::logger(
			sprintf(
				'[ORDER REUSE CHECK] Order %d - Unknown status "%s" - creating new order',
				$order_id,
				$status
			)
		);
		return array(
			'can_reuse' => false,
			'reason'    => sprintf( 'Order status "%s" not eligible for reuse', $status ),
		);
	}

	/**
	 * AJAX handler to save payment session ID to order immediately after payment session creation.
	 * This ensures order is linked to payment session even if user cancels after 3DS.
	 * 
	 * @return void
	 */
	public function ajax_save_payment_session_id() {
		// Verify nonce for security
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'cko_flow_payment_session' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Security check failed. Please refresh the page and try again.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// Get order ID and payment session ID from POST
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$payment_session_id = isset( $_POST['payment_session_id'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_session_id'] ) ) : '';
		
		// Validate required parameters
		if ( empty( $order_id ) || empty( $payment_session_id ) ) {
			wp_send_json_error( array(
				'message' => __( 'Missing required parameters.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// Get order object
		$order = wc_get_order( $order_id );
		
		if ( ! $order ) {
			wp_send_json_error( array(
				'message' => __( 'Order not found.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// SECURITY: Verify order ownership - order must belong to current user/session
		$current_user_id = get_current_user_id();
		$order_customer_id = $order->get_customer_id();
		
		// For logged-in users, verify order belongs to them
		if ( $current_user_id > 0 && $order_customer_id > 0 && $current_user_id !== $order_customer_id ) {
			WC_Checkoutcom_Utility::logger( '[SAVE PAYMENT SESSION ID] ❌ SECURITY: User ID mismatch - Current: ' . $current_user_id . ', Order Customer: ' . $order_customer_id );
			wp_send_json_error( array(
				'message' => __( 'You do not have permission to modify this order.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// For guest orders, verify order is pending and matches current checkout session
		if ( 0 === $current_user_id || 0 === $order_customer_id ) {
			// Only allow pending orders to be linked
			if ( ! in_array( $order->get_status(), array( 'pending', 'failed' ), true ) ) {
				WC_Checkoutcom_Utility::logger( '[SAVE PAYMENT SESSION ID] ❌ SECURITY: Guest order not in pending/failed status - Order ID: ' . $order_id . ', Status: ' . $order->get_status() );
				wp_send_json_error( array(
					'message' => __( 'Order is not in a valid state for payment processing.', 'checkout-com-unified-payments-api' ),
				) );
				return;
			}
			
			// Verify order key if provided (additional security for guest orders)
			$provided_order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';
			if ( ! empty( $provided_order_key ) && $provided_order_key !== $order->get_order_key() ) {
				WC_Checkoutcom_Utility::logger( '[SAVE PAYMENT SESSION ID] ❌ SECURITY: Order key mismatch - Order ID: ' . $order_id );
				wp_send_json_error( array(
					'message' => __( 'Invalid order key.', 'checkout-com-unified-payments-api' ),
				) );
				return;
			}
		}
		
		// CRITICAL: Check if payment session ID already saved (prevent overwriting)
		$existing_payment_session_id = $order->get_meta( '_cko_payment_session_id' );
		
		if ( ! empty( $existing_payment_session_id ) ) {
			if ( $existing_payment_session_id === $payment_session_id ) {
				// Already saved with same value, return success
				wp_send_json_success( array(
					'message' => __( 'Payment session ID already saved.', 'checkout-com-unified-payments-api' ),
					'order_id' => $order_id,
				) );
				return;
			} else {
				// Different payment session ID exists - prevent overwriting
				WC_Checkoutcom_Utility::logger( '[SAVE PAYMENT SESSION ID] ❌ CRITICAL ERROR: Payment session ID already exists with different value - Order ID: ' . $order_id . ', Existing: ' . substr( $existing_payment_session_id, 0, 20 ) . '..., New: ' . substr( $payment_session_id, 0, 20 ) . '... (preventing overwrite)' );
				wp_send_json_error( array(
					'message' => __( 'Payment session ID already exists with different value. Cannot overwrite.', 'checkout-com-unified-payments-api' ),
					'order_id' => $order_id,
				) );
				return;
			}
		}
		
		// Save payment session ID to order (order doesn't have it yet)
		$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
		$order->save();
		
		WC_Checkoutcom_Utility::logger( '[SAVE PAYMENT SESSION ID] Payment session ID saved to order immediately - Order ID: ' . $order_id . ', Payment Session ID: ' . $payment_session_id );
		
		// Return success
		wp_send_json_success( array(
			'message' => __( 'Payment session ID saved successfully.', 'checkout-com-unified-payments-api' ),
			'order_id' => $order_id,
		) );
	}

	/**
	 * AJAX handler to submit payment session with modified amount (dynamic amount adjustment).
	 * 
	 * This enables cart changes (coupon, shipping) without full Flow component reload.
	 * When cart total changes, instead of reloading the Flow component, we:
	 * 1. Store the new amount client-side
	 * 2. Call this endpoint with session_data from handleSubmit callback
	 * 3. This endpoint calls Checkout.com Submit Payment Session API with modified amount
	 * 4. Returns response to Flow for 3DS handling if needed
	 * 
	 * Works for card, Apple Pay, and Google Pay payments.
	 *
	 * @return void
	 */
	public function ajax_submit_payment_session() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		$nonce_valid = wp_verify_nonce( $nonce, 'cko_flow_payment_session' );
		
		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Nonce verification - Nonce: ' . substr( $nonce, 0, 10 ) . '..., Valid: ' . ( $nonce_valid ? 'YES (' . $nonce_valid . ')' : 'NO' ) . ', User ID: ' . get_current_user_id() );
		
		// Verify nonce for security
		// wp_verify_nonce returns 1 if valid and created 0-12 hours ago, 2 if valid and 12-24 hours ago, false if invalid
		if ( empty( $nonce ) || ! $nonce_valid ) {
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ❌ Nonce verification FAILED - Nonce: ' . ( $nonce ?: 'EMPTY' ) . ', Result: ' . var_export( $nonce_valid, true ) );
			wp_send_json_error( array(
				'message' => __( 'Security check failed. Please refresh the page and try again.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ✅ Nonce verification PASSED' );

		// Get parameters from POST
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- payment_session_id is alphanumeric ID from Checkout.com
		$payment_session_id = isset( $_POST['payment_session_id'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_session_id'] ) ) : '';
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- session_data is opaque token from Checkout.com SDK, must be passed as-is
		$session_data       = isset( $_POST['session_data'] ) ? wp_unslash( $_POST['session_data'] ) : '';
		$amount             = isset( $_POST['amount'] ) ? absint( $_POST['amount'] ) : 0;
		$order_id           = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$reference          = isset( $_POST['reference'] ) ? sanitize_text_field( wp_unslash( $_POST['reference'] ) ) : '';
		
		// Get billing/shipping address updates (JSON strings from JavaScript)
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- billing is JSON that will be decoded and sanitized
		$billing_json  = isset( $_POST['billing'] ) ? wp_unslash( $_POST['billing'] ) : '';
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- shipping is JSON that will be decoded and sanitized
		$shipping_json = isset( $_POST['shipping'] ) ? wp_unslash( $_POST['shipping'] ) : '';

		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Request received - Payment Session ID: ' . substr( $payment_session_id, 0, 20 ) . '..., Amount: ' . $amount . ', Order ID: ' . $order_id . ', Reference: ' . ( $reference ?: 'not provided' ) . ', Billing: ' . ( $billing_json ? 'provided' : 'not provided' ) . ', Shipping: ' . ( $shipping_json ? 'provided' : 'not provided' ) );

		// Validate required parameters
		if ( empty( $payment_session_id ) || empty( $session_data ) ) {
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ❌ Missing required parameters - payment_session_id: ' . ( $payment_session_id ? 'present' : 'missing' ) . ', session_data: ' . ( $session_data ? 'present' : 'missing' ) );
			wp_send_json_error( array(
				'message' => __( 'Missing required parameters.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}

		// Build the request body for Submit Payment Session API
		$request_body = array(
			'session_data' => $session_data,
		);

		// Subscription "Change payment method": the order being submitted is a WC_Subscription.
		// This SUBMIT step is where amount/reference/capture are finalised from the order — so the
		// zero-amount/detach forced at session-creation must be re-applied here too, otherwise the
		// order total (full recurring amount) is re-derived and CAPTURED, charging the customer for
		// a card change and re-attaching the payment to the subscription (which the webhooks then
		// flip to on-hold and fatal on capture). Force a zero-amount, capture:false, detached
		// verification instead.
		$is_sub_pay_change = false;
		if ( $order_id > 0 && function_exists( 'wcs_is_subscription' ) ) {
			$maybe_change_sub = wc_get_order( $order_id );
			if ( $maybe_change_sub && wcs_is_subscription( $maybe_change_sub ) ) {
				$is_sub_pay_change = true;
			}
		}

		// Add Payment Method (My Account → add-payment-method): also a $0 card verification, flagged
		// by the client since there is no order to resolve from. Same enforcement as change-payment.
		$is_add_pm = ! empty( $_POST['is_add_payment_method'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['is_add_payment_method'] ) ) && is_user_logged_in();

		// CRITICAL: Always get the correct amount from WooCommerce order or cart
		// This ensures coupons/discounts are properly applied even if client-side tracking fails
		$final_amount = $amount; // Start with client-provided amount

		if ( $is_sub_pay_change || $is_add_pm ) {
			// Zero-amount card verification — never charge for a card change / add-card.
			$final_amount           = 0;
			$request_body['amount']  = 0;
			$reference               = $is_add_pm ? ( 'cko-add-payment-method-' . get_current_user_id() ) : ( 'cko-card-change-' . $order_id ); // non-numeric → webhooks can't resolve an order
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ' . ( $is_add_pm ? 'Add-payment-method' : 'Subscription change-payment-method' ) . ' mode — forcing amount=0, capture off, reference detached.' );
		} else {
			// If order_id is provided, get amount from order (most reliable - includes coupons, taxes, etc.)
			if ( $order_id > 0 ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$order_currency = $order->get_currency();
					$order_total_decimal = (float) $order->get_total();
					$order_amount_minor = (int) WC_Checkoutcom_Utility::value_to_decimal( $order_total_decimal, $order_currency );

					WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Order amount check - Order ID: ' . $order_id . ', Order total: ' . $order_total_decimal . ' ' . $order_currency . ', Minor units: ' . $order_amount_minor . ', Client amount: ' . $amount );

					// Use order amount (always has correct discounted total)
					$final_amount = $order_amount_minor;
				}
			} elseif ( WC()->cart && ! WC()->cart->is_empty() ) {
				// Fallback to cart if no order (shouldn't happen in normal flow)
				$cart_total = WC()->cart->get_total( 'edit' );
				$cart_currency = get_woocommerce_currency();
				$cart_amount_minor = (int) WC_Checkoutcom_Utility::value_to_decimal( (float) $cart_total, $cart_currency );

				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Cart amount check - Cart total: ' . $cart_total . ' ' . $cart_currency . ', Minor units: ' . $cart_amount_minor . ', Client amount: ' . $amount );

				$final_amount = $cart_amount_minor;
			}

			// Add amount to request (always include to ensure correct discounted amount)
			if ( $final_amount > 0 ) {
				$request_body['amount'] = $final_amount;
				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Including amount in request: ' . $final_amount );
			}
		}
		
		// Add reference if provided (WooCommerce order ID for tracking in Checkout.com dashboard)
		if ( ! empty( $reference ) ) {
			$request_body['reference'] = $reference;
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Including reference: ' . $reference );
		}
		
		// Add reference if provided (WooCommerce order ID for tracking in Checkout.com dashboard)
		if ( ! empty( $reference ) ) {
			$request_body['reference'] = $reference;
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Including reference: ' . $reference );
		}
		
		// Add billing address if provided (dynamic address adjustment).
		// Only include it when the country is a valid 2-letter ISO code — sending an empty/invalid
		// country triggers Checkout.com's billing_address_country_invalid (common on the add-payment-
		// method page where the customer may have no saved country).
		if ( ! empty( $billing_json ) ) {
			$billing_data = json_decode( $billing_json, true );
			$billing_country_valid = is_array( $billing_data ) && isset( $billing_data['country'] ) && preg_match( '/^[A-Za-z]{2}$/', (string) $billing_data['country'] );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $billing_data ) && $billing_country_valid ) {
				$request_body['billing'] = array(
					'address' => array(
						'address_line1' => isset( $billing_data['address_line1'] ) ? sanitize_text_field( $billing_data['address_line1'] ) : '',
						'address_line2' => isset( $billing_data['address_line2'] ) ? sanitize_text_field( $billing_data['address_line2'] ) : '',
						'city'          => isset( $billing_data['city'] ) ? sanitize_text_field( $billing_data['city'] ) : '',
						'state'         => isset( $billing_data['state'] ) ? sanitize_text_field( $billing_data['state'] ) : '',
						'zip'           => isset( $billing_data['zip'] ) ? sanitize_text_field( $billing_data['zip'] ) : '',
						'country'       => isset( $billing_data['country'] ) ? sanitize_text_field( $billing_data['country'] ) : '',
					),
				);
				// Add phone if provided (Checkout.com expects phone as separate object under billing)
				if ( ! empty( $billing_data['phone'] ) ) {
					$request_body['billing']['phone'] = array(
						'number' => sanitize_text_field( $billing_data['phone'] ),
					);
				}
				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Including modified billing address in request: ' . wp_json_encode( $request_body['billing'] ) );
			}
		}
		
		// Add shipping address if provided (dynamic address adjustment).
		// Only include it when the country is a valid 2-letter ISO code (see billing note above).
		if ( ! empty( $shipping_json ) ) {
			$shipping_data = json_decode( $shipping_json, true );
			$shipping_country_valid = is_array( $shipping_data ) && isset( $shipping_data['country'] ) && preg_match( '/^[A-Za-z]{2}$/', (string) $shipping_data['country'] );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $shipping_data ) && $shipping_country_valid ) {
				$request_body['shipping'] = array(
					'address' => array(
						'address_line1' => isset( $shipping_data['address_line1'] ) ? sanitize_text_field( $shipping_data['address_line1'] ) : '',
						'address_line2' => isset( $shipping_data['address_line2'] ) ? sanitize_text_field( $shipping_data['address_line2'] ) : '',
						'city'          => isset( $shipping_data['city'] ) ? sanitize_text_field( $shipping_data['city'] ) : '',
						'state'         => isset( $shipping_data['state'] ) ? sanitize_text_field( $shipping_data['state'] ) : '',
						'zip'           => isset( $shipping_data['zip'] ) ? sanitize_text_field( $shipping_data['zip'] ) : '',
						'country'       => isset( $shipping_data['country'] ) ? sanitize_text_field( $shipping_data['country'] ) : '',
					),
				);
				// Add phone if provided
				if ( ! empty( $shipping_data['phone'] ) ) {
					$request_body['shipping']['phone'] = array(
						'number' => sanitize_text_field( $shipping_data['phone'] ),
					);
				}
				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Including modified shipping address in request: ' . wp_json_encode( $request_body['shipping'] ) );
			}
		}

		// Enable 3DS
		$request_body['3ds'] = array(
			'enabled' => true,
		);

		// If order exists, update success/failure URLs to include order_id
		if ( $order_id > 0 ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$order_key   = $order->get_order_key();
				$success_url = add_query_arg(
					array(
						'wc-api'   => 'wc_checkoutcom_flow_process',
						'order_id' => $order_id,
						'key'      => $order_key,
					),
					home_url( '/' )
				);
				$failure_url = $success_url;

				$request_body['success_url'] = $success_url;
				$request_body['failure_url'] = $failure_url;

				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Updated URLs with order_id: ' . $order_id );
			}
		}

		// Get Checkout.com API credentials
		$core_settings  = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$environment    = ! empty( $core_settings['ckocom_environment'] ) ? $core_settings['ckocom_environment'] : 'sandbox';

		// Get secret key - single key is used for both environments (determined by the key itself)
		$secret_key_raw = ! empty( $core_settings['ckocom_sk'] ) ? $core_settings['ckocom_sk'] : '';
		
		if ( empty( $secret_key_raw ) ) {
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ❌ Secret key not configured' );
			wp_send_json_error( array(
				'message' => __( 'Payment gateway not properly configured.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// Add Bearer prefix for NAS accounts
		$secret_key = cko_is_nas_account() ? 'Bearer ' . $secret_key_raw : $secret_key_raw;

		// CRITICAL: Calculate capture_on at SUBMIT time (not at session creation time)
		// This ensures the capture delay is calculated from actual payment submission,
		// not from when the customer landed on the checkout page.
		// Previously, capture_on was calculated client-side at session creation, which caused
		// issues when customers took longer than expected to complete checkout/3DS - the
		// capture_on timestamp would be in the past, leading to immediate capture and webhook race conditions.
		$auto_capture = '1' === WC_Admin_Settings::get_option( 'ckocom_card_autocap', '1' );

		// Never capture a card-change / add-card verification — it must stay a $0 auth only.
		if ( $is_sub_pay_change || $is_add_pm ) {
			$auto_capture = false;
		}

		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Auto-capture setting: ' . ( $auto_capture ? 'ENABLED' : 'DISABLED' ) );
		
		if ( $auto_capture ) {
			$capture_on = WC_Checkoutcom_Utility::get_delayed_capture_timestamp();
			if ( $capture_on ) {
				// Format as ISO 8601 string for Checkout.com API
				$request_body['capture_on'] = $capture_on->format( 'c' );
				WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] capture_on set to: ' . $request_body['capture_on'] . ' (calculated at submit time)' );
			}
		} else {
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Auto-capture disabled - no capture_on set (authorize only)' );
		}

		// Build API URL
		$api_base_url = 'sandbox' === $environment
			? 'https://api.sandbox.checkout.com'
			: 'https://api.checkout.com';
		$api_url      = $api_base_url . '/payment-sessions/' . $payment_session_id . '/submit';

		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Calling Checkout.com API - URL: ' . $api_url );
		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Request body: ' . wp_json_encode( WC_Checkoutcom_Utility::redact_for_log( $request_body ) ) );

		// Make API request
		$response = wp_remote_post(
			$api_url,
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => $secret_key, // Already includes 'Bearer ' prefix for NAS accounts
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $request_body ),
			)
		);

		// Check for WP error
		if ( is_wp_error( $response ) ) {
			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ❌ WP Error: ' . $response->get_error_message() );
			wp_send_json_error( array(
				'message' => __( 'Failed to connect to payment gateway.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}

		// Parse response
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] API Response - Code: ' . $response_code . ', Body: ' . $response_body );

		// Check for API error
		if ( $response_code >= 400 ) {
			$error_codes   = isset( $response_data['error_codes'] ) && is_array( $response_data['error_codes'] )
				? array_map( 'sanitize_text_field', $response_data['error_codes'] )
				: array();
			$error_message = isset( $response_data['error_type'] )
				? sanitize_text_field( $response_data['error_type'] ) . ': ' . implode( ', ', $error_codes )
				: __( 'Payment submission failed.', 'checkout-com-unified-payments-api' );

			WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ❌ API Error: ' . $error_message );
			wp_send_json_error( array(
				'message' => esc_html( $error_message ),
				'data'    => $response_data,
			) );
			return;
		}

		// Success - return the response for Flow to handle
		WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] ✅ Payment submitted successfully - Payment ID: ' . ( $response_data['id'] ?? 'N/A' ) . ', Status: ' . ( $response_data['status'] ?? 'N/A' ) );

		// Save payment ID and payment session ID to order if available
		// MULTI-TAB SUPPORT: Track ALL payment attempts, let first successful one win
		if ( $order_id > 0 && ! empty( $response_data['id'] ) ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$payment_id = $response_data['id'];
				$existing_session_id = $order->get_meta( '_cko_payment_session_id' );
				$existing_payment_id = $order->get_meta( '_cko_payment_id' );
				$is_primary_session = empty( $existing_session_id ) || $existing_session_id === $payment_session_id;
				
				// Get existing payment attempts array
				$payment_attempts = $order->get_meta( '_cko_payment_attempts' );
				if ( empty( $payment_attempts ) || ! is_array( $payment_attempts ) ) {
					$payment_attempts = array();
				}
				
				// Find and update the attempt for this payment session, or add new one
				$attempt_found = false;
				foreach ( $payment_attempts as $index => $attempt ) {
					if ( isset( $attempt['session_id'] ) && $attempt['session_id'] === $payment_session_id ) {
						$payment_attempts[ $index ]['payment_id'] = $payment_id;
						$payment_attempts[ $index ]['status'] = 'submitted';
						$payment_attempts[ $index ]['submitted_at'] = current_time( 'mysql' );
						$attempt_found = true;
						break;
					}
				}
				
				// If not found, add new attempt entry
				if ( ! $attempt_found ) {
					$payment_attempts[] = array(
						'session_id'   => $payment_session_id,
						'payment_id'   => $payment_id,
						'timestamp'    => current_time( 'mysql' ),
						'submitted_at' => current_time( 'mysql' ),
						'is_primary'   => $is_primary_session,
						'status'       => 'submitted',
					);
				}
				
				// Save the updated attempts array
				$order->update_meta_data( '_cko_payment_attempts', $payment_attempts );
				
				// Check if this is a multi-tab scenario
				if ( ! empty( $existing_session_id ) && $existing_session_id !== $payment_session_id ) {
					// MULTI-TAB: This is an additional payment attempt
					WC_Checkoutcom_Utility::logger( 
						sprintf(
							'[SUBMIT PAYMENT SESSION] ⚠️ MULTI-TAB DETECTED - Order %d: Primary PS: %s, This PS: %s, This Payment ID: %s',
							$order_id,
							substr( $existing_session_id, 0, 25 ),
							substr( $payment_session_id, 0, 25 ),
							substr( $payment_id, 0, 25 )
						)
					);
					
					// Add note about the additional payment attempt
					$order->add_order_note(
						sprintf(
							__( 'Additional payment submitted (multi-tab). Session: %s, Payment ID: %s. Waiting for 3DS completion.', 'checkout-com-unified-payments-api' ),
							$payment_session_id,
							$payment_id
						)
					);
				} else {
					// Normal case: This is the primary payment session
					// Save as primary payment ID and session ID
					$order->update_meta_data( '_cko_payment_id', $payment_id );
					$order->update_meta_data( '_cko_flow_payment_id', $payment_id );
					if ( empty( $existing_session_id ) ) {
						$order->update_meta_data( '_cko_payment_session_id', $payment_session_id );
					}
					WC_Checkoutcom_Utility::logger( '[SUBMIT PAYMENT SESSION] Primary payment ID saved to order: ' . $order_id );
				}
				
				$order->save();
				WC_Checkoutcom_Utility::logger( 
					sprintf( 
						'[SUBMIT PAYMENT SESSION] Payment attempts tracked for order %d. Total attempts: %d', 
						$order_id, 
						count( $payment_attempts ) 
					) 
				);
			}
		}

		wp_send_json_success( $response_data );
	}
	
	/**
	 * AJAX handler to create a failed order when payment is declined before form submission.
	 * This ensures all payment decline attempts are tracked in WooCommerce.
	 *
	 * @return void
	 */
	public function ajax_create_failed_order() {
		// Log entry point
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ========== ENTRY POINT ==========' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just logging keys, nonce verified below
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] POST data keys: ' . implode( ', ', array_map( 'sanitize_key', array_keys( $_POST ) ) ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Just logging keys, nonce verified below
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] REQUEST data keys: ' . implode( ', ', array_map( 'sanitize_key', array_keys( $_REQUEST ) ) ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Just logging, nonce verified below
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Action: ' . ( isset( $_POST['action'] ) ? sanitize_text_field( wp_unslash( $_POST['action'] ) ) : 'NOT SET' ) );
		
		// Verify nonce for security - check multiple possible locations
		$nonce_value = '';
		if ( isset( $_POST['woocommerce-process-checkout-nonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_POST['woocommerce-process-checkout-nonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce from POST: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		} elseif ( isset( $_REQUEST['woocommerce-process-checkout-nonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_REQUEST['woocommerce-process-checkout-nonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce from REQUEST: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		} elseif ( isset( $_REQUEST['_wpnonce'] ) ) {
			$nonce_value = sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce from _wpnonce: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
		}
		
		if ( empty( $nonce_value ) || ! wp_verify_nonce( $nonce_value, 'woocommerce-process_checkout' ) ) {
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: Invalid or missing nonce' );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce value received: ' . ( ! empty( $nonce_value ) ? substr( $nonce_value, 0, 10 ) . '...' : 'EMPTY' ) );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce verification result: ' . ( ! empty( $nonce_value ) ? ( wp_verify_nonce( $nonce_value, 'woocommerce-process_checkout' ) ? 'VALID' : 'INVALID' ) : 'MISSING' ) );
			wp_send_json_error( array(
				'message' => __( 'Session expired. Please refresh.', 'woocommerce' ),
			) );
			return;
		}
		
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Nonce validated successfully' );
		
		// Get error reason and message
		$error_reason = isset( $_POST['error_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['error_reason'] ) ) : 'payment_declined';
		$error_message = isset( $_POST['error_message'] ) ? sanitize_text_field( wp_unslash( $_POST['error_message'] ) ) : __( 'Payment was declined.', 'checkout-com-unified-payments-api' );
		
		WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Error reason: ' . $error_reason . ', Error message: ' . $error_message );
		
		// Load WooCommerce checkout class
		if ( ! function_exists( 'WC' ) || ! WC() ) {
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: WooCommerce not available' );
			wp_send_json_error( array( 'message' => __( 'WooCommerce not available.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}
		
		$checkout = WC()->checkout();
		if ( ! $checkout ) {
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: Checkout class not available' );
			wp_send_json_error( array( 'message' => __( 'Checkout class not available.', 'checkout-com-unified-payments-api' ) ) );
			return;
		}
		
		try {
			// Get posted data from form
			$posted_data = $checkout->get_posted_data();
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Posted data retrieved' );
			
			// Create order using public WooCommerce APIs (no Reflection).
			$customer_id = get_current_user_id();
			$order = wc_create_order( array( 'customer_id' => $customer_id ) );

			if ( is_wp_error( $order ) ) {
				WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: Failed to create order: ' . $order->get_error_message() );
				wp_send_json_error( array(
					'message' => __( 'Failed to create order. Please try again.', 'checkout-com-unified-payments-api' ),
					'error' => $order->get_error_message(),
				) );
				return;
			}

			$order_id = $order->get_id();
			if ( empty( $order_id ) ) {
				WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: Invalid order ID returned.' );
				wp_send_json_error( array(
					'message' => __( 'Failed to create order. Invalid order ID returned.', 'checkout-com-unified-payments-api' ),
				) );
				return;
			}

			// Map billing/shipping data from checkout form if available.
			$billing_fields = array(
				'first_name' => 'billing_first_name',
				'last_name'  => 'billing_last_name',
				'company'    => 'billing_company',
				'email'      => 'billing_email',
				'phone'      => 'billing_phone',
				'address_1'  => 'billing_address_1',
				'address_2'  => 'billing_address_2',
				'city'       => 'billing_city',
				'state'      => 'billing_state',
				'postcode'   => 'billing_postcode',
				'country'    => 'billing_country',
			);
			$billing = array();
			foreach ( $billing_fields as $key => $post_key ) {
				if ( isset( $posted_data[ $post_key ] ) ) {
					$billing[ $key ] = $posted_data[ $post_key ];
				}
			}
			if ( ! empty( $billing ) ) {
				$order->set_address( $billing, 'billing' );
			}

			$shipping_fields = array(
				'first_name' => 'shipping_first_name',
				'last_name'  => 'shipping_last_name',
				'company'    => 'shipping_company',
				'address_1'  => 'shipping_address_1',
				'address_2'  => 'shipping_address_2',
				'city'       => 'shipping_city',
				'state'      => 'shipping_state',
				'postcode'   => 'shipping_postcode',
				'country'    => 'shipping_country',
			);
			$shipping = array();
			foreach ( $shipping_fields as $key => $post_key ) {
				if ( isset( $posted_data[ $post_key ] ) ) {
					$shipping[ $key ] = $posted_data[ $post_key ];
				}
			}
			if ( ! empty( $shipping ) ) {
				$order->set_address( $shipping, 'shipping' );
			}

			// Add cart items to the failed order for tracking.
			if ( WC()->cart ) {
				foreach ( WC()->cart->get_cart() as $cart_item ) {
					if ( empty( $cart_item['data'] ) ) {
						continue;
					}
					$product = $cart_item['data'];
					$item = new WC_Order_Item_Product();
					$item->set_product( $product );
					$item->set_quantity( isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1 );
					if ( isset( $cart_item['line_subtotal'] ) ) {
						$item->set_subtotal( (float) $cart_item['line_subtotal'] );
					}
					if ( isset( $cart_item['line_total'] ) ) {
						$item->set_total( (float) $cart_item['line_total'] );
					}
					$order->add_item( $item );
				}
				$order->calculate_totals();
			}

			// Mark payment method as Flow.
			$order->set_payment_method( $this );
			$order->set_payment_method_title( $this->get_title() );

			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Order created successfully - Order ID: ' . $order_id );
			
			// Update order status to failed
			$order->update_status( 'failed', __( 'Payment declined before form submission', 'checkout-com-unified-payments-api' ) );
			
			// Add a static order note — client-supplied reason/message are logged server-side only.
			$order->add_order_note( __( 'Payment declined before form submission.', 'checkout-com-unified-payments-api' ) );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Decline details — reason: ' . $error_reason . ', message: ' . $error_message );
			
			// Save order
			$order->save();
			
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] Order updated to failed status - Order ID: ' . $order_id );
			
			// Return success with order ID
			wp_send_json_success( array(
				'order_id' => $order_id,
				'message' => __( 'Failed order created successfully.', 'checkout-com-unified-payments-api' ),
			) );
			
		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR: Exception: ' . $e->getMessage() );
			WC_Checkoutcom_Utility::logger( '[CREATE FAILED ORDER] ERROR stack trace: ' . $e->getTraceAsString() );
			wp_send_json_error( array(
				'message' => __( 'An error occurred. Please refresh and try again.', 'checkout-com-unified-payments-api' ),
			) );
		}
	}

	/**
	 * AJAX handler for storing save card preference in WooCommerce session
	 * This ensures the value survives 3DS redirects
	 */
	public function ajax_store_save_card_preference() {
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] AJAX handler called - POST keys: ' . implode( ', ', array_keys( $_POST ) ) );
		
		// Verify nonce for security
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Nonce received: ' . ( ! empty( $nonce ) ? substr( $nonce, 0, 10 ) . '...' : 'EMPTY' ) );
		
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cko_flow_payment_session' ) ) {
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] ERROR: Nonce verification failed' );
			wp_send_json_error( array(
				'message' => __( 'Security check failed.', 'checkout-com-unified-payments-api' ),
			) );
			return;
		}
		
		// Get save card preference value
		$save_card_value = isset( $_POST['save_card_value'] ) ? sanitize_text_field( wp_unslash( $_POST['save_card_value'] ) ) : 'no';
		WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Save card value received: ' . $save_card_value );
		
		// Initialize WooCommerce session if not already initialized
		if ( ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}
		
		// Store in WooCommerce session
		if ( WC()->session ) {
			WC()->session->set( 'wc-wc_checkout_com_flow-new-payment-method', $save_card_value );
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] Stored save card preference in WooCommerce session: ' . $save_card_value );
			wp_send_json_success( array(
				'message' => __( 'Save card preference stored.', 'checkout-com-unified-payments-api' ),
				'value' => $save_card_value,
			) );
		} else {
			WC_Checkoutcom_Utility::logger( '[FLOW SAVE CARD] ERROR: WooCommerce session not available' );
			wp_send_json_error( array(
				'message' => __( 'Session not available.', 'checkout-com-unified-payments-api' ),
			) );
		}
	}
}

