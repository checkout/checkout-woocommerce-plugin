<?php
/**
 * Utility class.
 *
 * @package wc_checkout_com
 */

/**
 * Class WC_Checkoutcom_Utility
 */
class WC_Checkoutcom_Utility {

	/**
	 * Verify cko signature for webhooks.
	 *
	 * @param string $event Data.
	 * @param string $key Secret key.
	 * @param string $cko_signature Header signature.
	 *
	 * @return bool
	 */
	public static function verify_signature( $event, $key, $cko_signature ) {
		return hash_hmac( 'sha256', $event, $key ) === $cko_signature;
	}

	/**
	 * Format amount in cents.
	 *
	 * @param integer $amount Amount in cents.
	 * @param string  $currency_symbol Currency symbol.
	 *
	 * @return float|int
	 */
	public static function value_to_decimal( $amount, $currency_symbol ) {
		$currency                    = strtoupper( $currency_symbol );
		// Three-decimal currencies: amount divided by 1000
		// Reference: https://www.checkout.com/docs/payments/accept-payments/format-the-amount-value
		$three_decimal_currency_list = [ 'BHD', 'LYD', 'JOD', 'IQD', 'KWD', 'OMR', 'TND' ];
		// Zero-decimal currencies: amount is the full amount (no division)
		// Reference: https://www.checkout.com/docs/payments/accept-payments/format-the-amount-value
		$zero_decimal_currency_list  = [
			'BIF', // Burundian Franc
			'DJF', // Djiboutian Franc
			'GNF', // Guinean Franc
			'ISK', // Icelandic Krona
			'JPY', // Japanese Yen
			'KMF', // Comoran Franc
			'KRW', // South Korean Won
			'PYG', // Paraguayan Guarani
			'RWF', // Rwandan Franc
			'UGX', // Ugandan Shilling
			'VUV', // Vanuatu Vatu
			'VND', // Vietnamese Dong
			'XAF', // Central African Franc
			'XOF', // West African CFA franc
			'XPF', // Comptoirs Français du Pacifique
		];

		if ( in_array( $currency, $three_decimal_currency_list, true ) ) {
			$value = (int) ( $amount * 1000 );
		} elseif ( in_array( $currency, $zero_decimal_currency_list, true ) ) {
			$value = floor( $amount );
		} else {
			$value = round( $amount * 100 );
		}

		return $value;
	}

	/**
	 * Format amount in decimal.
	 *
	 * @param integer $amount Amount in cents.
	 * @param string  $currency_symbol Currency symbol.
	 *
	 * @return float|int
	 */
	public static function decimal_to_value( $amount, $currency_symbol ) {
		$currency                    = strtoupper( $currency_symbol );
		// Three-decimal currencies: amount divided by 1000
		// Reference: https://www.checkout.com/docs/payments/accept-payments/format-the-amount-value
		$three_decimal_currency_list = [ 'BHD', 'LYD', 'JOD', 'IQD', 'KWD', 'OMR', 'TND' ];
		// Zero-decimal currencies: amount is the full amount (no division)
		// Reference: https://www.checkout.com/docs/payments/accept-payments/format-the-amount-value
		$zero_decimal_currency_list  = [
			'BIF', // Burundian Franc
			'DJF', // Djiboutian Franc
			'GNF', // Guinean Franc
			'ISK', // Icelandic Krona
			'JPY', // Japanese Yen
			'KMF', // Comoran Franc
			'KRW', // South Korean Won
			'PYG', // Paraguayan Guarani
			'RWF', // Rwandan Franc
			'UGX', // Ugandan Shilling
			'VUV', // Vanuatu Vatu
			'VND', // Vietnamese Dong
			'XAF', // Central African Franc
			'XOF', // West African CFA franc
			'XPF', // Comptoirs Français du Pacifique
		];

		if ( in_array( $currency, $three_decimal_currency_list, true ) ) {
			$value = $amount / 1000;
		} elseif ( in_array( $currency, $zero_decimal_currency_list, true ) ) {
			$value = $amount;
		} else {
			$value = $amount / 100;
		}

		return $value;
	}

	/**
	 * Add a delay to the current URC time
	 *
	 * @return DateTime ISO 8601 timestamp of UTC current time plus delays
	 *
	 * @throws Exception If the date cannot be parsed.
	 */
	public static function get_delayed_capture_timestamp() {
		// Specify a 10 seconds delay even if the autocapture time is set to 0 to avoid webhook issues.
		$default_seconds_delay = 10;
		$delay                 = preg_replace( '/\s/', '', WC_Admin_Settings::get_option( 'ckocom_card_cap_delay' ) );
		// If the input of the delay is numeric.
		if ( is_numeric( $delay ) ) {
			// Get total seconds based on the hour input.
			$total_seconds = round( $delay * 3600 );
			// If the delay is 0 manually add a 10 seconds delay.
			if ( 0 === $total_seconds ) {
				$total_seconds += $default_seconds_delay;
			}
			$hours   = floor( $total_seconds / 3600 );
			$minutes = floor( floor( $total_seconds / 60 ) % 60 );
			$seconds = floor( $total_seconds % 60 );

			// Return date and time in UTC with the delays added.
			return new DateTime( '+' . $hours . ' hours +' . $minutes . ' minutes +' . $seconds . 'seconds' );
		}

		// If the delay is in an invalid format (non-numeric) default to base delay (default_seconds_delay).
		return new DateTime( '+' . $default_seconds_delay . 'seconds' );
	}

	/**
	 * Check is MADA card.
	 *
	 * @param string $bin The card bin.
	 *
	 * @return bool
	 */
	public static function is_mada_card( $bin ) {
		// Path to MADA_BIN.csv.
		$csv_path = WC_CHECKOUTCOM_PLUGIN_PATH . '/includes/Files/Mada/MADA_BINS.csv';

		$array_from_csv = array_map( 'str_getcsv', file( $csv_path ) );

		// Remove the first row of csv columns.
		unset( $array_from_csv[0] );

		// Build the MADA BIN array.
		$bin_array = [];
		foreach ( $array_from_csv as $row ) {
			$bin_array[] = $row[0];
		}

		return in_array( strval( $bin ), $bin_array, true );
	}

	/**
	 * Add notice.
	 *
	 * @param string $message Message to display.
	 * @param string $status Status.
	 */
	public static function wc_add_notice_self( $message, $status = 'error' ) {
		if ( function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( $message, $status );
		} else {
			global $woocommerce;

			switch ( $status ) {
				case 'error':
					$woocommerce->add_error( $message );
					break;
				case 'notice':
					$woocommerce->add_message( $message );
					break;
				default:
					$woocommerce->add_error( $message );
					break;
			}
		}
	}

	/**
	 * Log data to file using WC logger.
	 *
	 * @param string|array $error_message Error message to log.
	 * @param Exception     $exception Exception object.
	 */
	public static function logger( $error_message, $exception = null ) {
		$logger  = wc_get_logger();
		$context = [ 'source' => 'wc_checkoutcom_gateway_log' ];

		// Convert array to string if needed
		if ( is_array( $error_message ) || is_object( $error_message ) ) {
			$error_message = wc_print_r( $error_message, true );
		}

		// Ensure error_message is a string
		if ( ! is_string( $error_message ) ) {
			$error_message = (string) $error_message;
		}

		// Get file logging from module setting.
		$file_logging = 'yes' === WC_Admin_Settings::get_option( 'cko_file_logging', 'no' );

		// Determine log level from message prefix
		$log_level = 'error'; // Default to error for backward compatibility
		
		// Check for debug/info prefixes (case-insensitive)
		if ( preg_match( '/\[FLOW\s+DEBUG\]|\[DEBUG\]|\[ADDRESS\s+DEBUG\]/i', $error_message ) ) {
			$log_level = 'debug';
		} elseif ( preg_match( '/\[FLOW\s+INFO\]|\[INFO\]/i', $error_message ) ) {
			$log_level = 'info';
		} elseif ( preg_match( '/\[FLOW\s+WARNING\]|\[WARNING\]|\[WARN\]/i', $error_message ) ) {
			$log_level = 'warning';
		} elseif ( preg_match( '/\[FLOW\s+ERROR\]|\[ERROR\]/i', $error_message ) ) {
			$log_level = 'error';
		} elseif ( preg_match( '/\[FLOW\s+SERVER\]|\[VALIDATE\s+CHECKOUT\]|\[PROCESS\s+PAYMENT\]|\[CREATE\s+ORDER\]|\[FLOW\s+VALID\s+FOR\s+USE\]|\[FLOW\s+AVAILABILITY\]|\[FLOW\s+SAVE\s+CARD\]/i', $error_message ) ) {
			// Server-side informational logs - use info level
			$log_level = 'info';
		}

		// Check if file logging is enabled.
		if ( $file_logging ) {
			// Log message with appropriate level
			$logger->log( $log_level, $error_message, $context );
			if ( null !== $exception ) {
				// If exception is an array, print it properly
				if ( is_array( $exception ) ) {
					$logger->log( $log_level, $error_message . ' Data: ' . wc_print_r( $exception, true ), $context );
				} else {
					$logger->log( $log_level, wc_print_r( $exception, true ), $context );
				}
			}
		} else {
			// Log only message (still respect log level)
			$logger->log( $log_level, $error_message, $context );
		}
	}

	/**
	 * Returns available alternative payment methods APMs.
	 *
	 * @return array
	 */
	public static function get_alternative_payment_methods() {
		$currency_code = get_woocommerce_currency();
		$apm_setting   = get_option( 'woocommerce_wc_checkout_com_alternative_payments_settings' );
		$apm           = ! empty( $apm_setting['ckocom_apms_selector'] ) ? $apm_setting['ckocom_apms_selector'] : [];
		$country_code  = WC()->customer->get_billing_country();

		$abc_apms = [ 'alipay', 'bancontact', 'boleto', 'eps', 'fawry', 'ideal', 'knet', 'multibanco', 'poli', 'qpay', 'sepa', 'sofort' ];
		$nas_apms = [ 'ideal', 'bancontact', 'eps', 'fawry', 'klarna', 'knet', 'multibanco', 'qpay', 'sort' ];

		if ( cko_is_nas_account() ) {
			$apm = array_intersect( $apm, $nas_apms );
		} else {
			$apm = array_intersect( $apm, $abc_apms );
		}

		$apm_array = [];
		if ( 0 !== $apm ) {

			foreach ( $apm as $value ) {
				// PHPCS:disable WordPress.PHP.YodaConditions.NotYoda
				if ( $value === 'ideal' && $currency_code === 'EUR' && $country_code === 'NL' ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'sofort' && $currency_code === 'EUR' ) {

					if ( $country_code === 'BE'
						|| $country_code === 'DE'
						|| $country_code === 'IT'
						|| $country_code === 'NL'
						|| $country_code === 'AT'
						|| $country_code === 'ES'
					) {
						array_push( $apm_array, $value );
					}
				}

				if ( $value === 'boleto' && $country_code === 'BR' ) {
					if ( $currency_code === 'BRL' || $currency_code === 'USD' ) {
						array_push( $apm_array, $value );
					}
				}

				if ( $value === 'poli' ) {
					if ( $currency_code === 'AUD' || $currency_code === 'NZD' ) {
						if ( $country_code === 'AU' || $country_code === 'NZ' ) {
							array_push( $apm_array, $value );
						}
					}
				}

				if ( $value === 'klarna' ) {
					if ( $currency_code === 'EUR'
						|| $currency_code === 'DKK'
						|| $currency_code === 'GBP'
						|| $currency_code === 'NOR'
						|| $currency_code === 'SEK'
					) {
						if ( $country_code === 'AU'
							|| $country_code === 'AT'
							|| $country_code === 'BE'
							|| $country_code === 'CA'
							|| $country_code === 'CZ'
							|| $country_code === 'DK'
							|| $country_code === 'FI'
							|| $country_code === 'FR'
							|| $country_code === 'DE'
							|| $country_code === 'GR'
							|| $country_code === 'IE'
							|| $country_code === 'IT'
							|| $country_code === 'MX'
							|| $country_code === 'NL'
							|| $country_code === 'NZ'
							|| $country_code === 'NO'
							|| $country_code === 'PL'
							|| $country_code === 'PT'
							|| $country_code === 'RO'
							|| $country_code === 'ES'
							|| $country_code === 'SE'
							|| $country_code === 'CH'
							|| $country_code === 'GB'
							|| $country_code === 'US'
						) {
							array_push( $apm_array, $value );
						}
					}
				}

				if ( $value === 'sepa' && $currency_code === 'EUR' ) {

					if ( $country_code === 'AD'
						|| $country_code === 'AT'
						|| $country_code === 'BE'
						|| $country_code === 'CY'
						|| $country_code === 'EE'
						|| $country_code === 'FI'
						|| $country_code === 'DE'
						|| $country_code === 'GR'
						|| $country_code === 'IE'
						|| $country_code === 'IT'
						|| $country_code === 'LV'
						|| $country_code === 'LT'
						|| $country_code === 'LU'
						|| $country_code === 'MT'
						|| $country_code === 'MC'
						|| $country_code === 'NL'
						|| $country_code === 'PT'
						|| $country_code === 'SM'
						|| $country_code === 'SK'
						|| $country_code === 'SI'
						|| $country_code === 'ES'
						|| $country_code === 'VA'
						|| $country_code === 'BG'
						|| $country_code === 'HR'
						|| $country_code === 'CZ'
						|| $country_code === 'DK'
						|| $country_code === 'HU'
						|| $country_code === 'IS'
						|| $country_code === 'LI'
						|| $country_code === 'NO'
						|| $country_code === 'PL'
						|| $country_code === 'RO'
						|| $country_code === 'SE'
						|| $country_code === 'CH'
						|| $country_code === 'GB'
					) {
						array_push( $apm_array, $value );
					}
				}

				if ( $value === 'eps' && $currency_code === 'EUR' && $country_code === 'AT' ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'bancontact' && $currency_code === 'EUR' && $country_code === 'BE' ) {
					array_push( $apm_array, $value );
				}

				if ( 'multibanco' === $value && 'EUR' === $currency_code && 'PT' === $country_code ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'knet' && $currency_code === 'KWD' && $country_code === 'KW' ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'fawry' && $currency_code === 'EGP' && $country_code === 'EG' ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'alipay' && $currency_code === 'USD' && $country_code === 'CN' ) {
					array_push( $apm_array, $value );
				}

				if ( $value === 'qpay' && $currency_code === 'QAR' && $country_code === 'QA' ) {
					array_push( $apm_array, $value );
				}
				// PHPCS:enable WordPress.PHP.YodaConditions.NotYoda
			}
		}

		return $apm_array;
	}

	/**
	 * Get redirect url for the payment.
	 *
	 * @param array $data Response data.
	 *
	 * @return false|mixed
	 */
	public static function get_redirect_url( $data ) {

		if ( empty( $data['_links'] ) ) {
			return false;
		}

		if ( empty( $data['_links']['redirect'] ) ) {
			return false;
		}

		if ( ! empty( $data['_links']['redirect']['href'] ) ) {
			return $data['_links']['redirect']['href'];
		}

		return false;
	}

	/**
	 * Check is successful.
	 *
	 * @param array $data Response data.
	 *
	 * @return bool
	 */
	public static function is_successful( $data ) {

		if ( ! empty( $data['http_metadata'] ) ) {
			return $data['http_metadata']->getStatusCode() < 400 && self::is_approved( $data );
		}

		return false;
	}

	/**
	 * Check is pending.
	 *
	 * @param array $data Response data.
	 *
	 * @return bool
	 */
	public static function is_pending( $data ) {
		return $data['http_metadata']->getStatusCode() === 202;
	}

	/**
	 * Check data contains approved key.
	 *
	 * @param array $data Response data.
	 *
	 * @return bool|mixed
	 */
	public static function is_approved( $data ) {
		$approved = true;
		if ( isset( $data['approved'] ) ) {
			$approved = $data['approved'];
		}

		return $approved;
	}


	/**
	 * Set WC session value by key.
	 *
	 * @param string $key Session key.
	 * @param string $value Session value.
	 *
	 * @return false|void
	 */
	public static function cko_set_session( $key, $value ) {
		if ( ! class_exists( 'WooCommerce' ) || null == WC()->session ) {
			return false;
		}

		$cko_session = WC()->session->get( 'cko_session' );

		if ( ! is_array( $cko_session ) ) {
			$cko_session = [];
		}

		$cko_session[ $key ] = $value;

		WC()->session->set( 'cko_session', $cko_session );
	}

	/**
	 *  Get WC session value by key.
	 *
	 * @param string $key Session key.
	 *
	 * @return false|mixed
	 */
	public static function cko_get_session( $key ) {
		if ( ! class_exists( 'WooCommerce' ) || null == WC()->session ) {
			return false;
		}

		$cko_session = WC()->session->get( 'cko_session' );

		if ( ! empty( $cko_session[ $key ] ) ) {
			return $cko_session[ $key ];
		}

		return false;
	}

	/**
	 * Check if cart has subscription item.
	 *
	 * @return bool
	 */
	public static function is_cart_contains_subscription() {
		$cart = WC()->cart;

		if ( $cart->is_empty() ) {
			return false;
		}

		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			$product = $cart_item['data'];

			if ( $product->is_type( 'subscription' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Track if unified express checkout container has been rendered.
	 *
	 * @param bool $set Optional. Set the flag to true.
	 * @return bool True if container has been rendered, false otherwise.
	 */
	public static function express_checkout_container_rendered( $set = false ) {
		static $rendered = false;
		
		if ( $set ) {
			$rendered = true;
		}
		
		return $rendered;
	}

	public static function is_paypal_express_available() {
		$paypal_settings = get_option( 'woocommerce_wc_checkout_com_paypal_settings' );

		$is_express_enable = ! empty( $paypal_settings['paypal_express'] ) && 'yes' === $paypal_settings['paypal_express'];

		$available_payment_methods = WC()->payment_gateways()->get_available_payment_gateways();

		$checkout_setting = get_option( 'woocommerce_wc_checkout_com_cards_settings' );
		$checkout_mode    = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';

		if ( $checkout_mode === 'classic' ) {
			/**
			 * If checkout_mode is classic, show express-paypal if enabled and 
			 * if 'wc_checkout_com_paypal' is an available payment method on checkout.
			 * 
			 * Note: On shop/cart pages, gateways might not be "available" yet, so we also
			 * check if the gateway exists in all gateways (not just available ones).
			 */
			$all_gateways = WC()->payment_gateways()->payment_gateways();
			$paypal_exists = isset( $all_gateways['wc_checkout_com_paypal'] );
			
			if ( ( isset( $available_payment_methods['wc_checkout_com_paypal'] ) || $paypal_exists ) && $is_express_enable ) {
				return true;
			}
		}
		else {
			/**
			 * If checkout_mode is flow, show express-paypal if enabled.
			 */
			if ( $is_express_enable ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if Google Pay Express is available.
	 *
	 * @return bool True if Google Pay Express is available, false otherwise.
	 */
	public static function is_google_pay_express_available() {
		$google_pay_settings = get_option( 'woocommerce_wc_checkout_com_google_pay_settings' );

		$is_express_enable = ! empty( $google_pay_settings['google_pay_express'] ) && 'yes' === $google_pay_settings['google_pay_express'];

		$available_payment_methods = WC()->payment_gateways()->get_available_payment_gateways();

		$checkout_setting = get_option( 'woocommerce_wc_checkout_com_cards_settings' );
		$checkout_mode    = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';

		if ( $checkout_mode === 'classic' ) {
			/**
			 * If checkout_mode is classic, show express-google-pay if enabled and 
			 * if 'wc_checkout_com_google_pay' is an available payment method on checkout.
			 * 
			 * Note: On shop/cart pages, gateways might not be "available" yet, so we also
			 * check if the gateway exists in all gateways (not just available ones).
			 */
			$all_gateways = WC()->payment_gateways()->payment_gateways();
			$google_pay_exists = isset( $all_gateways['wc_checkout_com_google_pay'] );
			
			if ( ( isset( $available_payment_methods['wc_checkout_com_google_pay'] ) || $google_pay_exists ) && $is_express_enable ) {
				return true;
			}
		}
		else {
			/**
			 * If checkout_mode is flow, show express-google-pay if enabled.
			 */
			if ( $is_express_enable ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if Apple Pay Express is available.
	 *
	 * @return bool True if Apple Pay Express is available, false otherwise.
	 */
	public static function is_apple_pay_express_available() {
		$apple_pay_settings = get_option( 'woocommerce_wc_checkout_com_apple_pay_settings' );

		$is_express_enable = ! empty( $apple_pay_settings['apple_pay_express'] ) && 'yes' === $apple_pay_settings['apple_pay_express'];

		$available_payment_methods = WC()->payment_gateways()->get_available_payment_gateways();

		$checkout_setting = get_option( 'woocommerce_wc_checkout_com_cards_settings' );
		$checkout_mode    = isset( $checkout_setting['ckocom_checkout_mode'] ) ? $checkout_setting['ckocom_checkout_mode'] : 'classic';

		if ( $checkout_mode === 'classic' ) {
			/**
			 * If checkout_mode is classic, show express-apple-pay if enabled and 
			 * if 'wc_checkout_com_apple_pay' is an available payment method on checkout.
			 * 
			 * Note: On shop/cart pages, gateways might not be "available" yet, so we also
			 * check if the gateway exists in all gateways (not just available ones).
			 */
			$all_gateways = WC()->payment_gateways()->payment_gateways();
			$apple_pay_exists = isset( $all_gateways['wc_checkout_com_apple_pay'] );
			
			if ( ( isset( $available_payment_methods['wc_checkout_com_apple_pay'] ) || $apple_pay_exists ) && $is_express_enable ) {
				return true;
			}
		}
		else {
			/**
			 * If checkout_mode is flow, show express-apple-pay if enabled.
			 */
			if ( $is_express_enable ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get express button height from settings.
	 *
	 * @param string $payment_method Payment method: 'apple_pay', 'google_pay', or 'paypal'.
	 * @return array Returns array with 'height' (in pixels or 'native') and 'use_native' (boolean).
	 */
	public static function get_express_button_height( $payment_method = 'apple_pay' ) {
		// Map payment method to settings key
		$settings_key_map = array(
			'apple_pay' => 'woocommerce_wc_checkout_com_apple_pay_settings',
			'google_pay' => 'woocommerce_wc_checkout_com_google_pay_settings',
			'paypal' => 'woocommerce_wc_checkout_com_paypal_settings',
		);
		
		$settings_key = isset( $settings_key_map[ $payment_method ] ) 
			? $settings_key_map[ $payment_method ] 
			: 'woocommerce_wc_checkout_com_apple_pay_settings';
		
		$settings = get_option( $settings_key, array() );
		
		$size_preset = isset( $settings[ $payment_method . '_express_button_size_preset' ] ) 
			? $settings[ $payment_method . '_express_button_size_preset' ] 
			: 'native';
		
		// If native, return native
		if ( 'native' === $size_preset ) {
			return array(
				'height' => 'native',
				'use_native' => true,
			);
		}
		
		// Map presets to heights (matching Stripe's approach)
		$preset_heights = array(
			'small' => 40,   // Small (40px) - matching Stripe
			'default' => 48, // Default (48px) - matching Stripe
			'large' => 56,   // Large (56px) - matching Stripe
		);
		
		// If custom, get custom height
		if ( 'custom' === $size_preset ) {
			$custom_height = isset( $settings[ $payment_method . '_express_button_custom_height' ] ) 
				? absint( $settings[ $payment_method . '_express_button_custom_height' ] ) 
				: 40;
			
			// Validate custom height (36-60px)
			$custom_height = max( 36, min( 60, $custom_height ) );
			
			return array(
				'height' => $custom_height,
				'use_native' => false,
			);
		}
		
		// Use preset height
		$height = isset( $preset_heights[ $size_preset ] ) ? $preset_heights[ $size_preset ] : 40;
		
		return array(
			'height' => $height,
			'use_native' => false,
		);
	}
}
