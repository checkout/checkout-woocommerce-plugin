<?php
/**
 * PayPal's method class.
 *
 * @package wc_checkout_com
 */

defined( 'ABSPATH' ) || exit;

require_once 'express/paypal/class-paypal-express.php';

use Checkout\CheckoutApiException;
use Checkout\Payments\PaymentType;

/**
 * Class WC_Gateway_Checkout_Com_PayPal for PayPal payment method.
 */
#[AllowDynamicProperties]
class WC_Gateway_Checkout_Com_PayPal extends WC_Payment_Gateway {

	/**
	 * WC_Gateway_Checkout_Com_PayPal constructor.
	 */
	public function __construct() {
		$this->id                 = 'wc_checkout_com_paypal';
		$this->method_title       = __( 'Checkout.com', 'checkout-com-unified-payments-api' );
		$this->method_description = __( 'The Checkout.com extension allows shop owners to process online payments through the <a href="https://www.checkout.com">Checkout.com Payment Gateway.</a>', 'checkout-com-unified-payments-api' );
		$this->title              = __( 'PayPal', 'checkout-com-unified-payments-api' );
		$this->has_fields         = true;
		$this->supports           = [
			'products',
			'refunds',
			'subscriptions',
			'subscription_cancellation',
			'subscription_suspension',
			'subscription_reactivation',
			'subscription_date_changes',
		];

		$this->init_form_fields();
		$this->init_settings();

		// Turn these settings into variables we can use.
		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );

		// PayPal Payment scripts.
		add_action( 'wp_enqueue_scripts', [ $this, 'payment_scripts' ] );
		add_filter( 'script_loader_tag', [ $this, 'add_attributes_to_script' ], 10, 3 );

		add_action( 'woocommerce_api_' . strtolower( 'CKO_Paypal_Woocommerce' ), [ $this, 'handle_wc_api' ] );
	}

	/**
	 * Handle paypal method API requests.
	 *
	 * @return void
	 */
	public function handle_wc_api() {

		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_GET['cko_paypal_action'] ) ) {
			switch ( $_GET['cko_paypal_action'] ) {

			case 'create_order':
				if ( ! empty( $_POST ) ) {
					// Check if this is an express checkout request
					// phpcs:ignore WordPress.Security.NonceVerification.Missing
					$express_checkout = ! empty( $_POST['express_checkout'] ) || ! empty( $_POST['use_existing_cart'] );
					
					if ( $express_checkout ) {
						// Route to express checkout handler
						$this->cko_express_create_order();
						break;
					}

					WC()->checkout->process_checkout();

					if ( wc_notice_count( 'error' ) > 0 ) {
						WC()->session->set( 'reload_checkout', true );
						$error_messages_data = wc_get_notices( 'error' );
						$error_messages      = array();
						foreach ( $error_messages_data as $key => $value ) {
							$error_messages[] = $value['notice'];
						}
						wc_clear_notices();
						ob_start();
						wp_send_json_error( array( 'messages' => $error_messages ) );
						exit;
					}
					exit();
				}
				break;
				
				case 'empty_session':
					WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', '' );
					WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_id', '' );

				case 'cc_capture':
					WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', wc_clean( $_GET['paypal_order_id'] ) );
					$this->cko_cc_capture();
					break;

				case 'express_add_to_cart':
					$this->cko_express_add_to_cart();
					break;

				case 'express_create_order':
					$this->cko_express_create_order();
					break;

				case 'express_paypal_order_session':
					WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', wc_clean( $_GET['paypal_order_id'] ) );
					$this->cko_express_paypal_order_session();
					break;

				case 'order_pay':
					$this->cko_create_order_request();
					break;
			}
		}

		// phpcs:enable
		exit();
	}

	public function cko_express_add_to_cart() {
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'checkoutcom_paypal_express_add_to_cart' ) ) {
			wp_send_json( [ 'result' => 'failed' ] );
		}

		if ( ! defined( 'WOOCOMMERCE_CART' ) ) {
			define( 'WOOCOMMERCE_CART', true );
		}

		WC()->shipping->reset_shipping();

		$product_id   = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$qty          = ! isset( $_POST['qty'] ) ? 1 : absint( $_POST['qty'] );
		$product      = wc_get_product( $product_id );
		$product_type = $product->get_type();

		// First empty the cart to prevent wrong calculation.
		WC()->cart->empty_cart();

		if ( ( 'variable' === $product_type || 'variable-subscription' === $product_type ) && isset( $_POST['attributes'] ) ) {
			$attributes = wc_clean( wp_unslash( $_POST['attributes'] ) );

			$data_store   = WC_Data_Store::load( 'product' );
			$variation_id = $data_store->find_matching_product_variation( $product, $attributes );

			$is_added_to_cart = WC()->cart->add_to_cart( $product->get_id(), $qty, $variation_id, $attributes );
		}

		if ( in_array( $product_type, [ 'simple', 'variation', 'subscription', 'subscription_variation' ], true ) ) {
			$is_added_to_cart = WC()->cart->add_to_cart( $product->get_id(), $qty );
		}

		WC()->cart->calculate_totals();

		$data           = [];
		$data['result'] = 'success';
		$data['total']  = WC()->cart->total;

		wp_send_json( $data );
	}

	public function cko_express_create_order() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$express_checkout = ! empty( $_POST['express_checkout'] );
		$add_to_cart = isset( $_POST['add_to_cart'] ) ? sanitize_text_field( wp_unslash( $_POST['add_to_cart'] ) ) : '';
		$use_existing_cart = ! empty( $_POST['use_existing_cart'] );

		// For product pages, check if add_to_cart was successful
		if ( $express_checkout && ! empty( $add_to_cart ) && 'success' !== $add_to_cart ) {
			wp_send_json_error( [ 'messages' => 'Failed to add product to cart' ] );
			return;
		}

		// Ensure cart is loaded - important for Blocks cart pages
		if ( ! WC()->cart ) {
			wp_send_json_error( [ 'messages' => 'Cart not initialized' ] );
			return;
		}

		// For Blocks cart pages, ensure cart is loaded from session
		// This is important because Blocks cart might not have synced with server session
		if ( $use_existing_cart ) {
			// Force cart to load from session
			WC()->cart->get_cart_from_session();
			
			// Recalculate totals to ensure we have the latest
			WC()->cart->calculate_totals();
			
			// Check if cart is empty after loading from session
			if ( WC()->cart->is_empty() ) {
				wp_send_json_error( [ 'messages' => 'Cart is empty' ] );
				return;
			}
		}

		// For product pages, ensure cart is not empty after adding product
		if ( ! $use_existing_cart && WC()->cart->is_empty() ) {
			wp_send_json_error( [ 'messages' => 'Cart is empty' ] );
			return;
		}

		$this->cko_create_order_request( true );
	}

	public function cko_express_paypal_order_session() {
		$cko_paypal_order_id = WC_Checkoutcom_Utility::cko_get_session( 'cko_paypal_order_id' );
		$cko_pc_id           = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' );

		// If we have a payment context, process the express checkout immediately
		if ( ! empty( $cko_pc_id ) ) {
			try {
				// Create the order from cart
				$order = $this->create_express_order_from_cart();
				
				if ( ! $order ) {
					wp_send_json_error( array( 'messages' => 'Failed to create order for PayPal Express checkout.' ) );
					return;
				}

				// Get payment context details
				$checkout = new Checkout_SDK();
				$response = $checkout->get_builder()->getPaymentContextsClient()->getPaymentContextDetails( $cko_pc_id );
				
				$payment_context_id    = $cko_pc_id;
				$processing_channel_id = $response['payment_request']['processing_channel_id'];

				// Process the payment immediately
				$payment_response = $this->request_payment( $order, $payment_context_id, $processing_channel_id );

				WC_Checkoutcom_Utility::logger( 'PayPal Express: Payment response received. ID: ' . ( isset( $payment_response['id'] ) ? $payment_response['id'] : 'N/A' ) . ', status: ' . ( isset( $payment_response['status'] ) ? $payment_response['status'] : 'N/A' ) );

				// Clear PayPal session
				WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', '' );
				WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_id', '' );

				// Check if payment was successful
				if ( isset( $payment_response['result'] ) && $payment_response['result'] === 'success' ) {
					// Payment was successful - use the redirect URL from the response
					$redirect_url = $payment_response['redirect'];
					
					// Debug logging
					WC_Checkoutcom_Utility::logger( 'PayPal Express: Payment successful, redirecting to: ' . $redirect_url );
					WC_Checkoutcom_Utility::logger( 'PayPal Express: Order ID: ' . $order->get_id() . ', Order Key: ' . $order->get_order_key() );
					
					wp_send_json_success( array( 'redirect_url' => $redirect_url ) );
				} else {
					// Payment failed
					$order->update_status( 'failed', 'PayPal Express payment failed.' );
					wp_send_json_error( array( 'messages' => 'Payment failed. Please try again.' ) );
				}

			} catch ( CheckoutApiException $ex ) {
				$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';
				$error_message = 'An error occurred while processing PayPal Express payment. ';
				
				if ( $gateway_debug ) {
					$error_message .= $ex->getMessage();
				}

				WC_Checkoutcom_Utility::logger( $error_message, $ex );
				wp_send_json_error( array( 'messages' => $error_message ) );
			}
		} else {
			// No payment context, just return success (fallback to old behavior)
			wp_send_json_success();
		}
	}

	/**
	 * Create order from cart for PayPal Express checkout.
	 *
	 * @return WC_Order|false
	 */
	private function create_express_order_from_cart() {
		try {
			// Determine customer ID and email
			$customer_id = 0;
			$customer_email = '';
			
			// Check if user is logged in
			if ( is_user_logged_in() ) {
				$current_user = wp_get_current_user();
				$customer_id = $current_user->ID;
				$customer_email = $current_user->user_email;
			} else {
				// For guest users, get email from PayPal data
				$paypal_email = $this->get_paypal_email_from_context();
				if ( ! empty( $paypal_email ) ) {
					$customer_email = $paypal_email;
				}
			}

			// Create order with proper customer ID
			$order = wc_create_order( array( 'customer_id' => $customer_id ) );
			
			if ( ! $order ) {
				return false;
			}

			// Set customer email if we have one
			if ( ! empty( $customer_email ) ) {
				$order->set_billing_email( $customer_email );
			}

			// Add cart items to order
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$product = $cart_item['data'];
				$order->add_product( $product, $cart_item['quantity'] );
			}

			// Set order addresses from PayPal data if available
			$this->set_order_addresses_from_paypal( $order );

			// Set shipping method if available
			$shipping_packages = WC()->shipping->get_packages();
			if ( ! empty( $shipping_packages ) ) {
				foreach ( $shipping_packages as $package ) {
					$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
					if ( ! empty( $chosen_methods ) ) {
						$order->set_shipping_method( $chosen_methods[0] );
					}
				}
			}

			// Calculate totals
			$order->calculate_totals();

			// Set payment method to PayPal Express
			$order->set_payment_method( 'wc_checkout_com_paypal' );
			$order->set_payment_method_title( 'PayPal Express' );

			// Set order status
			$order->set_status( 'pending' );
			$order->save();

			// Store order ID in session for potential use
			WC()->session->set( 'order_awaiting_payment', $order->get_id() );

			return $order;

		} catch ( Exception $e ) {
			WC_Checkoutcom_Utility::logger( 'Error creating PayPal Express order: ' . $e->getMessage(), $e );
			return false;
		}
	}

	/**
	 * Set order addresses from PayPal payment context data.
	 *
	 * @param WC_Order $order
	 */
	private function set_order_addresses_from_paypal( $order ) {
		$cko_pc_details = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_details' );
		
		if ( empty( $cko_pc_details ) ) {
			// Try to get payment context details
			$cko_pc_id = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' );
			if ( ! empty( $cko_pc_id ) ) {
				try {
					$checkout = new Checkout_SDK();
					$cko_pc_details = $checkout->get_builder()->getPaymentContextsClient()->getPaymentContextDetails( $cko_pc_id );
					WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_details', $cko_pc_details );
				} catch ( Exception $e ) {
					// If we can't get details, use default addresses
					return;
				}
			}
		}

		if ( isset( $cko_pc_details['payment_request']['shipping']['address'] ) ) {
			$paypal_shipping_address = $cko_pc_details['payment_request']['shipping']['address'];
			$shipping_name = $cko_pc_details['payment_request']['shipping']['first_name'] ?? '';
			$shipping_name_parts = explode( ' ', $shipping_name );
			$shipping_first_name = $shipping_name_parts[0] ?? '';
			$shipping_last_name = $shipping_name_parts[1] ?? '';

			// Set shipping address
			$order->set_shipping_first_name( $shipping_first_name );
			$order->set_shipping_last_name( $shipping_last_name );
			$order->set_shipping_address_1( $paypal_shipping_address['address_line1'] ?? '' );
			$order->set_shipping_address_2( $paypal_shipping_address['address_line2'] ?? '' );
			$order->set_shipping_city( $paypal_shipping_address['city'] ?? '' );
			$order->set_shipping_postcode( $paypal_shipping_address['zip'] ?? '' );
			$order->set_shipping_country( $paypal_shipping_address['country'] ?? '' );

			// Set billing address (same as shipping for PayPal Express)
			$order->set_billing_first_name( $shipping_first_name );
			$order->set_billing_last_name( $shipping_last_name );
			$order->set_billing_address_1( $paypal_shipping_address['address_line1'] ?? '' );
			$order->set_billing_address_2( $paypal_shipping_address['address_line2'] ?? '' );
			$order->set_billing_city( $paypal_shipping_address['city'] ?? '' );
			$order->set_billing_postcode( $paypal_shipping_address['zip'] ?? '' );
			$order->set_billing_country( $paypal_shipping_address['country'] ?? '' );

			// Set email based on user login status
			if ( is_user_logged_in() ) {
				// For logged-in users, use their account email
				$current_user = wp_get_current_user();
				if ( $current_user && $current_user->user_email ) {
					$order->set_billing_email( $current_user->user_email );
				}
			} else {
				// For guest users, get email from PayPal data
				$paypal_email = $this->get_paypal_email_from_context( $cko_pc_details );
				if ( ! empty( $paypal_email ) ) {
					$order->set_billing_email( $paypal_email );
				}
			}
		}
	}

	/**
	 * Get PayPal email from payment context details.
	 * Checks multiple possible locations in the PayPal response.
	 *
	 * @param array $cko_pc_details Payment context details (optional, will fetch if not provided).
	 * @return string Email address or empty string if not found.
	 */
	private function get_paypal_email_from_context( $cko_pc_details = null ) {
		if ( empty( $cko_pc_details ) ) {
			$cko_pc_details = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_details' );
		}
		
		if ( empty( $cko_pc_details ) ) {
			// Try to get payment context details
			$cko_pc_id = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' );
			if ( ! empty( $cko_pc_id ) ) {
				try {
					$checkout = new Checkout_SDK();
					$cko_pc_details = $checkout->get_builder()->getPaymentContextsClient()->getPaymentContextDetails( $cko_pc_id );
					WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_details', $cko_pc_details );
				} catch ( Exception $e ) {
					return '';
				}
			}
		}

		if ( empty( $cko_pc_details ) || ! isset( $cko_pc_details['payment_request'] ) ) {
			return '';
		}

		// Try to get email from different possible locations in PayPal response
		// Check source.account_holder.email first (this is where PayPal often puts it)
		if ( isset( $cko_pc_details['payment_request']['source']['account_holder']['email'] ) ) {
			return $cko_pc_details['payment_request']['source']['account_holder']['email'];
		}
		
		if ( isset( $cko_pc_details['payment_request']['shipping']['email'] ) ) {
			return $cko_pc_details['payment_request']['shipping']['email'];
		}
		
		if ( isset( $cko_pc_details['payment_request']['billing']['email'] ) ) {
			return $cko_pc_details['payment_request']['billing']['email'];
		}
		
		if ( isset( $cko_pc_details['payment_request']['payer']['email'] ) ) {
			return $cko_pc_details['payment_request']['payer']['email'];
		}

		// Try additional locations that might contain email
		if ( isset( $cko_pc_details['payment_request']['customer']['email'] ) ) {
			return $cko_pc_details['payment_request']['customer']['email'];
		}

		return '';
	}

	/**
	 * Process payment with PayPal.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array
	 */
	public function process_payment( $order_id ) {
		if ( ! session_id() ) {
			session_start();
		}

		$cko_paypal_order_id = WC_Checkoutcom_Utility::cko_get_session( 'cko_paypal_order_id' );
		$cko_pc_id           = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' );

		if ( ! empty( $cko_pc_id ) ) {

			try {
				$checkout = new Checkout_SDK();
				$response = $checkout->get_builder()->getPaymentContextsClient()->getPaymentContextDetails( $cko_pc_id );

				$order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
				$order    = wc_get_order( $order_id );

				$payment_context_id    = $cko_pc_id;
				$processing_channel_id = $response['payment_request']['processing_channel_id'];

				// Payment request to capture amount.
				$return_response = $this->request_payment( $order, $payment_context_id, $processing_channel_id );

				WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', '' );
				WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_id', '' );

				wp_send_json( $return_response );

			} catch ( CheckoutApiException $ex ) {
				$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';

				$error_message = 'An error has occurred while processing PayPal getPaymentContextDetails request. ';

				if ( $gateway_debug ) {
					$error_message .= $ex->getMessage();
				}

				WC_Checkoutcom_Utility::logger( $error_message, $ex );

				wp_send_json_error( [ 'messages' => $error_message ] );
			}
		} else {
			// Not express checkout
			$this->cko_create_order_request();
		}

		exit();
	}

	/**
	 * Handle PayPal PaymentContexts request with cart data.
	 *
	 * 1st step to generate PayPal Order ID.
	 *
	 * @return void
	 */
	public function cko_create_order_request( $is_express = false ) {

		// Ensure cart is loaded and totals are calculated
		// This is important for Blocks cart pages
		if ( ! WC()->cart ) {
			wp_send_json_error( array( 'messages' => 'Cart not initialized' ) );
			return;
		}

		// For Blocks cart pages, ensure cart is loaded from session
		// Sometimes the cart needs to be refreshed from the session
		if ( WC()->cart->is_empty() ) {
			// Try to load cart from session
			WC()->cart->get_cart_from_session();
			WC()->cart->calculate_totals();
		}
		
		// Recalculate totals to ensure we have the latest (important for Blocks cart)
		WC()->cart->calculate_totals();

		// For Blocks cart pages, ensure cart contents are loaded
		if ( WC()->cart->is_empty() ) {
			WC_Checkoutcom_Utility::logger( 'PayPal Express: Cart is empty after session load. Item count: ' . WC()->cart->get_cart_contents_count() );
			wp_send_json_error( array( 'messages' => 'Cart is empty. Please add items to your cart.' ) );
			return;
		}

		$paymentContextsRequest           = new Checkout\Payments\Contexts\PaymentContextsRequest();
		$paymentContextsRequest->source   = new Checkout\Payments\Request\Source\Apm\RequestPayPalSource();
		$paymentContextsRequest->currency = get_woocommerce_currency();

		$paymentContextsRequest->processing                      = new Checkout\Payments\Contexts\PaymentContextsProcessing();
		$paymentContextsRequest->processing->shipping_preference = Checkout\Payments\ShippingPreference::$GET_FROM_FILE;

		if ( $is_express ) {
			$paymentContextsRequest->processing->user_action = Checkout\Payments\UserAction::$CONTINUE;
		}

		// Get cart total - use 'raw' to get the numeric value directly
		$total_amount = WC()->cart->get_total( 'raw' );
		
		// Fallback to formatted total if raw is 0
		if ( $total_amount <= 0 ) {
			$total_amount = WC()->cart->total;
		}

		// Validate that we have a valid total amount
		if ( $total_amount <= 0 ) {
			WC_Checkoutcom_Utility::logger( 'PayPal Express: Invalid cart total (' . floatval( $total_amount ) . '). Item count: ' . WC()->cart->get_cart_contents_count() );
			wp_send_json_error( array( 'messages' => 'Cart total is invalid. Please refresh the page and try again.' ) );
			return;
		}

		// Logic for order-pay page.

		$is_order_pay = get_option( 'woocommerce_checkout_pay_endpoint', 'order-pay' );

		$nonce = isset( $_POST['woocommerce-pay-nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['woocommerce-pay-nonce'] ) ) : '';

		if ( ! empty( $nonce ) && wp_verify_nonce( $nonce, 'woocommerce-pay' ) ) {
			
			$referer_url = isset( $_POST['_wp_http_referer'] ) ? esc_url_raw( wp_unslash( $_POST['_wp_http_referer'] ) ) : '';

			if ( strpos( $referer_url, "/{$is_order_pay}/" ) !== false ) {
				$parts = explode( '/', trim( $referer_url, '/' ) );

				$order_pay_id = isset( $parts[2] ) ? absint( $parts[2] ) : 0;

				$pay_order = wc_get_order( $order_pay_id );
				
				if ( $pay_order ) {
					$total_amount = $pay_order->get_total();
				}
			}
		}

		$amount_cents = WC_Checkoutcom_Utility::value_to_decimal( $total_amount, get_woocommerce_currency() );

		$paymentContextsRequest->amount  = $amount_cents;
		$paymentContextsRequest->capture = true;

		$paymentContextsRequest->payment_type = PaymentType::$regular;

		if ( WC_Checkoutcom_Utility::is_cart_contains_subscription() ) {
			$paymentContextsRequest->payment_type = PaymentType::$recurring;

			$plan       = new Checkout\Payments\BillingPlan();
			$plan->type = Checkout\Payments\BillingPlanType::$merchant_initiated_billing_single_agreement;

			$paymentContextsRequest->processing->plan = $plan;
		}

		$items             = new Checkout\Payments\Contexts\PaymentContextsItems();
		$items->name       = 'All Products';
		$items->unit_price = $amount_cents;
		$items->quantity   = '1';

		$paymentContextsRequest->items = [ $items ];

		$checkout = new Checkout_SDK();

		try {
			$response = $checkout->get_builder()->getPaymentContextsClient()->createPaymentContexts( $paymentContextsRequest );

			WC_Checkoutcom_Utility::logger( 'PayPal Express: Payment context response. ID: ' . ( isset( $response['id'] ) ? $response['id'] : 'N/A' ) . ', response keys: ' . implode( ', ', array_keys( (array) $response ) ) );

			if ( ! isset( $response['id'] ) ) {
				WC_Checkoutcom_Utility::logger( 'PayPal Express: No payment context ID in response. Response keys: ' . implode( ', ', array_keys( (array) $response ) ) );
				wp_send_json_error( [ 'messages' => 'Failed to create PayPal payment context. No ID returned.' ] );
				return;
			}

			WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_id', $response['id'] );

			// Return order_id from partner_metadata (PayPal Order ID)
			// Check multiple possible locations for order_id
			$order_id = null;
			if ( isset( $response['partner_metadata']['order_id'] ) ) {
				$order_id = $response['partner_metadata']['order_id'];
			} elseif ( isset( $response['partner_metadata'] ) && is_array( $response['partner_metadata'] ) ) {
				// Try to find order_id anywhere in partner_metadata
				foreach ( $response['partner_metadata'] as $key => $value ) {
					if ( 'order_id' === $key || 'orderId' === $key || 'order-id' === $key ) {
						$order_id = $value;
						break;
					}
				}
			} elseif ( isset( $response['order_id'] ) ) {
				$order_id = $response['order_id'];
			}

			if ( $order_id ) {
				WC_Checkoutcom_Utility::logger( 'PayPal Express: Order ID found: ' . $order_id );
				wp_send_json( [ 'order_id' => $order_id ], 200 );
			} else {
				// If no order_id found, log and return error
				WC_Checkoutcom_Utility::logger( 'PayPal Express: No order_id found in response. Response keys: ' . implode( ', ', array_keys( (array) $response ) ) );
				wp_send_json_error( [ 'messages' => 'Failed to create PayPal order. No order ID returned from payment context.' ] );
			}
		} catch ( CheckoutApiException $ex ) {
			$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';

			$error_message = 'An error has occurred while processing PayPal createPaymentContexts request. ';

			if ( $gateway_debug ) {
				$error_message .= $ex->getMessage();
			}

			// Log detailed error information
			WC_Checkoutcom_Utility::logger( 'PayPal Express: CheckoutApiException caught. Error message: ' . $ex->getMessage() );

			// Get more detailed error information if available
			if ( method_exists( $ex, 'getErrorDetails' ) ) {
				$error_details = $ex->getErrorDetails();
				WC_Checkoutcom_Utility::logger( 'PayPal Express: Error codes: ' . ( isset( $error_details['error_codes'] ) ? implode( ', ', (array) $error_details['error_codes'] ) : 'N/A' ) );
				if ( is_array( $error_details ) && isset( $error_details['error_codes'] ) ) {
					$error_message .= ' Error codes: ' . implode( ', ', $error_details['error_codes'] );
				}
			}

			WC_Checkoutcom_Utility::logger( $error_message, $ex );

			wp_send_json_error( [ 'messages' => $error_message ] );
		} catch ( \Exception $ex ) {
			// Catch any other exceptions
			WC_Checkoutcom_Utility::logger( 'PayPal Express: General exception caught. Error: ' . $ex->getMessage() );
			WC_Checkoutcom_Utility::logger( 'PayPal Express: Exception trace: ' . $ex->getTraceAsString() );
			wp_send_json_error( [ 'messages' => 'An unexpected error occurred: ' . $ex->getMessage() ] );
		}

		exit();
	}

	/**
	 * Handle last payment request to capture payment.
	 *
	 * @return void
	 */
	public function cko_cc_capture() {
		$cko_paypal_order_id = WC_Checkoutcom_Utility::cko_get_session( 'cko_paypal_order_id' );
		$cko_pc_id           = WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' );

		if ( empty( $cko_pc_id ) ) {
			return;
		}

		try {
			$checkout = new Checkout_SDK();
			$response = $checkout->get_builder()->getPaymentContextsClient()->getPaymentContextDetails( $cko_pc_id );

			$order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );
			$order    = wc_get_order( $order_id );

			$payment_context_id    = $cko_pc_id;
			$processing_channel_id = $response['payment_request']['processing_channel_id'];

			// Payment request to capture amount.
			$return_response = $this->request_payment( $order, $payment_context_id, $processing_channel_id );

			WC_Checkoutcom_Utility::cko_set_session( 'cko_paypal_order_id', '' );
			WC_Checkoutcom_Utility::cko_set_session( 'cko_pc_id', '' );

			wp_send_json_success( $return_response );

		} catch ( CheckoutApiException $ex ) {
			$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';

			$error_message = 'An error has occurred while processing PayPal getPaymentContextDetails request. ';

			if ( $gateway_debug ) {
				$error_message .= $ex->getMessage();
			}

			WC_Checkoutcom_Utility::logger( $error_message, $ex );

			wp_send_json_error( [ 'messages' => $error_message ] );
		}
	}

	/**
	 * Handle request to capture amount.
	 *
	 * @param WC_Order $order Order object.
	 * @param string   $payment_context_id Payment Context ID.
	 * @param string   $processing_channel_id Processing channel ID.
	 * @return array|void
	 */
	public function request_payment( $order, $payment_context_id, $processing_channel_id ) {

		try {
			$checkout = new Checkout_SDK();

			$amount       = $order->get_total();
			$amount_cents = WC_Checkoutcom_Utility::value_to_decimal( $amount, $order->get_currency() );

			$payment_request_param                        = $checkout->get_payment_request();
			$payment_request_param->payment_context_id    = $payment_context_id;
			$payment_request_param->processing_channel_id = $processing_channel_id;
			$payment_request_param->reference             = $order->get_order_number();
			$payment_request_param->amount                = $amount_cents;

			$items             = new Checkout\Payments\Contexts\PaymentContextsItems();
			$items->name       = 'All Products';
			$items->unit_price = $amount_cents;
			$items->quantity   = '1';

			$payment_request_param->items = [ $items ];

			$response      = $checkout->get_builder()->getPaymentsClient()->requestPayment( $payment_request_param );
			$response_code = $response['http_metadata']->getStatusCode();

			if ( ! WC_Checkoutcom_Utility::is_successful( $response ) || 'Declined' === $response['status'] ) {
				$order->update_meta_data( '_cko_payment_id', $response['id'] );
				$order->save();

				$error_message = esc_html__( 'An error has occurred while PayPal payment request. ', 'checkout-com-unified-payments-api' );

				wp_send_json_error( [ 'messages' => $error_message ] );
			}

			/**
			 * Full Success = 201
			 * Partial Success = 202
			 *
			 * Ref : https://api-reference.checkout.com/#operation/requestAPaymentOrPayout!path=1/payment_context_id&t=request
			 */
			if ( in_array( $response_code, [ 201, 202 ], true ) ) {

				$order->set_transaction_id( $response['id'] );
				$order->update_meta_data( '_cko_payment_id', $response['id'] );
				
				// CRITICAL: Save order immediately so webhooks can find it by payment ID
				// Webhooks may arrive very quickly after payment, so payment ID must be saved before status update
				$order->save();
				WC_Checkoutcom_Utility::logger( 'PayPal Express: Payment ID saved to order immediately - Order ID: ' . $order->get_id() . ', Payment ID: ' . $response['id'] );
				
				// Process any pending webhooks for this order (webhooks may have arrived before payment ID was saved)
				if ( class_exists( 'WC_Checkout_Com_Webhook_Queue' ) ) {
					WC_Checkout_Com_Webhook_Queue::process_pending_webhooks_for_order( $order );
				}

				if ( class_exists( 'WC_Subscriptions_Order' ) && isset( $response['source'] ) ) {
					// Save source id for subscription.
					WC_Checkoutcom_Subscription::save_source_id( $order->get_id(), $order, $response['source']['id'] );
				}

				// Get cko auth status configured in admin.
				$status = WC_Admin_Settings::get_option( 'ckocom_order_authorised', 'on-hold' );

				$order->update_meta_data( 'cko_payment_authorized', true );
				$order->update_status( $status );

				// Reduce stock levels.
				wc_reduce_stock_levels( $order->get_id() );

				// Remove cart.
				WC()->cart->empty_cart();

				// Return thank you page.
				return [
					'result'   => 'success',
					'redirect' => $this->get_return_url( $order ),
				];
			}
		} catch ( CheckoutApiException $ex ) {
			$gateway_debug = WC_Admin_Settings::get_option( 'cko_gateway_responses' ) === 'yes';

			$error_message = esc_html__( 'An error has occurred while PayPal payment request. ', 'checkout-com-unified-payments-api' );

			// Check if gateway response is enabled from module settings.
			if ( $gateway_debug ) {
				$error_message .= $ex->getMessage();
			}

			WC_Checkoutcom_Utility::logger( $error_message, $ex );

			wp_send_json_error( [ 'messages' => $error_message ] );
		}
	}

	/**
	 * Show module configuration in backend.
	 *
	 * @return string|void
	 */
	public function init_form_fields() {
		$this->form_fields = WC_Checkoutcom_Cards_Settings::paypal_settings();
		$this->form_fields = array_merge(
			$this->form_fields,
			[
				'screen_button' => [
					'id'    => 'screen_button',
					'type'  => 'screen_button',
					'title' => __( 'Other Settings', 'checkout-com-unified-payments-api' ),
				],
			]
		);
	}

	/**
	 * Generate links for the admin page.
	 *
	 * @param string $key The key.
	 * @param array  $value The value.
	 */
	public function generate_screen_button_html( $key, $value ) {
		WC_Checkoutcom_Admin::generate_links( $key, $value );
	}

	/**
	 * Add attributes to script tag.
	 *
	 * @param string $tag HTML for the script tag.
	 * @param string $handle Handle of script.
	 * @param string $src Src of script.
	 * @return string
	 */
	public function add_attributes_to_script( $tag, $handle, $src ) {
		if ( 'cko-paypal-script' !== $handle ) {
			return $tag;
		}

		return str_replace( '<script src', '<script data-partner-attribution-id="CheckoutLtd_PSP" src', $tag );
	}

	/**
	 * Outputs scripts used for checkout payment.
	 */
	public function payment_scripts() {
		$paypal_enabled = ! empty( $this->get_option( 'enabled' ) ) && 'yes' === $this->get_option( 'enabled' );

		$checkout_setting = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$checkout_mode    = $checkout_setting['ckocom_checkout_mode'] ?? 'classic';

		if ( $checkout_mode === 'classic' ) {
			if ( ! $paypal_enabled ) {
					return;
			}
		}

		if ( ! empty( WC_Checkoutcom_Utility::cko_get_session( 'cko_pc_id' ) ) ) {
			return;
		}

		// Load on Cart, Checkout, pay for order or add payment method pages.
		if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) && ! is_add_payment_method_page() ) {
			return;
		}

		if ( is_wc_endpoint_url( 'order-received' ) ) {
			return;
		}

		$core_settings = function_exists( 'cko_get_raw_option' )
			? cko_get_raw_option( 'woocommerce_wc_checkout_com_cards_settings' )
			: get_option( 'woocommerce_wc_checkout_com_cards_settings', array() );
		$environment   = 'sandbox' === ( $core_settings['ckocom_environment'] ?? 'sandbox' );

		if ( $environment ) {
			// sandbox.
			$paypal_js_arg['client-id'] = 'ASLqLf4pnWuBshW8Qh8z_DRUbIv2Cgs3Ft8aauLm9Z-MO9FZx1INSo38nW109o_Xvu88P3tly88XbJMR';
		} else {
			// live.
			$paypal_js_arg['client-id'] = 'ATbi1ysGm-jp4RmmAFz1EWH4dFpPd-VdXIWWzR4QZK5LAvDu_5atDY9dsUEJcLS5mTpR8Wb1l_m6Ameq';
		}

		$paypal_js_arg['merchant-id'] = $this->get_option( 'ckocom_paypal_merchant_id' );

		$paypal_js_arg['disable-funding'] = 'credit,card,sepa';
		$paypal_js_arg['commit']          = 'false';
		$paypal_js_arg['currency']        = get_woocommerce_currency();
		$paypal_js_arg['intent']          = 'capture'; // 'authorize' // ???

		if ( WC_Checkoutcom_Utility::is_cart_contains_subscription() ) {
			$paypal_js_arg['intent'] = 'tokenize';
			$paypal_js_arg['vault']  = 'true';
		}

		$paypal_js_url = add_query_arg( $paypal_js_arg, 'https://www.paypal.com/sdk/js' );

		wp_register_script( 'cko-paypal-script', $paypal_js_url, [ 'jquery' ], null );

		$vars = [
			'create_order_url'              => add_query_arg( [ 'cko_paypal_action' => 'create_order' ], WC()->api_request_url( 'CKO_Paypal_Woocommerce' ) ),
			'clear_session_url'             => add_query_arg( [ 'cko_paypal_action' => 'empty_session' ], WC()->api_request_url( 'CKO_Paypal_Woocommerce' ) ),
			'cc_capture'                    => add_query_arg( [ 'cko_paypal_action' => 'cc_capture' ], WC()->api_request_url( 'CKO_Paypal_Woocommerce' ) ),
			'order_pay_url'                 => add_query_arg( [ 'cko_paypal_action' => 'order_pay' ], WC()->api_request_url( 'CKO_Paypal_Woocommerce' ) ),
			'woocommerce_process_checkout'  => wp_create_nonce( 'woocommerce-process_checkout' ),
			'is_cart_contains_subscription' => WC_Checkoutcom_Utility::is_cart_contains_subscription(),
			'paypal_button_selector'        => '#paypal-button-container',
		];

		wp_localize_script( 'cko-paypal-script', 'cko_paypal_vars', $vars );

		wp_enqueue_script( 'cko-paypal-script' );

		wp_register_script(
			'cko-paypal-integration-script',
			WC_CHECKOUTCOM_PLUGIN_URL . '/assets/js/cko-paypal-integration.js',
			[ 'jquery', 'cko-paypal-script' ],
			WC_CHECKOUTCOM_PLUGIN_VERSION
		);

		wp_enqueue_script( 'cko-paypal-integration-script' );
	}

	/**
	 * Show frames js on checkout page.
	 */
	public function payment_fields() {

		if ( ! empty( $this->get_option( 'description' ) ) ) {
			echo esc_html( $this->get_option( 'description' ) );
		}
	}

	/**
	 * Handle PayPal refund.
	 *
	 * @param int    $order_id Order ID.
	 * @param null   $amount  Amount to refund.
	 * @param string $reason Reason for refund.
	 *
	 * @return bool
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order  = wc_get_order( $order_id );
		$result = (array) WC_Checkoutcom_Api_Request::refund_payment( $order_id, $order );

		// check if result has error and return error message.
		if ( ! empty( $result['error'] ) ) {
			WC_Checkoutcom_Utility::wc_add_notice_self( $result['error'] );
			return false;
		}

		// Set action id as woo transaction id.
		$order->set_transaction_id( $result['action_id'] );
		$order->save();

		// Get cko auth status configured in admin.
		$status = WC_Admin_Settings::get_option( 'ckocom_order_refunded', 'refunded' );

		/* translators: %s: Action ID. */
		$message = sprintf( esc_html__( 'Checkout.com Payment refunded - Action ID : %s', 'checkout-com-unified-payments-api' ), $result['action_id'] );

		if ( isset( $_SESSION['cko-refund-is-less'] ) ) {
			if ( $_SESSION['cko-refund-is-less'] ) {
				/* translators: %s: Action ID. */
				$order->add_order_note( sprintf( esc_html__( 'Checkout.com Payment Partially refunded - Action ID : %s', 'checkout-com-unified-payments-api' ), $result['action_id'] ) );

				unset( $_SESSION['cko-refund-is-less'] );

				return true;
			}
		}

		// Add notes for the order and update status.
		$order->add_order_note( $message );
		$order->update_status( $status );

		return true;
	}
}
