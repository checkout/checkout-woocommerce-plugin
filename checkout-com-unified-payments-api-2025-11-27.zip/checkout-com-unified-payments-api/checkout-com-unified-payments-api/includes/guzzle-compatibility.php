<?php
/**
 * Guzzle HTTP Compatibility Shim
 * 
 * Handles conflicts between Guzzle 6.x (from other plugins) and Guzzle 7.x (required by Checkout.com SDK)
 * 
 * The issue: Checkout.com SDK requires Guzzle 7.x which uses GuzzleHttp\Utils::chooseHandler()
 * Other plugins may load Guzzle 6.x which doesn't have this class/method.
 * 
 * Solution: Pre-load our Guzzle 7.x Utils class BEFORE autoloader tries to use it
 * 
 * @package wc_checkout_com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// CRITICAL: Load our Guzzle Utils class FIRST, before autoloader or functions.php tries to use it
// This ensures Utils::chooseHandler() is available even if Guzzle 6.x loaded first
$guzzle_utils_path = dirname( dirname( __FILE__ ) ) . '/vendor/guzzlehttp/guzzle/src/Utils.php';
if ( file_exists( $guzzle_utils_path ) ) {
	// Only load if Utils class doesn't exist yet (to avoid conflicts)
	if ( ! class_exists( 'GuzzleHttp\Utils', false ) ) {
		require_once $guzzle_utils_path;
	}
	
	// Verify chooseHandler method exists
	if ( class_exists( 'GuzzleHttp\Utils', false ) && ! method_exists( 'GuzzleHttp\Utils', 'chooseHandler' ) ) {
		// This means Utils class exists but doesn't have the method - likely Guzzle 6.x
		error_log( 'Checkout.com: WARNING - GuzzleHttp\Utils class exists but chooseHandler method is missing.' );
		error_log( 'Checkout.com: This indicates Guzzle 6.x is loaded. Our Utils.php should have been loaded.' );
		error_log( 'Checkout.com: Attempting to reload Utils.php...' );
		// Try to reload (won't work if class already defined, but worth trying)
		if ( ! class_exists( 'GuzzleHttp\Utils', false ) ) {
			require_once $guzzle_utils_path;
		}
	}
}

// Also pre-load functions.php to ensure our version is used
// But only if Utils class exists (which we just loaded)
$guzzle_functions_path = dirname( dirname( __FILE__ ) ) . '/vendor/guzzlehttp/guzzle/src/functions.php';
if ( file_exists( $guzzle_functions_path ) && class_exists( 'GuzzleHttp\Utils', false ) ) {
	// Check if choose_handler function exists (Guzzle 6.x) - if so, don't load our functions.php
	// because it will conflict. Instead, let autoloader handle it.
	// Actually, we should load it to ensure our version is used
	if ( ! function_exists( 'GuzzleHttp\choose_handler' ) ) {
		// Guzzle 6.x functions not loaded - safe to load our functions.php
		require_once $guzzle_functions_path;
	}
	// If choose_handler exists, Guzzle 6.x is loaded - our functions.php will use Utils::chooseHandler()
	// which should now exist because we loaded Utils.php above
}

