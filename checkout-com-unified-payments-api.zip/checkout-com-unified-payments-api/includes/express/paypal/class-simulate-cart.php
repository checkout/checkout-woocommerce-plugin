<?php
/**
 * PayPal simulate cart wc-api handler.
 *
 * @package wc_checkout_com
 */

defined( 'ABSPATH' ) || exit;

class WC_Paypal_Simulate_cart {

	public static function run() {

	}
}