#!/bin/bash

# Script to update Checkout.com plugin in Docker WordPress environment
# Usage: ./update-docker.sh [container_name] [wp_plugins_path]

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}🔄 Updating Checkout.com plugin in Docker...${NC}"

# Default values
CONTAINER_NAME=""
WP_PLUGINS_PATH="/var/www/html/wp-content/plugins"

# Check if container name provided as argument
if [ -n "$1" ]; then
    CONTAINER_NAME="$1"
else
    # Try to detect WordPress container
    echo -e "${YELLOW}📦 Detecting WordPress Docker container...${NC}"
    CONTAINER_NAME=$(docker ps --format "{{.Names}}" | grep -i "wordpress\|wp\|web" | head -1)
    
    if [ -z "$CONTAINER_NAME" ]; then
        echo -e "${RED}❌ No WordPress container found. Please provide container name:${NC}"
        echo "Usage: ./update-docker.sh <container_name> [wp_plugins_path]"
        echo ""
        echo "Available containers:"
        docker ps --format "{{.Names}}"
        exit 1
    fi
    echo -e "${GREEN}✅ Found container: ${CONTAINER_NAME}${NC}"
fi

# Check if plugins path provided as argument
if [ -n "$2" ]; then
    WP_PLUGINS_PATH="$2"
fi

# Verify container exists and is running
if ! docker ps --format "{{.Names}}" | grep -q "^${CONTAINER_NAME}$"; then
    echo -e "${RED}❌ Container '${CONTAINER_NAME}' is not running${NC}"
    echo "Available containers:"
    docker ps --format "{{.Names}}"
    exit 1
fi

# Verify plugin directory exists in container
if ! docker exec "${CONTAINER_NAME}" test -d "${WP_PLUGINS_PATH}"; then
    echo -e "${YELLOW}⚠️  Default plugins path not found. Trying common alternatives...${NC}"
    
    # Try common paths
    for path in "/var/www/html/wp-content/plugins" "/app/wp-content/plugins" "/wordpress/wp-content/plugins"; do
        if docker exec "${CONTAINER_NAME}" test -d "${path}"; then
            WP_PLUGINS_PATH="${path}"
            echo -e "${GREEN}✅ Found plugins at: ${WP_PLUGINS_PATH}${NC}"
            break
        fi
    done
    
    if ! docker exec "${CONTAINER_NAME}" test -d "${WP_PLUGINS_PATH}"; then
        echo -e "${RED}❌ Could not find WordPress plugins directory${NC}"
        echo "Please provide the correct path:"
        echo "Usage: ./update-docker.sh ${CONTAINER_NAME} /path/to/wp-content/plugins"
        exit 1
    fi
fi

PLUGIN_NAME="checkout-com-unified-payments-api"
PLUGIN_DIR="${WP_PLUGINS_PATH}/${PLUGIN_NAME}"

echo -e "${GREEN}📁 Plugin directory: ${PLUGIN_DIR}${NC}"

# Check if plugin exists in container
if docker exec "${CONTAINER_NAME}" test -d "${PLUGIN_DIR}"; then
    echo -e "${YELLOW}⚠️  Plugin already exists. Backing up...${NC}"
    BACKUP_NAME="${PLUGIN_NAME}-backup-$(date +%Y%m%d-%H%M%S)"
    docker exec "${CONTAINER_NAME}" mv "${PLUGIN_DIR}" "${WP_PLUGINS_PATH}/${BACKUP_NAME}" || true
    echo -e "${GREEN}✅ Backup created: ${BACKUP_NAME}${NC}"
fi

# Copy plugin files to container
echo -e "${GREEN}📦 Copying plugin files to container...${NC}"

# Create plugin directory in container
docker exec "${CONTAINER_NAME}" mkdir -p "${PLUGIN_DIR}"

# Copy files using tar (most reliable method)
cd "$(dirname "$0")"
tar -czf - -C checkout-com-unified-payments-api . | docker exec -i "${CONTAINER_NAME}" tar -xzf - -C "${PLUGIN_DIR}"

# Set proper permissions
echo -e "${GREEN}🔐 Setting permissions...${NC}"
docker exec "${CONTAINER_NAME}" chown -R www-data:www-data "${PLUGIN_DIR}" 2>/dev/null || \
docker exec "${CONTAINER_NAME}" chown -R 33:33 "${PLUGIN_DIR}" 2>/dev/null || \
echo -e "${YELLOW}⚠️  Could not set ownership (may need root)${NC}"

docker exec "${CONTAINER_NAME}" chmod -R 755 "${PLUGIN_DIR}" 2>/dev/null || true

echo -e "${GREEN}✅ Plugin updated successfully!${NC}"
echo ""
echo -e "${GREEN}📋 Summary:${NC}"
echo "  Container: ${CONTAINER_NAME}"
echo "  Plugin Path: ${PLUGIN_DIR}"
if [ -n "${BACKUP_NAME}" ]; then
    echo "  Backup: ${BACKUP_NAME}"
fi
echo ""
echo -e "${YELLOW}💡 Next steps:${NC}"
echo "  1. Clear WordPress cache (if using caching plugin)"
echo "  2. Refresh browser cache"
echo "  3. Test the checkout flow"





