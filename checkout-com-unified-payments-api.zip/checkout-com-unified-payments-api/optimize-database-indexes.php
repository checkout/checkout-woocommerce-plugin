<?php
/**
 * Database Index Optimizer for Checkout.com Flow Integration
 * 
 * This script creates the recommended database indexes for optimal
 * performance of payment_session_id queries.
 * 
 * Usage:
 *   1. Via WP-CLI: wp eval-file optimize-database-indexes.php
 *   2. Via Browser: Place in WordPress root and access via browser (requires admin)
 * 
 * WARNING: This script modifies the database. Always backup before running.
 * 
 * @package checkout-com-unified-payments-api
 * @version 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	// If running via command line (WP-CLI), load WordPress
	if ( php_sapi_name() === 'cli' ) {
		// Try to find WordPress
		$wp_load_paths = array(
			__DIR__ . '/wp-load.php',
			__DIR__ . '/../wp-load.php',
			__DIR__ . '/../../wp-load.php',
		);
		
		foreach ( $wp_load_paths as $path ) {
			if ( file_exists( $path ) ) {
				require_once $path;
				break;
			}
		}
		
		if ( ! defined( 'ABSPATH' ) ) {
			die( 'Error: WordPress not found. Please run this script from WordPress root or via WP-CLI.' );
		}
	} else {
		// Browser access - require admin
		require_once( dirname( __FILE__ ) . '/wp-load.php' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			die( 'Error: Administrator access required.' );
		}
	}
}

// Check if WooCommerce is active
if ( ! class_exists( 'WooCommerce' ) ) {
	die( 'Error: WooCommerce is not active.' );
}

global $wpdb;

$postmeta_table = $wpdb->postmeta;
$meta_key = '_cko_payment_session_id';
$results = array();

/**
 * Check if index exists
 */
function index_exists( $wpdb, $table_name, $index_name ) {
	$exists = $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM information_schema.statistics 
		WHERE table_schema = DATABASE() 
		AND table_name = %s 
		AND index_name = %s",
		$table_name,
		$index_name
	) );
	
	return $exists > 0;
}

/**
 * Create index for payment_session_id queries
 */
function create_payment_session_index( $wpdb, $table_name, $meta_key ) {
	$index_name = 'idx_ckopaymentsessionid';
	
	// Check if index already exists
	if ( index_exists( $wpdb, $table_name, $index_name ) ) {
		return array(
			'success' => false,
			'message' => 'Index already exists.',
			'action' => 'skipped',
		);
	}
	
	// Create composite index on meta_key and meta_value
	// Using prefix length 191 for meta_value to avoid key length issues
	$sql = "CREATE INDEX {$index_name} ON {$table_name} (meta_key(191), meta_value(191))";
	
	$result = $wpdb->query( $sql );
	
	if ( $result === false ) {
		return array(
			'success' => false,
			'message' => 'Failed to create index: ' . $wpdb->last_error,
			'action' => 'failed',
		);
	}
	
	return array(
		'success' => true,
		'message' => 'Index created successfully.',
		'action' => 'created',
		'index_name' => $index_name,
	);
}

/**
 * Test query performance before and after
 */
function test_performance( $wpdb, $table_name, $meta_key ) {
	// Get sample value
	$sample_value = $wpdb->get_var( $wpdb->prepare(
		"SELECT meta_value FROM {$table_name} WHERE meta_key = %s LIMIT 1",
		$meta_key
	) );
	
	if ( ! $sample_value ) {
		return null;
	}
	
	// Run query multiple times and average
	$times = array();
	for ( $i = 0; $i < 5; $i++ ) {
		$start = microtime( true );
		$wpdb->get_results( $wpdb->prepare(
			"SELECT post_id FROM {$table_name} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
			$meta_key,
			$sample_value
		) );
		$end = microtime( true );
		$times[] = ( $end - $start ) * 1000; // Convert to ms
	}
	
	$avg_time = array_sum( $times ) / count( $times );
	
	return array(
		'average_ms' => round( $avg_time, 2 ),
		'min_ms' => round( min( $times ), 2 ),
		'max_ms' => round( max( $times ), 2 ),
	);
}

// Main execution
$results['before'] = test_performance( $wpdb, $postmeta_table, $meta_key );
$results['index_creation'] = create_payment_session_index( $wpdb, $postmeta_table, $meta_key );
$results['after'] = test_performance( $wpdb, $postmeta_table, $meta_key );

// Output results
if ( php_sapi_name() === 'cli' ) {
	echo "\n";
	echo "========================================\n";
	echo "Database Index Optimizer - Checkout.com Flow\n";
	echo "========================================\n\n";
	
	echo "Meta Key: {$meta_key}\n";
	echo "Table: {$postmeta_table}\n\n";
	
	if ( $results['before'] ) {
		echo "Performance BEFORE:\n";
		echo "  - Average: " . $results['before']['average_ms'] . "ms\n";
		echo "  - Min: " . $results['before']['min_ms'] . "ms\n";
		echo "  - Max: " . $results['before']['max_ms'] . "ms\n\n";
	}
	
	echo "Index Creation:\n";
	if ( $results['index_creation']['success'] ) {
		echo "  ✅ " . $results['index_creation']['message'] . "\n";
		if ( isset( $results['index_creation']['index_name'] ) ) {
			echo "  Index Name: " . $results['index_creation']['index_name'] . "\n";
		}
	} else {
		echo "  " . ( $results['index_creation']['action'] === 'skipped' ? 'ℹ️' : '❌' ) . " " . $results['index_creation']['message'] . "\n";
	}
	echo "\n";
	
	if ( $results['after'] ) {
		echo "Performance AFTER:\n";
		echo "  - Average: " . $results['after']['average_ms'] . "ms\n";
		echo "  - Min: " . $results['after']['min_ms'] . "ms\n";
		echo "  - Max: " . $results['after']['max_ms'] . "ms\n\n";
		
		if ( $results['before'] ) {
			$improvement = $results['before']['average_ms'] - $results['after']['average_ms'];
			$improvement_pct = ( $improvement / $results['before']['average_ms'] ) * 100;
			
			if ( $improvement > 0 ) {
				echo "Performance Improvement:\n";
				echo "  ✅ " . round( $improvement, 2 ) . "ms faster (" . round( $improvement_pct, 1 ) . "% improvement)\n";
			} else {
				echo "Performance:\n";
				echo "  ℹ️  No significant change (index may already exist or data volume is low)\n";
			}
		}
	}
	
	echo "\n";
} else {
	// HTML output
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Database Index Optimizer - Checkout.com Flow</title>
		<style>
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
				max-width: 1200px;
				margin: 40px auto;
				padding: 20px;
				background: #f5f5f5;
			}
			.container {
				background: white;
				padding: 30px;
				border-radius: 8px;
				box-shadow: 0 2px 4px rgba(0,0,0,0.1);
			}
			h1 {
				color: #333;
				border-bottom: 3px solid #0073aa;
				padding-bottom: 10px;
			}
			.status {
				padding: 15px;
				margin: 15px 0;
				border-radius: 4px;
			}
			.status.success {
				background: #d4edda;
				color: #155724;
				border-left: 4px solid #28a745;
			}
			.status.warning {
				background: #fff3cd;
				color: #856404;
				border-left: 4px solid #ffc107;
			}
			.status.info {
				background: #d1ecf1;
				color: #0c5460;
				border-left: 4px solid #17a2b8;
			}
			table {
				width: 100%;
				border-collapse: collapse;
				margin: 20px 0;
			}
			th, td {
				padding: 12px;
				text-align: left;
				border-bottom: 1px solid #ddd;
			}
			th {
				background: #f8f9fa;
				font-weight: 600;
			}
			.code {
				background: #f4f4f4;
				padding: 2px 6px;
				border-radius: 3px;
				font-family: monospace;
				font-size: 0.9em;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<h1>Database Index Optimizer - Checkout.com Flow</h1>
			
			<h2>Meta Key: <code><?php echo esc_html( $meta_key ); ?></code></h2>
			<p>Table: <code><?php echo esc_html( $postmeta_table ); ?></code></p>
			
			<h3>Index Creation Result</h3>
			<div class="status <?php echo $results['index_creation']['success'] ? 'success' : ( $results['index_creation']['action'] === 'skipped' ? 'info' : 'warning' ); ?>">
				<strong>
					<?php
					if ( $results['index_creation']['success'] ) {
						echo '✅ ' . esc_html( $results['index_creation']['message'] );
					} elseif ( $results['index_creation']['action'] === 'skipped' ) {
						echo 'ℹ️ ' . esc_html( $results['index_creation']['message'] );
					} else {
						echo '❌ ' . esc_html( $results['index_creation']['message'] );
					}
					?>
				</strong>
				<?php if ( isset( $results['index_creation']['index_name'] ) ) : ?>
					<br><br>Index Name: <code><?php echo esc_html( $results['index_creation']['index_name'] ); ?></code>
				<?php endif; ?>
			</div>
			
			<?php if ( $results['before'] && $results['after'] ) : ?>
				<h3>Performance Comparison</h3>
				<table>
					<tr>
						<th>Metric</th>
						<th>Before</th>
						<th>After</th>
						<th>Improvement</th>
					</tr>
					<tr>
						<td>Average Query Time</td>
						<td><?php echo esc_html( $results['before']['average_ms'] ); ?>ms</td>
						<td><?php echo esc_html( $results['after']['average_ms'] ); ?>ms</td>
						<td>
							<?php
							$improvement = $results['before']['average_ms'] - $results['after']['average_ms'];
							$improvement_pct = ( $improvement / $results['before']['average_ms'] ) * 100;
							if ( $improvement > 0 ) {
								echo '<span style="color: #28a745;">✅ ' . round( $improvement, 2 ) . 'ms faster (' . round( $improvement_pct, 1 ) . '%)</span>';
							} else {
								echo '<span style="color: #6c757d;">ℹ️ No significant change</span>';
							}
							?>
						</td>
					</tr>
					<tr>
						<td>Min Query Time</td>
						<td><?php echo esc_html( $results['before']['min_ms'] ); ?>ms</td>
						<td><?php echo esc_html( $results['after']['min_ms'] ); ?>ms</td>
						<td>-</td>
					</tr>
					<tr>
						<td>Max Query Time</td>
						<td><?php echo esc_html( $results['before']['max_ms'] ); ?>ms</td>
						<td><?php echo esc_html( $results['after']['max_ms'] ); ?>ms</td>
						<td>-</td>
					</tr>
				</table>
			<?php endif; ?>
			
			<div class="status info">
				<strong>Note:</strong> Index optimization is complete. You can now run the check script 
				(<code>check-database-indexes.php</code>) to verify the indexes are working correctly.
			</div>
		</div>
	</body>
	</html>
	<?php
}

