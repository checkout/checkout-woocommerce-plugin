#!/bin/bash

# Simple script to copy plugin to Docker using docker cp
# Usage: ./update-docker-simple.sh <container_name>

set -e

CONTAINER_NAME="${1}"

if [ -z "$CONTAINER_NAME" ]; then
    echo "Usage: ./update-docker-simple.sh <container_name>"
    echo ""
    echo "Available containers:"
    docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"
    exit 1
fi

PLUGIN_NAME="checkout-com-unified-payments-api"
PLUGIN_SOURCE="./checkout-com-unified-payments-api"
PLUGIN_DEST="/var/www/html/wp-content/plugins/${PLUGIN_NAME}"

echo "🔄 Updating ${PLUGIN_NAME} in container: ${CONTAINER_NAME}"

# Check if source directory exists
if [ ! -d "$PLUGIN_SOURCE" ]; then
    echo "❌ Error: Plugin directory not found: ${PLUGIN_SOURCE}"
    exit 1
fi

# Check if container is running
if ! docker ps --format "{{.Names}}" | grep -q "^${CONTAINER_NAME}$"; then
    echo "❌ Error: Container '${CONTAINER_NAME}' is not running"
    exit 1
fi

# Backup existing plugin if it exists
if docker exec "${CONTAINER_NAME}" test -d "${PLUGIN_DEST}" 2>/dev/null; then
    echo "📦 Backing up existing plugin..."
    BACKUP_NAME="${PLUGIN_NAME}-backup-$(date +%Y%m%d-%H%M%S)"
    docker exec "${CONTAINER_NAME}" mv "${PLUGIN_DEST}" "/var/www/html/wp-content/plugins/${BACKUP_NAME}" 2>/dev/null || true
    echo "✅ Backup created: ${BACKUP_NAME}"
fi

# Copy plugin files
echo "📁 Copying plugin files..."
docker cp "${PLUGIN_SOURCE}" "${CONTAINER_NAME}:${PLUGIN_DEST}"

# Set permissions
echo "🔐 Setting permissions..."
docker exec "${CONTAINER_NAME}" chown -R www-data:www-data "${PLUGIN_DEST}" 2>/dev/null || \
docker exec "${CONTAINER_NAME}" chown -R 33:33 "${PLUGIN_DEST}" 2>/dev/null || true

docker exec "${CONTAINER_NAME}" chmod -R 755 "${PLUGIN_DEST}" 2>/dev/null || true

echo "✅ Plugin updated successfully!"
echo ""
echo "💡 Don't forget to:"
echo "   - Clear WordPress cache"
echo "   - Refresh browser cache"
echo "   - Test checkout flow"





